"""Command-line entry point for the offline, chat-operated static-model kit.

Expensive geometry dependencies load only when a command needs them.
Project terms are in LICENSE; external credits are in THIRD_PARTY_NOTICES.md."""

from __future__ import annotations
import argparse
import json
import os
import sys
import tempfile
from agent import VERSION
from pathlib import Path
sys.dont_write_bytecode = True
# Avoid nested numerical worker pools in small chat-hosted builds.
for name in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS']:
    os.environ.setdefault(name, '1')


def parser():
    """Declare the supported public command-line surface in one place."""
    p = argparse.ArgumentParser(description='Lightweight, chat-operated 3D kit. Read START_HERE.md.')
    p.add_argument('--version', action='version', version=VERSION)
    sub = p.add_subparsers(dest='cmd', required=True)
    sub.add_parser('boot')
    sub.add_parser('doctor')
    sub.add_parser('verify')
    for name in ['build', 'run', 'texture']:
        x = sub.add_parser(name)
        x.add_argument('file')
        output(x)
        if name == 'build':
            x.add_argument('--quality', choices=['draft', 'standard', 'high'])
    x = sub.add_parser('hands')
    x.add_argument('model')
    x = sub.add_parser('textures')
    x.add_argument('model')
    x.add_argument('--out', required=True)
    x = sub.add_parser('material')
    x.add_argument('name', choices=['armor', 'steel', 'rubber', 'hazard', 'red_core', 'wood'])
    x.add_argument('--out', required=True)
    x = sub.add_parser('swatch')
    x.add_argument('image')
    x.add_argument('--out', required=True)
    x.add_argument('--crop', type=float, nargs=4)
    x.add_argument('--corners', type=float, nargs=8)
    x.add_argument('--size', type=int, default=512)
    x.add_argument('--delight', type=float, default=0)
    x.add_argument('--tile', action='store_true')
    x = sub.add_parser('import')
    x.add_argument('model')
    x.add_argument('--name', default='Imported_Model')
    x.add_argument('--scale', type=float, default=1)
    x.add_argument('--up', choices=['y', 'z'], default='y')
    output(x)
    x = sub.add_parser('edit')
    x.add_argument('model')
    x.add_argument('edits')
    x.add_argument('--name', default='Edited_Model')
    output(x)
    x = sub.add_parser('relief')
    x.add_argument('image')
    x.add_argument('--mode', choices=['height', 'brightness'], required=True)
    x.add_argument('--name', default='Image_Relief')
    x.add_argument('--width', type=float, default=1)
    x.add_argument('--depth', type=float, default=0.06)
    x.add_argument('--base', type=float, default=0.02)
    x.add_argument('--res', type=int, default=48)
    x.add_argument('--invert', action='store_true')
    output(x)
    x = sub.add_parser('inspect')
    x.add_argument('model')
    x.add_argument('--full', action='store_true')
    x = sub.add_parser('render')
    x.add_argument('model')
    x.add_argument('--out', required=True)
    x.add_argument('--size', type=int, default=384)
    x.add_argument('--review', action='store_true')
    x.add_argument('--aa', type=int, choices=[1, 2], default=1)
    x.add_argument('--angle', type=float)
    x.add_argument('--elev', type=float, default=17)
    x.add_argument(
        '--mode',
        choices=['beauty', 'clay', 'base', 'normal', 'rough', 'metal', 'ao', 'emission', 'uv'],
        default='beauty'
    )
    x = sub.add_parser('template')
    x.add_argument('name', choices=['pillar', 'crate', 'barrel', 'arch'])
    x.add_argument('--out', required=True)
    x = sub.add_parser('schema')
    x.add_argument(
        '--section',
        choices=['recipe', 'part', 'material', 'sculpt', 'stamp', 'use', 'task', 'edit', 'hand'],
        default='recipe'
    )
    x = sub.add_parser('audit')
    x.add_argument('folder')
    x.add_argument('--latest', action='store_true')
    x = sub.add_parser('pack')
    x.add_argument('folder')
    x.add_argument('--out', required=True)
    x = sub.add_parser('unpack')
    x.add_argument('file')
    x.add_argument('--out', required=True)
    return p


def output(p):
    p.add_argument('--out', required=True)
    p.add_argument('--size', type=int, default=384)
    p.add_argument('--no-render', action='store_true')
    p.add_argument('--max-triangles', type=int, default=200000)


def brief(data):
    if 'folder' in data and 'lods' in data:
        return {k: data[k] for k in [
            'ok',
            'name',
            'folder',
            'cached',
            'build_seconds',
            'total_seconds',
            'lods',
            'review_required'
        ] if k in data} | {'report': str(Path(data['folder']) / 'report.json')}
    return data


def execute(a):
    """Dispatch one command and return JSON-serializable results."""
    from agent.state import doctor, output_path, read, verify, write
    if a.cmd in {'boot', 'doctor'}:
        return doctor(smoke=a.cmd == 'boot')
    if a.cmd == 'verify':
        return verify()
    if a.cmd == 'schema':
        from agent import schema
        from agent.work import EDIT, TASK
        sections = {
            'recipe': schema.SCHEMA,
            'part': schema.PART,
            'material': schema.MAT,
            'sculpt': schema.SCULPT,
            'stamp': schema.STAMP,
            'use': schema.USE,
            'task': TASK,
            'edit': EDIT,
            'hand': schema.HAND
        }
        return sections[a.section]
    if a.cmd == 'hands':
        from agent.hands import check
        return check(a.model)
    if a.cmd == 'textures':
        from agent.quality import inspect
        path = output_path(a.out)
        return inspect(a.model, path)
    if a.cmd == 'material':
        from agent.presets import material
        path = output_path(a.out)
        write(path, material(a.name))
        return {'ok': True, 'file': str(path)}
    if a.cmd == 'swatch':
        from agent.photo import swatch
        corners = [a.corners[i:i + 2] for i in range(0, 8, 2)] if a.corners else None
        return swatch(a.image, a.out, a.crop, corners, a.size, a.delight, a.tile)
    if a.cmd == 'template':
        from agent.templates import get
        path = output_path(a.out)
        data = get(a.name)
        data['lods'] = [1]
        data['texture_size'] = 256
        write(path, data)
        return {'ok': True, 'file': str(path)}
    if a.cmd == 'build':
        from agent.build import build
        from agent.schema import load
        path = Path(a.file).resolve()
        from agent.presets import quality
        data = quality(load(path), a.quality)
        data['max_triangles'] = min(data.get('max_triangles', 10000), a.max_triangles)
        return brief(build(data, path.parent, a.out, render='none' if a.no_render else 'cpu', size=a.size))
    if a.cmd in {'import', 'edit', 'relief', 'run', 'texture'}:
        from agent.work import run
        if a.cmd in {'run', 'texture'}:
            path = Path(a.file).resolve()
            job = read(path)
            if a.cmd == 'texture' and job.get('op') != 'texture':
                raise ValueError('The texture command expects a texture task JSON.')
        elif a.cmd == 'relief':
            path = Path(a.image).resolve()
            job = {
                'schema': 'ai3d.task/1',
                'name': a.name,
                'op': 'relief',
                'image': path.name,
                'mode': a.mode,
                'width': a.width,
                'depth': a.depth,
                'base': a.base,
                'res': a.res,
                'invert': a.invert
            }
        else:
            path = Path(a.model).resolve()
            job = {'schema': 'ai3d.task/1', 'name': a.name, 'op': 'import', 'model': path.name}
            if a.cmd == 'edit':
                job['edits'] = read(a.edits)
            else:
                job['scale'] = [a.scale] * 3
                job['rot'] = [-90, 0, 0] if a.up == 'z' else [0, 0, 0]
        return brief(run(job, path.parent, a.out, size=a.size, draw=not a.no_render, limit=a.max_triangles))
    if a.cmd == 'inspect':
        from agent.files import load
        from agent.work import warnings
        from core.validate import check
        g, notes = load(a.model)
        with tempfile.TemporaryDirectory(prefix='ai3d-inspect-') as tmp:
            path = g.save(Path(tmp) / 'model.glb')
            valid = check(path)
        result = {'ok': valid['passed'], 'validation': valid, 'limitations': notes + warnings(g)}
        inventory = g.inventory()
        result['inventory'] = inventory if a.full else {
            'nodes': inventory['nodes'][:80],
            'node_count': len(inventory['nodes']),
            'materials': [{'index': i['index'], 'name': i['name']} for i in inventory['materials']]
        }
        return result
    if a.cmd == 'render':
        from agent.files import load
        from agent.preview import render
        from core.validate import check
        path = output_path(a.out)
        g, notes = load(a.model)
        with tempfile.TemporaryDirectory(prefix='ai3d-render-') as tmp:
            model = g.save(Path(tmp) / 'model.glb')
            valid = check(model)
            if not valid['passed']:
                raise ValueError('; '.join(valid['errors']))
            if a.angle is not None or a.mode != 'beauty':
                from agent.preview import cpu
                rows = [cpu(
                    model,
                    path / 'custom.png',
                    a.size,
                    angle=a.angle if a.angle is not None else 35,
                    elev=a.elev,
                    mode=a.mode,
                    aa=a.aa
                )]
            else:
                rows = render(model, path, size=a.size, review=a.review, aa=a.aa)
        return {'ok': True, 'views': rows, 'notes': notes}
    if a.cmd == 'audit':
        from agent.build import audit
        return audit(a.folder, a.latest)
    if a.cmd == 'pack':
        from agent.work import pack
        return pack(a.folder, a.out)
    if a.cmd == 'unpack':
        from agent.files import unpack
        return unpack(a.file, a.out)
    raise ValueError('Unknown command.')


def main():
    """Report command failures as structured output with a nonzero exit status."""
    a = parser().parse_args()
    try:
        data = execute(a)
        print(json.dumps(data, indent=2, allow_nan=False))
        return 0 if data.get('ok', True) else 1
    except KeyboardInterrupt:
        print(json.dumps({'ok': False, 'error': 'Interrupted.'}))
        return 130
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': str(exc), 'type': type(exc).__name__}, allow_nan=False))
        return 1
if __name__ == '__main__':
    raise SystemExit(main())
