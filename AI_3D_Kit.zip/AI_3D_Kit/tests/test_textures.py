"""Regression tests for material channels, UVs, image preparation, and renders."""

from __future__ import annotations
import io
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from agent.build import build, audit
from agent.geom import shape
from agent.hard import prism
from agent.mats import make, color, srgb
from agent.photo import swatch
from agent.preview import cpu, sample, render
from agent.quality import inspect
from agent.schema import validate
from agent.uv import atlas, metric, stats
from agent.wear import edges
from agent.work import run
from core.mesh import GLB, box
from core.validate import check


class TextureTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.recipe = {
            'schema': 'ai3d.recipe/1',
            'name': 'Test',
            'texture_size': 64,
            'materials': {'m': {'kind': 'steel', 'color': [0.3, 0.32, 0.34], 'bump': 0.0002}},
            'parts': [{
                'name': 'body',
                'shape': 'box',
                'mat': 'm',
                'size': [1, 1, 1],
                'bevel': 0.04,
                'uv': 'atlas'
            }]
        }

    def tearDown(self):
        self.tmp.cleanup()

    def img(self, name, color=(128, 128, 128)):
        path = self.root / name
        Image.new('RGB', (16, 16), color).save(path)
        return path

    def model(self, uv=True):
        g = GLB()
        g.material('old', color=(0.5, 0.4, 0.3, 1))
        g.add_mesh('body', box((1, 1, 1), 0), 'old')
        g.group('other', mesh=0, pos=(2, 0, 0))
        if not uv:
            g.j['meshes'][0]['primitives'][0]['attributes'].pop('TEXCOORD_0')
        return g.save(self.root / 'source.glb')

    def job(self, uv='keep'):
        return {
            'schema': 'ai3d.task/1',
            'name': 'Paint',
            'op': 'texture',
            'model': 'source.glb',
            'texture_size': 64,
            'materials': {'m': {'kind': 'steel', 'rough': 0.6}},
            'assign': [{'node': 'body', 'mat': 'm', 'uv': uv}]
        }

    def test_prism_closed(self):
        m = prism([[-0.5, -0.5], [0.5, -0.5], [0.3, 0.6], [-0.2, 0.8]], 0.4, 0.03, 0.6)
        g = GLB()
        g.material('a')
        g.add_mesh('wedge', m, 'a')
        result = check(g.save(self.root / 'p.glb'))
        self.assertTrue(result['passed'])
        self.assertEqual(result['degenerate_triangles'], 0)
        tri = m.v[m.f]
        volume = np.einsum('ij,ij->i', tri[:, 0], np.cross(tri[:, 1], tri[:, 2])).sum() / 6
        self.assertGreater(volume, 0)

    def test_prism_rejects_interior(self):
        with self.assertRaises(ValueError):
            prism([[0, 0], [1, 0], [1, 1], [0, 1], [0.5, 0.5]], 0.5)

    def test_prism_bevel_limit(self):
        with self.assertRaises(ValueError):
            prism([[0, 0], [1, 0], [0.5, 1]], 0.1, 0.06)

    def test_atlas_area(self):
        m = atlas(box((1, 2, 3), 0.03))
        result = stats(m)
        self.assertEqual(result['zero_uv_triangles'], 0)
        self.assertLess(result['uv_area_sum'], 1)
        self.assertGreater(m.uv.min(), 0)
        self.assertLess(m.uv.max(), 1)

    def test_metric_scale(self):
        m = metric(box((1, 2, 3), 0), 0.5)
        a = np.linalg.norm(m.v[m.f[:, 1]] - m.v[m.f[:, 0]], axis=1)
        b = np.linalg.norm(m.uv[m.f[:, 1]] - m.uv[m.f[:, 0]], axis=1)
        np.testing.assert_allclose(b, a * 2)

    def test_explicit_custom_uv(self):
        m = shape({
            'shape': 'mesh',
            'v': [[0, 0, 0], [1, 0, 0], [0, 1, 0]],
            'f': [[0, 1, 2]],
            'uvs': [[0.1, 0.2], [0.8, 0.2], [0.1, 0.8]]
        })
        np.testing.assert_allclose(m.uv, [[0.1, 0.2], [0.8, 0.2], [0.1, 0.8]])

    def test_custom_uv_count(self):
        with self.assertRaises(ValueError):
            shape({
                'shape': 'mesh',
                'v': [[0, 0, 0], [1, 0, 0], [0, 1, 0]],
                'f': [[0, 1, 2]],
                'uvs': [[0, 0]]
            })

    def test_hard_edges_exclude_diagonals(self):
        self.assertEqual(len(edges(box((1, 1, 1), 0))), 12)

    def test_edge_wear_baked(self):
        self.recipe['materials']['m'].update(edge_wear=0.8, edge_width=0.06)
        result = build(self.recipe, self.root, self.root / 'out', render='none')
        self.assertTrue(any((m.get('edge_wear', {}).get('painted_texels', 0) for m in result['materials'].values())))
        self.assertTrue(audit(self.root / 'out')['ok'])

    def test_wear_requires_unique_uv(self):
        self.recipe['materials']['m']['edge_wear'] = 0.5
        self.recipe['parts'][0]['uv'] = 'metric'
        with self.assertRaises(ValueError):
            validate(self.recipe)

    def test_scalar_map_packing(self):
        for name, val in [('ao', 220), ('rough', 70), ('metal', 165)]:
            self.img(name + '.png', (val, val, val))
        maps, _ = make(
            {'kind': 'solid', 'ao_map': 'ao.png', 'rough_map': 'rough.png', 'metal_map': 'metal.png'},
            self.root / 'maps',
            64,
            42,
            self.root
        )
        np.testing.assert_allclose(np.asarray(Image.open(maps['orm']))[20, 20], [220, 70, 165])

    def test_ambiguous_orm_rejected(self):
        self.recipe['materials']['m'].update(orm='a.png', rough_map='b.png')
        with self.assertRaises(ValueError):
            validate(self.recipe)

    def test_directx_green_flip(self):
        self.img('normal.png', (128, 190, 245))
        maps, _ = make(
            {'kind': 'solid', 'normal': 'normal.png', 'normal_y': 'directx'},
            self.root / 'maps',
            64,
            42,
            self.root
        )
        self.assertEqual(np.asarray(Image.open(maps['normal']))[10, 10, 1], 65)

    def test_solid_baked_color_consistency(self):
        cfg = {'kind': 'solid', 'color': [0.25, 0.5, 0.75]}
        maps, _ = make(cfg, self.root / 'maps', 64, 42, self.root)
        pixel = np.asarray(Image.open(maps['base']))[10, 10] / 255
        np.testing.assert_allclose(pixel, srgb(color(cfg, 'linear')), atol=1 / 255)

    def test_explicit_srgb_solid(self):
        self.recipe['materials']['m'] = {'kind': 'solid', 'color': [0.3, 0.3, 0.3], 'color_space': 'srgb'}
        build(self.recipe, self.root, self.root / 'out', render='none')
        g = GLB.load(self.root / 'out/model.glb')
        value = g.j['materials'][0]['pbrMetallicRoughness']['baseColorFactor'][0]
        self.assertAlmostEqual(value, 0.07323896, places=6)

    def test_emissive_embedded_and_rendered(self):
        a = np.zeros((32, 32, 3), np.uint8)
        a[:, :16, 0] = 255
        Image.fromarray(a).save(self.root / 'emit.png')
        self.recipe['materials']['m'] = {
            'kind': 'solid',
            'color': [0, 0, 0],
            'emissive': 'emit.png',
            'emission': [1, 0, 0]
        }
        self.recipe['parts'][0].pop('uv')
        build(self.recipe, self.root, self.root / 'out', render='none')
        g = GLB.load(self.root / 'out/model.glb')
        self.assertIn('emissiveTexture', g.j['materials'][0])
        cpu(self.root / 'out/model.glb', self.root / 'emit_view.png', 96, 0, elev=0, mode='emission')
        a = np.asarray(Image.open(self.root / 'emit_view.png'))
        self.assertGreater(a[48, 26, 0], 220)
        self.assertLess(a[48, 70, 0], 10)

    def test_sampling_clamp_repeat_mirror(self):
        a = np.array([[[1.0, 0, 0], [0, 1.0, 0]]])
        uv = np.array([[1.25, 0.5]])
        for mode, expected in [(10497, [1, 0, 0]), (33071, [0, 1, 0]), (33648, [0, 1, 0])]:
            tx = {'pixels': a, 's': mode, 't': 33071, 'nearest': True}
            np.testing.assert_allclose(sample(tx, uv, [0, 0, 0])[0], expected)

    def test_orm_red_is_not_implicit_ao(self):
        self.model()
        g = GLB.load(self.root / 'source.glb')
        results = []
        for red in [0, 255]:
            raw = io.BytesIO()
            Image.new('RGB', (4, 4), (red, 180, 0)).save(raw, format='PNG')
            tx = g.texture(raw.getvalue(), 'orm')
            g.j['materials'][0]['pbrMetallicRoughness']['metallicRoughnessTexture'] = {'index': tx}
            g.save(self.root / 'x.glb')
            cpu(self.root / 'x.glb', self.root / f'ao_{red}.png', size=64)
            results.append(np.asarray(Image.open(self.root / f'ao_{red}.png')))
        np.testing.assert_array_equal(*results)

    def test_normal_scale_zero(self):
        self.img('n.png', (230, 128, 195))
        self.recipe['materials']['m'].update(normal='n.png', normal_scale=0)
        build(self.recipe, self.root, self.root / 'out', render='none')
        cpu(self.root / 'out/model.glb', self.root / 'n.png', size=96, angle=0, elev=0, mode='normal')
        a = np.asarray(Image.open(self.root / 'n.png'))
        np.testing.assert_allclose(a[48, 48], [128, 128, 255], atol=2)

    def test_retexture_isolates_instance(self):
        self.model()
        run(self.job(), self.root, self.root / 'out', draw=False)
        g = GLB.load(self.root / 'out/model.glb')
        a, b = [g.j['meshes'][n['mesh']]['primitives'][0]['material'] for n in g.j['nodes'][:2]]
        self.assertNotEqual(a, b)
        self.assertEqual(b, 0)
        self.assertTrue(audit(self.root / 'out')['ok'])

    def test_retexture_replay(self):
        self.model()
        run(self.job('atlas'), self.root, self.root / 'out', draw=False)
        task = json.loads((self.root / 'out/task.json').read_text())
        run(task, self.root / 'out', self.root / 'again', draw=False)
        self.assertEqual(
            inspect(self.root / 'out/model.glb')['materials'],
            inspect(self.root / 'again/model.glb')['materials']
        )

    def test_retexture_uv_missing_fails(self):
        self.model(False)
        with self.assertRaises(ValueError):
            run(self.job(), self.root, self.root / 'out', draw=False)
        self.assertFalse((self.root / 'out').exists())

    def test_retexture_generates_uv(self):
        self.model(False)
        job = self.job('atlas')
        job['assign'][0]['node'] = '*'
        run(job, self.root, self.root / 'out', draw=False)
        self.assertTrue(inspect(self.root / 'out/model.glb')['ok'])

    def test_texture_asset_path_rejected(self):
        self.model()
        job = self.job()
        job['materials']['m'] = {'kind': 'image', 'image': '../bad.png'}
        with self.assertRaises(ValueError):
            run(job, self.root, self.root / 'out', draw=False)

    def test_texture_extract_matches_glb(self):
        build(self.recipe, self.root, self.root / 'out', render='none')
        result = inspect(self.root / 'out/model.glb', self.root / 'textures')
        self.assertEqual(result['embedded_images_used'], 3)
        g = GLB.load(self.root / 'out/model.glb')
        for item in result['materials']:
            for m in item['maps'].values():
                self.assertEqual((self.root / 'textures' / m['file']).read_bytes(), g.image_bytes(m['image']))
        self.assertTrue((self.root / 'textures/contact.png').exists())

    def test_swatch_crop_and_provenance(self):
        self.img('photo.png', (100, 150, 200))
        result = swatch(self.root / 'photo.png', self.root / 'swatch', crop=[0, 0, 0.5, 0.5], size=64)
        self.assertEqual(result['selected_size'], (8, 8))
        self.assertTrue(result['source_sha256'])
        self.assertTrue(result['notes'])

    def test_swatch_bad_crop(self):
        self.img('photo.png')
        with self.assertRaises(ValueError):
            swatch(self.root / 'photo.png', self.root / 'swatch', crop=[0.8, 0, 0.8, 1])

    def test_swatch_tile_edges(self):
        a = np.random.default_rng(2).integers(0, 255, (32, 32, 3), dtype=np.uint8)
        Image.fromarray(a).save(self.root / 'photo.png')
        swatch(self.root / 'photo.png', self.root / 'out', size=64, tile=True)
        a = np.asarray(Image.open(self.root / 'out/color.png'))
        np.testing.assert_allclose(a[:, 0], a[:, -1], atol=1)
        np.testing.assert_allclose(a[0], a[-1], atol=1)

    def test_projected_polygon_on_prism(self):
        self.recipe['parts'][0] = {
            'name': 'body',
            'shape': 'prism',
            'points': [[-0.5, -0.5], [0.5, -0.5], [0.3, 0.5], [-0.3, 0.5]],
            'depth': 0.2,
            'uv': 'atlas',
            'mat': 'm',
            'decals': [{
                'kind': 'polygon',
                'side': 'front',
                'points': [[0, 0], [1, 0], [0.5, 1]],
                'color': [1, 0, 0]
            }]
        }
        result = build(self.recipe, self.root, self.root / 'out', render='none')
        self.assertEqual(result['projected_decals'], 1)

    def test_review_views(self):
        self.model()
        result = render(self.root / 'source.glb', self.root / 'views', size=64, review=True)
        self.assertEqual(len(result), 8)
        self.assertTrue((self.root / 'views/base.png').exists())
        self.assertTrue((self.root / 'views/top.png').exists())

    def test_many_solids_do_not_allocate_maps(self):
        self.recipe['texture_size'] = 2048
        self.recipe['materials'] = {f'm{i}': {'kind': 'solid', 'color': [0.2, 0.3, 0.4]} for i in range(32)}
        self.recipe['parts'][0]['mat'] = 'm0'
        build(self.recipe, self.root, self.root / 'out', render='none')
        g = GLB.load(self.root / 'out/model.glb')
        self.assertEqual(len(g.j.get('images', [])), 0)

    def test_image_layer_tint(self):
        from agent.mats import layer
        self.img('color.png', (200, 100, 50))
        im = layer({'kind': 'image', 'image': 'color.png', 'tint': [0.5, 1, 0.2]}, 16, 16, 0, self.root)
        np.testing.assert_array_equal(np.asarray(im)[8, 8], [100, 100, 10, 255])

    def test_speckle_seed_is_repeatable(self):
        from agent.mats import layer
        cfg = {'kind': 'speckle', 'count': 12, 'seed': 32}
        a = np.asarray(layer(cfg, 128, 128, 1, self.root))
        b = np.asarray(layer(cfg, 128, 128, 2, self.root))
        np.testing.assert_array_equal(a, b)
        self.assertGreater(a[..., 3].std(), 1)

    def test_polygon_requires_points(self):
        self.recipe['materials']['m']['layers'] = [{'kind': 'polygon'}]
        with self.assertRaises(ValueError):
            validate(self.recipe)

    def test_cpu_vertex_color(self):
        self.model()
        g = GLB.load(self.root / 'source.glb')
        for m in g.j['materials']:
            m['pbrMetallicRoughness']['baseColorFactor'] = [1, 1, 1, 1]
        prim = g.j['meshes'][0]['primitives'][0]
        count = g.j['accessors'][prim['attributes']['POSITION']]['count']
        prim['attributes']['COLOR_0'] = g.accessor(
            np.tile([1.0, 0.0, 0.0], (count, 1)).astype(np.float32),
            'VEC3'
        )
        g.save(self.root / 'color.glb')
        cpu(self.root / 'color.glb', self.root / 'view.png', 96, angle=0, elev=0, mode='base')
        a = np.asarray(Image.open(self.root / 'view.png'))
        red = (a[..., 0] > 200) & (a[..., 1] < 10) & (a[..., 2] < 10)
        self.assertGreater(red.sum(), 100)

    def test_retexture_external_image_replay(self):
        self.model()
        self.img('new.png', (150, 60, 10))
        job = self.job('atlas')
        job['materials']['m'] = {'kind': 'image', 'image': 'new.png'}
        run(job, self.root, self.root / 'out', draw=False)
        (self.root / 'new.png').unlink()
        task = json.loads((self.root / 'out/task.json').read_text())
        run(task, self.root / 'out', self.root / 'again', draw=False)
        self.assertEqual(
            inspect(self.root / 'out/model.glb')['materials'],
            inspect(self.root / 'again/model.glb')['materials']
        )

    def test_float_height_range_rejected(self):
        Image.fromarray(np.full((8, 8), 2.0, np.float32)).save(self.root / 'height.tiff')
        with self.assertRaises(ValueError):
            make({'kind': 'solid', 'height': 'height.tiff'}, self.root / 'maps', 64, 2, self.root)

    def test_quality_profile_honors_overrides(self):
        from agent.presets import quality
        r = quality(self.recipe, 'high')
        self.assertEqual(r['texture_size'], 64)
        self.assertEqual(r['max_triangles'], 100000)

    def test_startup_embeds_textures(self):
        from agent.state import doctor
        r = doctor(smoke=True)
        self.assertTrue(r['ok'])
        self.assertEqual(r['smoke_test']['embedded_images'], 3)

    def test_sampler_absent_uses_default_repeat(self):
        from agent.preview import tex
        g = GLB()
        raw = io.BytesIO()
        Image.new('RGB', (4, 4), (90, 120, 150)).save(raw, format='PNG')
        tx = g.texture(raw.getvalue(), 'x')
        g.j['samplers'] = [{'wrapS': 33071, 'wrapT': 33071}]
        g.j['textures'][tx].pop('sampler', None)
        t = tex(g, {'index': tx})
        self.assertEqual(t['s'], 10497)
        self.assertEqual(t['t'], 10497)

    def test_vertex_alpha_mask(self):
        self.model()
        g = GLB.load(self.root / 'source.glb')
        g.j['materials'][0]['alphaMode'] = 'MASK'
        prim = g.j['meshes'][0]['primitives'][0]
        count = g.j['accessors'][prim['attributes']['POSITION']]['count']
        prim['attributes']['COLOR_0'] = g.accessor(
            np.tile([1.0, 0.0, 0.0, 0.0], (count, 1)).astype(np.float32),
            'VEC4'
        )
        g.save(self.root / 'alpha.glb')
        cpu(self.root / 'alpha.glb', self.root / 'view.png', 96, mode='base')
        a = np.asarray(Image.open(self.root / 'view.png'))
        self.assertLess(a[..., 0].max(), 70)
if __name__ == '__main__':
    unittest.main()
