"""Regression tests for the CLI foundations, geometry, imports, and safe outputs."""

from __future__ import annotations
import copy
import json
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from PIL import Image
from agent.build import audit, build
from agent.files import join, load, unpack
from agent.preview import render
from agent.schema import validate
from agent.state import ROOT, doctor, output_path, safe
from agent.work import edit, pack, relief, run
from core.mesh import GLB, box, node_matrix
from core.validate import check


class KitTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='ai3d-test-')
        self.root = Path(self.tmp.name)
        self.data = {
            'schema': 'ai3d.recipe/1',
            'name': 'Box',
            'texture_size': 64,
            'lods': [1],
            'materials': {'solid': {'kind': 'solid', 'color': [0.3, 0.5, 0.7]}},
            'parts': [{'name': 'box', 'shape': 'box', 'mat': 'solid', 'size': [1, 2, 3]}]
        }

    def tearDown(self):
        self.tmp.cleanup()

    def model(self, name='source.glb'):
        g = GLB()
        g.material('solid')
        g.add_mesh('box', box((1, 2, 3), 0), 'solid')
        path = g.save(self.root / name)
        return (g, path)

    def image(self, name='height.png', rgb=False):
        y, x = np.mgrid[-1:1:20j, -1:1:24j]
        a = np.uint16(np.exp(-(x * x + y * y) * 4) * 65535)
        im = Image.fromarray(a)
        if rgb:
            im = im.convert('RGB')
        path = self.root / name
        im.save(path)
        return path

    def test_boot(self):
        result = doctor(smoke=True)
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['smoke_test']['renders'], 3)

    def test_build_solid_without_textures(self):
        result = build(self.data, self.root, self.root / 'out', size=96)
        self.assertTrue(result['ok'])
        self.assertFalse((self.root / 'out/textures').exists())
        self.assertEqual(result['lods'][0]['rendered_triangles'], 12)
        self.assertTrue((self.root / 'out/views/hero.png').is_file())
        self.assertTrue(audit(self.root / 'out')['ok'])

    def test_cache(self):
        out = self.root / 'out'
        build(self.data, self.root, out, render='none')
        result = build(self.data, self.root, out, render='none')
        self.assertTrue(result['cached'])

    def test_existing_output_protected(self):
        out = self.root / 'out'
        out.mkdir()
        (out / 'keep.txt').write_text('keep')
        with self.assertRaises(FileExistsError):
            build(self.data, self.root, out, render='none')
        self.assertEqual((out / 'keep.txt').read_text(), 'keep')

    def test_output_not_inside_kit(self):
        with self.assertRaises(ValueError):
            output_path(ROOT / 'out')

    def test_unknown_recipe_fields(self):
        self.data['parts'][0]['magic'] = True
        with self.assertRaises(ValueError):
            validate(self.data)

    def test_nonfinite_recipe(self):
        self.data['parts'][0]['pos'] = [float('nan'), 0, 0]
        with self.assertRaises(ValueError):
            validate(self.data)

    def test_triangle_budget(self):
        self.data['parts'][0]['bevel'] = 0.05
        self.data['max_triangles'] = 12
        with self.assertRaises(ValueError):
            build(self.data, self.root, self.root / 'out', render='none')
        self.assertFalse((self.root / 'out').exists())

    def test_shared_geometry(self):
        self.data['parts'].append({**self.data['parts'][0], 'name': 'other', 'pos': [3, 0, 0]})
        result = build(self.data, self.root, self.root / 'out', render='none')
        row = result['lods'][0]
        self.assertEqual(row['rendered_triangles'], 24)
        self.assertEqual(row['stored_triangles'], 12)

    def test_lods(self):
        self.data['lods'] = [1, 0.5]
        self.data['parts'] = [{
            'name': 'ball',
            'shape': 'sphere',
            'mat': 'solid',
            'radius': 1,
            'steps': 24,
            'rings': 16
        }]
        result = build(self.data, self.root, self.root / 'out', render='none')
        self.assertGreater(result['lods'][0]['rendered_triangles'], result['lods'][1]['rendered_triangles'])

    def test_primitives(self):
        specs = [
            {'shape': 'box', 'size': [1, 1, 1], 'bevel': 0.05},
            {'shape': 'cylinder', 'radius': 0.5, 'length': 1, 'steps': 12},
            {'shape': 'sphere', 'radius': 0.5, 'steps': 12, 'rings': 8},
            {'shape': 'ellipsoid', 'size': [1, 2, 1], 'steps': 12, 'rings': 8},
            {'shape': 'torus', 'radius': 0.5, 'tube': 0.1, 'steps': 12, 'rings': 8},
            {'shape': 'bowl', 'size': [1, 0.5, 1], 'depth': 0.02, 'steps': 12, 'rings': 4},
            {'shape': 'lathe', 'profile': [[0, -0.5], [0.5, -0.5], [0.4, 0.5], [0, 0.5]], 'steps': 12},
            {'shape': 'hose', 'points': [[0, 0, 0], [0, 1, 0], [1, 2, 0]], 'samples': 8, 'steps': 8},
            {'shape': 'plate', 'points': [[0, 0], [1, 0], [1, 1], [0, 1]], 'depth': 0.1},
            {'shape': 'mesh', 'v': [[0, 0, 0], [1, 0, 0], [0, 1, 0]], 'f': [[0, 1, 2]]}
        ]
        for i, spec in enumerate(specs):
            with self.subTest(shape=spec['shape']):
                data = copy.deepcopy(self.data)
                data['parts'] = [{'name': 'part', 'mat': 'solid', **spec}]
                result = build(data, self.root, self.root / f'out{i}', render='none')
                self.assertTrue(result['ok'])

    def test_procedural_material(self):
        self.data['materials']['solid'] = {'kind': 'wood', 'bump': 0.001}
        result = build(self.data, self.root, self.root / 'out', render='none')
        self.assertTrue(result['ok'])
        self.assertEqual(len(GLB.load(self.root / 'out/model.glb').j['images']), 3)

    def test_supplied_image_material(self):
        self.image('color.png', rgb=True)
        self.data['materials']['solid'] = {'kind': 'image', 'image': 'color.png'}
        build(self.data, self.root, self.root / 'out', render='none')
        self.assertTrue(audit(self.root / 'out')['ok'])
        recipe = json.loads((self.root / 'out/recipe.json').read_text())
        self.assertTrue((self.root / 'out' / recipe['materials']['solid']['image']).is_file())

    def test_sculpt(self):
        data = json.loads((ROOT / 'examples/sculpt.json').read_text())
        result = build(data, self.root, self.root / 'out', render='none')
        self.assertTrue(result['sculpt'])
        self.assertTrue((self.root / 'out/before.glb').is_file())

    def test_stamp(self):
        self.data['stamps'] = {'dent': {'kind': 'dent', 'size': 64}}
        self.data['parts'][0].update(
            uv='box',
            stamps=[{'stamp': 'dent', 'side': 'front', 'mode': 'carve', 'depth': 0.08, 'res': 8}]
        )
        result = build(self.data, self.root, self.root / 'out', render='none')
        self.assertTrue(result['stamps'])
        self.assertGreater(result['lods'][0]['rendered_triangles'], 12)

    def test_audit_changed_file(self):
        out = self.root / 'out'
        build(self.data, self.root, out, render='none')
        (out / 'recipe.json').write_text('{}')
        self.assertFalse(audit(out)['ok'])

    def test_pack(self):
        out = self.root / 'out'
        build(self.data, self.root, out, render='none')
        result = pack(out, self.root / 'project.zip')
        self.assertTrue(result['ok'])
        with zipfile.ZipFile(result['file']) as z:
            self.assertIn('out/model.glb', z.namelist())
        with self.assertRaises(FileExistsError):
            pack(out, self.root / 'project.zip')

    def test_glb_import(self):
        g, path = self.model()
        result = run(
            {'schema': 'ai3d.task/1', 'name': 'Imported', 'op': 'import', 'model': path.name},
            self.root,
            self.root / 'out',
            draw=False
        )
        self.assertEqual(result['lods'][0]['rendered_triangles'], 12)
        self.assertTrue((self.root / 'out/assets/source.glb').is_file())

    def test_replay_task(self):
        _, path = self.model()
        job = {
            'schema': 'ai3d.task/1',
            'name': 'Moved',
            'op': 'import',
            'model': path.name,
            'pos': [2, 0, 0],
            'scale': [2, 2, 2]
        }
        run(job, self.root, self.root / 'out', draw=False)
        saved = json.loads((self.root / 'out/task.json').read_text())
        run(saved, self.root / 'out', self.root / 'again', draw=False)
        a, b = (check(self.root / 'out/model.glb'), check(self.root / 'again/model.glb'))
        np.testing.assert_allclose(a['bounds_m'], b['bounds_m'])

    def test_edit_material_isolated(self):
        g, _ = self.model()
        g.group('instance', mesh=0, pos=(3, 0, 0))
        edit(g, [{'node': 'box', 'color': [1, 0, 0, 1], 'pos': [0, 1, 0]}])
        self.assertNotEqual(g.j['nodes'][0]['mesh'], g.j['nodes'][1]['mesh'])
        self.assertEqual(g.j['meshes'][0]['primitives'][0]['material'], 0)
        self.assertEqual(g.j['materials'][1]['pbrMetallicRoughness']['baseColorFactor'], [1, 0, 0, 1])
        self.assertAlmostEqual(node_matrix(g.j['nodes'][0])[1, 3], 1)

    def test_bad_node_selection(self):
        g, _ = self.model()
        with self.assertRaises(ValueError):
            edit(g, [{'node': 'missing', 'rough': 0.1}])

    def test_assembly(self):
        _, path = self.model()
        job = {
            'schema': 'ai3d.task/1',
            'name': 'Pair',
            'op': 'assemble',
            'items': [
                {'name': 'left', 'model': path.name},
                {'name': 'right', 'model': path.name, 'pos': [2, 0, 0]}
            ]
        }
        result = run(job, self.root, self.root / 'out', draw=False)
        self.assertEqual(result['lods'][0]['rendered_triangles'], 24)
        np.testing.assert_allclose(result['lods'][0]['dimensions_m'], [3, 2, 3])

    def test_assembly_textures(self):
        self.data['materials']['solid'] = {'kind': 'wood'}
        build(self.data, self.root, self.root / 'first', render='none')
        g = GLB.load(self.root / 'first/model.glb')
        dst = GLB()
        join(dst, g, 'a')
        join(dst, g, 'b', pos=[2, 0, 0])
        path = dst.save(self.root / 'combined.glb')
        self.assertTrue(check(path)['passed'])
        self.assertEqual(len(dst.j['images']), 6)

    def test_missing_normals_and_material(self):
        g, path = self.model()
        prim = g.j['meshes'][0]['primitives'][0]
        prim['attributes'].pop('NORMAL')
        prim.pop('material')
        g.j['materials'] = []
        g.save(path)
        render(path, self.root / 'views', size=96)
        self.assertTrue((self.root / 'views/hero.png').is_file())

    def test_reject_animation(self):
        g, path = self.model()
        g.j['animations'] = [{'name': 'unsupported'}]
        g.save(path)
        with self.assertRaises(ValueError):
            load(path)

    def test_reject_texture_transform(self):
        g, path = self.model()
        g.j['materials'][0]['extensions'] = {'KHR_materials_unlit': {}}
        g.save(path)
        with self.assertRaises(ValueError):
            load(path)

    def test_height_relief(self):
        path = self.image()
        g = relief(path, {'mode': 'height', 'res': 12})
        dst = g.save(self.root / 'relief.glb')
        valid = check(dst)
        self.assertTrue(valid['passed'])
        self.assertGreater(valid['dimensions_m'][2], 0.03)

    def test_height_rejects_rgb(self):
        path = self.image('rgb.png', rgb=True)
        with self.assertRaises(ValueError):
            relief(path, {'mode': 'height', 'res': 12})

    def test_brightness_explicit(self):
        path = self.image('rgb.png', rgb=True)
        result = run(
            {
                'schema': 'ai3d.task/1',
                'name': 'Relief',
                'op': 'relief',
                'image': path.name,
                'mode': 'brightness',
                'res': 12
            },
            self.root,
            self.root / 'out',
            draw=False
        )
        self.assertTrue(any(('artistic' in text for text in result['limitations'])))

    def test_relief_color(self):
        path = self.image()
        color = self.image('color.png', rgb=True)
        g = relief(path, {'mode': 'height', 'res': 12}, color)
        self.assertTrue(check(g.save(self.root / 'color.glb'))['passed'])
        self.assertEqual(len(g.j['images']), 1)

    def test_task_unknown_fields(self):
        _, path = self.model()
        with self.assertRaises(ValueError):
            run(
                {'schema': 'ai3d.task/1', 'name': 'No', 'op': 'import', 'model': path.name, 'mode': 'height'},
                self.root,
                self.root / 'out',
                draw=False
            )

    def test_asset_path_escape(self):
        with self.assertRaises(ValueError):
            safe(self.root, '../outside.png')
        with self.assertRaises(ValueError):
            safe(self.root, 'C:\\secret.png')

    def test_zip_asset(self):
        _, path = self.model()
        archive = self.root / 'input.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.write(path, 'assets/model.glb')
        result = unpack(archive, self.root / 'unpacked')
        self.assertTrue(result['ok'])
        self.assertTrue((self.root / 'unpacked/assets/model.glb').is_file())

    def test_zip_traversal(self):
        archive = self.root / 'bad.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.writestr('../escape.txt', 'bad')
        with self.assertRaises(ValueError):
            unpack(archive, self.root / 'unpacked')
        self.assertFalse((self.root / 'unpacked').exists())

    def test_zip_symlink(self):
        archive = self.root / 'bad.zip'
        info = zipfile.ZipInfo('link.txt')
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 511) << 16
        with zipfile.ZipFile(archive, 'w') as z:
            z.writestr(info, '/etc/passwd')
        with self.assertRaises(ValueError):
            unpack(archive, self.root / 'unpacked')

    def test_zip_case_collision(self):
        archive = self.root / 'bad.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.writestr('A.txt', 'a')
            z.writestr('a.txt', 'b')
        with self.assertRaises(ValueError):
            unpack(archive, self.root / 'unpacked')

    def test_zip_skips_os_metadata(self):
        _, path = self.model()
        archive = self.root / 'input.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.write(path, 'model.glb')
            z.writestr('__MACOSX/._model.glb', 'metadata')
            z.writestr('.DS_Store', 'metadata')
        result = unpack(archive, self.root / 'unpacked')
        self.assertEqual(len(result['files']), 1)

    def test_relief_is_closed_after_vertex_weld(self):
        try:
            import trimesh
        except ImportError:
            self.skipTest('Optional trimesh is not installed.')
        path = self.image()
        g = relief(path, {'mode': 'height', 'res': 12})
        model = g.save(self.root / 'relief.glb')
        mesh = trimesh.load_mesh(model, process=True)
        mesh.merge_vertices(merge_tex=True, merge_norm=True)
        self.assertTrue(mesh.is_watertight)
        self.assertTrue(mesh.is_winding_consistent)
        self.assertGreater(mesh.volume, 0)

    def test_imported_budget_preserves_input(self):
        g, path = self.model()
        g.group('instance', mesh=0, pos=(3, 0, 0))
        g.save(path)
        raw = path.read_bytes()
        with self.assertRaises(ValueError):
            run(
                {'schema': 'ai3d.task/1', 'name': 'Too_Large', 'op': 'import', 'model': path.name},
                self.root,
                self.root / 'out',
                draw=False,
                limit=12
            )
        self.assertEqual(raw, path.read_bytes())
        self.assertFalse((self.root / 'out').exists())

    def test_cli_failure_status(self):
        result = subprocess.run(
            [sys.executable, str(ROOT / 'kit.py'), 'inspect', str(self.root / 'missing.glb')],
            capture_output=True,
            text=True
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)['ok'])

    def test_optional_imports(self):
        try:
            import trimesh
        except ImportError:
            self.skipTest('Optional trimesh is not installed.')
        for ext in ['obj', 'stl', 'ply']:
            with self.subTest(ext=ext):
                path = self.root / f'box.{ext}'
                trimesh.creation.box(extents=(1, 2, 3)).export(path)
                g, _ = load(path)
                valid = check(g.save(self.root / f'{ext}.glb'))
                self.assertTrue(valid['passed'], valid)
                np.testing.assert_allclose(valid['dimensions_m'], [1, 2, 3])
if __name__ == '__main__':
    unittest.main(verbosity=2)
