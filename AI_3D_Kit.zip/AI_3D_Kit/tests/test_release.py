"""Release regressions for provenance, packaging, code hygiene, and browser fallback.

These checks are narrow guardrails, not a full security or source-similarity audit.
"""

from __future__ import annotations

import ast
import hashlib
import html
import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from agent import DATE, VERSION
from agent import state
from agent.preview import page
from core.mesh import GLB, box
from tools import release

ROOT = Path(__file__).resolve().parents[1]


class ReleaseTests(unittest.TestCase):
    """Exercise source packaging separately from model-project packaging."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name)
        self.root = self.home / 'source'
        self.root.mkdir()
        (self.root / 'agent').mkdir()
        (self.root / 'agent' / '__init__.py').write_text('VERSION = "fixture"\n')
        (self.root / 'README.md').write_text('# Fixture\n')
        (self.root / 'LICENSE').write_text('Fixture license.\n')
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(state, 'ROOT', self.root))
        self.stack.enter_context(patch.object(release, 'ROOT', self.root))

    def refresh(self):
        """Create a fixture manifest using the real release inventory code."""
        state.write(self.root / 'MANIFEST.json', release.manifest())

    def test_version_single_source(self):
        self.assertEqual(GLB().j['asset']['generator'], f'AI 3D Kit {VERSION}')
        result = subprocess.run(
            [sys.executable, '-B', str(ROOT / 'kit.py'), '--version'],
            capture_output=True, text=True, check=True,
        )
        self.assertEqual(result.stdout.strip(), VERSION)

    def test_manifest_includes_docs_and_ci(self):
        for name in ['docs/legal/notice.md', '.github/workflows/checks.yml']:
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('fixture\n')
        inventory = state.code_files()
        self.assertIn('docs/legal/notice.md', inventory)
        self.assertIn('.github/workflows/checks.yml', inventory)
        self.assertIn('LICENSE', inventory)

    def test_modified_document_fails_verification(self):
        self.refresh()
        self.assertTrue(state.verify()['release_verified'])
        (self.root / 'README.md').write_text('changed\n')
        self.assertFalse(state.verify()['ok'])

    def test_wrong_manifest_version_fails(self):
        saved = release.manifest()
        saved['version'] = 'old-version'
        state.write(self.root / 'MANIFEST.json', saved)
        self.assertFalse(state.verify()['ok'])

    def test_no_manifest_is_not_packagable(self):
        self.assertFalse(state.verify()['release_verified'])
        with self.assertRaises(ValueError):
            release.pack(self.home / 'out.zip')

    def test_caches_local_secrets_and_outputs_excluded(self):
        (self.root / '.env').write_text('local only\n')
        (self.root / 'agent' / '__pycache__').mkdir()
        (self.root / 'agent' / '__pycache__' / 'fixture.pyc').write_bytes(b'cache')
        (self.root / 'output.glb').write_bytes(b'not source')
        inventory = state.code_files()
        self.assertNotIn('.env', inventory)
        self.assertFalse(any('__pycache__' in name for name in inventory))
        self.assertNotIn('output.glb', inventory)

    def test_private_file_in_package_rejected(self):
        (self.root / 'agent' / 'private.key').write_text('private fixture\n')
        with self.assertRaises(ValueError):
            state.code_files()

    def test_environment_file_in_package_rejected(self):
        (self.root / 'agent' / '.env.local').write_text('private fixture\n')
        with self.assertRaises(ValueError):
            state.code_files()

    def link(self, target, link, directory=False):
        try:
            link.symlink_to(target, target_is_directory=directory)
        except (OSError, NotImplementedError) as error:
            self.skipTest(f'Symlink creation is unavailable: {error}')

    def test_source_file_symlink_rejected(self):
        file = self.home / 'outside.py'
        file.write_text('x = 1\n')
        self.link(file, self.root / 'agent' / 'linked.py')
        with self.assertRaises(ValueError):
            state.code_files()

    def test_source_directory_symlink_rejected(self):
        folder = self.home / 'outside'
        folder.mkdir()
        self.link(folder, self.root / 'agent' / 'linked', True)
        with self.assertRaises(ValueError):
            state.code_files()

    def test_zip_is_deterministic_and_manifest_limited(self):
        self.refresh()
        one, two = self.home / 'one.zip', self.home / 'two.zip'
        release.pack(one)
        release.pack(two)
        self.assertEqual(one.read_bytes(), two.read_bytes())
        with zipfile.ZipFile(one) as archive:
            expected = {'AI_3D_Kit/' + p for p in state.code_files()} | {'AI_3D_Kit/MANIFEST.json'}
            self.assertEqual(set(archive.namelist()), expected)
            for item in archive.infolist():
                self.assertEqual(item.date_time[:3], tuple(map(int, DATE.split('-'))))
                self.assertEqual(item.external_attr >> 16 & 0o777, 0o644)

    def test_pack_does_not_overwrite_existing_zip(self):
        self.refresh()
        out = self.home / 'out.zip'
        out.write_bytes(b'keep')
        with self.assertRaises(FileExistsError):
            release.pack(out)
        self.assertEqual(out.read_bytes(), b'keep')

    def test_pack_rejects_output_inside_repository(self):
        self.refresh()
        with self.assertRaises(ValueError):
            release.pack(self.root / 'out.zip')

    def test_pack_rejects_non_zip_suffix(self):
        self.refresh()
        with self.assertRaises(ValueError):
            release.pack(self.home / 'out.tar')

    def test_refresh_resolves_intentional_change(self):
        self.refresh()
        (self.root / 'README.md').write_text('reviewed change\n')
        self.assertFalse(state.verify()['ok'])
        self.refresh()
        self.assertTrue(state.verify()['release_verified'])

    def test_unused_mesh_helpers_removed(self):
        tree = ast.parse((ROOT / 'core/mesh.py').read_text(encoding='utf-8'))
        names = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
        self.assertFalse(names & {'sphere', 'ellipsoid', 'bolt', 'loft', 'link', 'sha'})

    def test_unexposed_build_wrappers_removed(self):
        tree = ast.parse((ROOT / 'agent/build.py').read_text(encoding='utf-8'))
        names = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
        self.assertFalse(names & {'plan', 'build_file'})

    def test_no_inactive_accelerator_argument(self):
        for path in list((ROOT / 'agent').glob('*.py')) + list((ROOT / 'core').glob('*.py')):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    self.assertNotIn('accel', {arg.arg for arg in node.args.args}, str(path))

    def test_modules_have_documentation(self):
        paths = [ROOT / 'kit.py']
        for directory in ['agent', 'core', 'tools']:
            paths.extend((ROOT / directory).glob('*.py'))
        for path in paths:
            self.assertTrue(ast.get_docstring(ast.parse(path.read_text(encoding='utf-8'))), str(path))

    def test_no_unused_imports_in_current_modules(self):
        paths = [ROOT / 'kit.py']
        for directory in ['agent', 'core', 'tools', 'tests']:
            paths.extend((ROOT / directory).glob('*.py'))
        for path in paths:
            tree = ast.parse(path.read_text(encoding='utf-8'))
            used = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)}
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.ImportFrom) and node.module == '__future__':
                        continue
                    for item in node.names:
                        name = item.asname or item.name.split('.')[0]
                        self.assertIn(name, used, f'{path.name}: {name}')

    def test_markdown_local_links_resolve(self):
        for path in ROOT.rglob('*.md'):
            for target in re.findall(r'\]\(([^)\s]+)(?:\s+[^)]*)?\)', path.read_text(encoding='utf-8')):
                if target.startswith(('http:', 'https:', '#', 'mailto:')):
                    continue
                target = target.split('#')[0]
                self.assertTrue((path.parent / target).exists(), f'{path.relative_to(ROOT)}: {target}')

    def test_example_asset_hash_and_origin(self):
        data = json.loads((ROOT / 'docs/assets.json').read_text(encoding='utf-8'))
        for item in data['included']:
            self.assertEqual(hashlib.sha256((ROOT / item['file']).read_bytes()).hexdigest(), item['sha256'])
            self.assertEqual(item['source_image_inputs'], [])
            self.assertEqual(hashlib.sha256((ROOT / item['recipe']).read_bytes()).hexdigest(), item['recipe_sha256'])
        for name in ['reference.png', 'model.png', 'textures.png', 'inspection.png']:
            self.assertFalse((ROOT / 'docs/images' / name).exists())

    def test_source_lineage_is_compact_and_versioned(self):
        data = json.loads((ROOT / 'docs/provenance.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema'], 'ai3d.provenance/2')
        self.assertEqual(data['release'], VERSION)
        self.assertEqual(data['license'], 'MIT')
        self.assertEqual(data['inputs'][0]['files'], 163)
        for item in data['inputs']:
            self.assertRegex(item['sha256'], r'^[0-9a-f]{64}$')
        self.assertNotIn('prepared_for', data)
        self.assertNotIn('status', data)

    def test_project_license_is_mit(self):
        text = (ROOT / 'LICENSE').read_text(encoding='utf-8')
        self.assertTrue(text.startswith('MIT License\n'))
        self.assertIn('Copyright (c) 2026 AI 3D Kit contributors', text)
        self.assertIn('Permission is hereby granted, free of charge', text)
        self.assertIn('copies or substantial portions of the Software.', text)
        self.assertIn('THE SOFTWARE IS PROVIDED "AS IS"', text)

    def test_release_metadata_uses_no_personal_lead(self):
        tree = ast.parse((ROOT / 'agent/__init__.py').read_text(encoding='utf-8'))
        names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
        self.assertNotIn('LEAD', names)
        self.assertFalse((ROOT / 'AUTHORS.md').exists())
        self.assertFalse((ROOT / 'docs/AUDIT.md').exists())
        self.assertFalse((ROOT / 'docs/legal').exists())

    def test_public_docs_have_no_superseded_license_status(self):
        for name in ['README.md', 'START_HERE.md', 'AGENTS.md', 'PUBLISHING.md', 'CONTRIBUTING.md', 'THIRD_PARTY_NOTICES.md']:
            text = (ROOT / name).read_text(encoding='utf-8').lower()
            for phrase in ['license status pending', 'unresolved inherited', 'preparation candidate', 'prepared for:', 'project lead:']:
                self.assertNotIn(phrase, text, name)
            self.assertIn('mit', text, name)

    def test_dependency_notice_hashes(self):
        data = json.loads((ROOT / 'docs/dependencies.json').read_text(encoding='utf-8'))
        for item in data['components']:
            path = ROOT / item['notice_file']
            self.assertTrue(path.resolve().is_relative_to(ROOT / 'docs/licenses'))
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), item['sha256'])
            self.assertFalse(item['distribution_bundled'])
        required = {'numpy', 'scipy', 'Pillow', 'jsonschema', 'trimesh', 'Python'}
        self.assertTrue(required <= {item['name'] for item in data['components']})

    def test_notice_inventory_covers_all_copied_texts(self):
        data = json.loads((ROOT / 'docs/dependencies.json').read_text(encoding='utf-8'))
        indexed = {item['notice_file'] for item in data['components']}
        actual = {p.relative_to(ROOT).as_posix() for p in (ROOT / 'docs/licenses').glob('*.txt')}
        self.assertEqual(actual, indexed)

    def test_startup_prompt_matches_both_guides(self):
        prompt = (ROOT / 'CHATGPT_START.txt').read_text(encoding='utf-8').strip()
        for name in ['README.md', 'START_HERE.md']:
            self.assertIn(prompt, (ROOT / name).read_text(encoding='utf-8'))
        for term in ['AGENTS.md', 'python kit.py boot', 'hand placement', 'GLB', 'project ZIP']:
            self.assertIn(term, prompt)

    def test_readme_version_matches_cli(self):
        self.assertIn('Version ' + VERSION.removesuffix('-kit'), (ROOT / 'README.md').read_text(encoding='utf-8'))

    def test_exported_viewer_retains_software_notices(self):
        model = GLB()
        model.material('plain')
        model.add_mesh('box', box((1, 1, 1), 0), 'plain')
        path = model.save(self.home / 'model.glb')
        exported = Path(page(path, self.home, 'Notice fixture')).read_text(encoding='utf-8')
        decoded = html.unescape(exported)
        self.assertIn((ROOT / 'LICENSE').read_text(encoding='utf-8').strip(), decoded)
        self.assertIn('Krzysztof Narkowicz', decoded)
        self.assertIn('CC0-1.0', decoded)
        self.assertIn('knarkowicz.wordpress.com', decoded)

    def test_no_bundled_models_fonts_or_old_studio(self):
        forbidden = {'.ttf', '.otf', '.woff', '.woff2', '.glb', '.zip', '.pyd', '.so', '.dll'}
        for path in ROOT.rglob('*'):
            if '__pycache__' not in path.parts and path.is_file():
                self.assertNotIn(path.suffix.lower(), forbidden, str(path))
        for name in ['app.py', 'model.py', 'agent.py', 'adapters', 'characters', 'studio', 'requirements-native.txt']:
            self.assertFalse((ROOT / name).exists(), name)

    def test_viewer_shader_attribution(self):
        text = (ROOT / 'core/viewer.html').read_text(encoding='utf-8')
        self.assertIn('Krzysztof Narkowicz', text)
        self.assertIn('CC0', text)
        self.assertNotRegex(text, r'<script[^>]+src=')

    @unittest.skipUnless(shutil.which('node'), 'Node is optional for viewer syntax checks.')
    def test_viewer_javascript_syntax_and_no_webgl_fallback(self):
        text = (ROOT / 'core/viewer.html').read_text(encoding='utf-8')
        script = re.search(r'<script>([\s\S]*?)</script>', text).group(1)
        path = self.home / 'viewer.js'
        path.write_text(script)
        subprocess.run(['node', '--check', str(path)], check=True, capture_output=True)
        wrapper = self.home / 'fallback.js'
        wrapper.write_text(
            "const status = {};\n"
            "global.document = {getElementById: id => id === 'c' ? {getContext: () => null} : status};\n"
            "global.window = {addEventListener: () => {}};\n"
            + script
            + "\nif (!window.viewerError || !status.textContent.includes('WebGL 2')) process.exit(1);\n"
        )
        subprocess.run(['node', str(wrapper)], check=True, capture_output=True)


if __name__ == '__main__':
    unittest.main()
