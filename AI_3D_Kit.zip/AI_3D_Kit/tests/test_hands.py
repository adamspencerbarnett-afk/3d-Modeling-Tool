"""Regressions for explicit handedness, palm-side curl, and real exported geometry."""

from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation

from agent.build import audit, build
from agent.hands import anchor, check, expand, frame, meshes, spec
from agent.schema import validate
from core.mesh import GLB

ROOT = Path(__file__).resolve().parents[1]


def recipe():
    return json.loads((ROOT / 'examples' / 'hands.json').read_text())


class HandTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.home = Path(cls.tmp.name)
        cls.data = recipe()
        cls.project = cls.home / 'project'
        build(cls.data, ROOT / 'examples', cls.project, render='none')
        cls.model = cls.project / 'model.glb'

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_declared_hands_are_checked(self):
        row = check(self.model)
        self.assertTrue(row['ok'], row)
        self.assertEqual(row['checked'], 2)
        self.assertEqual(row['status'], 'checked')
        self.assertTrue(all(h['digit_count'] == 5 for h in row['hands']))

    def test_palm_inward_thumbs_forward(self):
        row = check(self.model)
        right, left = row['hands']
        self.assertGreater(right['palm_normal'][0], .98)
        self.assertLess(left['palm_normal'][0], -.98)
        self.assertGreater(right['thumb_direction'][2], .98)
        self.assertGreater(left['thumb_direction'][2], .98)

    def test_frame_is_proper_rotation_across_poses(self):
        for side in (-1, 1):
            for d, palm in [([0, -1, 0], [side, 0, 0]), ([0, -1, 0], [0, 0, 1]),
                            ([side, 0, 0], [0, 0, 1]), ([.4, -.7, .6], [0, 1, 0])]:
                m = frame([0, 0, 0], d, palm)
                np.testing.assert_allclose(m[:3, :3].T @ m[:3, :3], np.eye(3), atol=1e-12)
                self.assertAlmostEqual(np.linalg.det(m[:3, :3]), 1)

    def test_joint_pose_rotates_with_body(self):
        m = frame([0, .7, 0], [0, .4, 0], [1, 0, 0])
        r = Rotation.from_euler('xyz', [24, -37, 64], degrees=True).as_matrix()
        moved = frame(r @ [0, .7, 0], r @ [0, .4, 0], r @ [1, 0, 0])
        np.testing.assert_allclose(moved[:3, :3], r @ m[:3, :3], atol=1e-12)

    def test_zero_forearm_rejected(self):
        with self.assertRaises(ValueError):
            frame([0, 0, 0], [0, 0, 0], [1, 0, 0])

    def test_zero_palm_rejected(self):
        with self.assertRaises(ValueError):
            frame([0, 1, 0], [0, 0, 0], [0, 0, 0])

    def test_parallel_palm_rejected(self):
        for palm in ([0, -1, 0], [0, 1, 0], [.001, -1, 0]):
            with self.assertRaises(ValueError):
                frame([0, 1, 0], [0, 0, 0], palm)

    def test_reversed_finger_axis_rejected(self):
        with self.assertRaises(ValueError):
            frame([0, 1, 0], [0, 0, 0], [0, 0, 1], [0, 1, 0])

    def test_bent_wrist_supported(self):
        m = frame([0, 1, 0], [0, 0, 0], [1, 0, 0], [0, -1, 1])
        np.testing.assert_allclose(m[:3, 1], np.array([0, -1, 1]) / np.sqrt(2))

    def test_nonfinite_input_rejected(self):
        for value in (float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                frame([0, 1, 0], [0, value, 0], [0, 0, 1])

    def test_left_and_right_paths_are_exact_mirrors(self):
        cfg = copy.deepcopy(self.data['hands'][0])
        _, right = meshes(cfg)
        cfg['side'] = 'left'
        _, left = meshes(cfg)
        for name in right:
            np.testing.assert_allclose(np.asarray(right[name]) * [-1, 1, 1], left[name], atol=1e-12)

    def test_both_sides_have_positive_facing_normals(self):
        for side in ('left', 'right'):
            cfg = {**self.data['hands'][0], 'side': side}
            parts, _ = meshes(cfg)
            for mesh in parts.values():
                t = mesh.v[mesh.f]
                face = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
                dots = np.sum(face * mesh.n[mesh.f].mean(1), axis=1)
                self.assertTrue(np.all(dots > 0))

    def test_curl_stays_on_palm_side_for_every_supported_limit(self):
        for side in ('left', 'right'):
            for curl in (0, 28, 60):
                parts, paths = meshes({**self.data['hands'][0], 'side': side, 'curl': curl})
                self.assertEqual(len(paths), 5)
                for path in paths.values():
                    self.assertTrue(np.all(np.diff(np.asarray(path)[:, 2]) >= -1e-12))
                self.assertTrue(all(np.isfinite(m.v).all() for m in parts.values()))

    def test_no_input_recipe_mutation(self):
        before = recipe()
        expanded, records = expand(before)
        self.assertEqual(before, recipe())
        self.assertNotIn('hands', expanded)
        self.assertEqual(len(records), 2)
        validate(expanded)

    def test_missing_material_rejected(self):
        data = recipe()
        data['hands'][0]['armor_mat'] = 'missing'
        with self.assertRaises(ValueError):
            validate(data)

    def test_wrong_side_rejected(self):
        with self.assertRaises(ValueError):
            spec({**self.data['hands'][0], 'side': 'screen_left'})

    def test_unknown_hand_fields_rejected(self):
        with self.assertRaises(ValueError):
            spec({**self.data['hands'][0], 'guess': True})

    def test_negative_size_and_backward_curl_rejected(self):
        for change in ({'size': [-.075, .085, .03]}, {'curl': -10}, {'curl': 80}):
            with self.assertRaises(ValueError):
                spec({**self.data['hands'][0], **change})

    def test_impossible_palm_proportions_rejected(self):
        with self.assertRaises(ValueError):
            spec({**self.data['hands'][0], 'size': [.001, 1, .2]})

    def test_unknown_anchor_rejected(self):
        data = recipe()
        data['hands'][0]['wrist'] = {'part': 'missing'}
        with self.assertRaises(ValueError):
            validate(data)

    def test_anchor_uses_part_transform(self):
        part = {'name': 'arm', 'pos': [1, 2, 3], 'rot': [0, 0, 90], 'scale': [1, 2, 1]}
        actual = anchor({'part': 'arm', 'point': [0, 1, 0]}, parts={'arm': part})
        np.testing.assert_allclose(actual, [-1, 2, 3], atol=1e-12)

    def test_hand_name_collision_rejected(self):
        data = recipe()
        data['parts'].append({'name': 'R_hand_palm', 'shape': 'box', 'mat': 'metal'})
        with self.assertRaises(ValueError):
            validate(data)

    def test_duplicate_hand_name_rejected(self):
        data = recipe()
        data['hands'][1]['name'] = data['hands'][0]['name']
        with self.assertRaises(ValueError):
            validate(data)

    def test_part_budget_counts_expansion(self):
        data = recipe()
        data['parts'] += [{'name': f'box_{i}', 'shape': 'box', 'mat': 'metal'} for i in range(247)]
        with self.assertRaises(ValueError):
            validate(data)

    def test_anchor_cannot_disappear_at_lod(self):
        data = recipe()
        data['lods'] = [1, .5]
        data['parts'][0]['min_lod'] = .8
        with self.assertRaises(ValueError):
            validate(data)

    def test_saved_recipe_is_declarative(self):
        saved = json.loads((self.project / 'recipe.json').read_text())
        self.assertEqual(saved, self.data)
        self.assertTrue((self.project / 'hands.json').is_file())

    def test_rotated_hand_fails_export_check(self):
        g = GLB.load(self.model)
        node = g.j['nodes'][g.find('nodes', 'R_hand_palm')]
        node['rotation'] = Rotation.from_euler('y', 180, degrees=True).as_quat().tolist()
        self.assertFalse(check(g)['ok'])

    def test_moved_wrist_fails_export_check(self):
        g = GLB.load(self.model)
        g.j['nodes'][g.find('nodes', 'R_arm')]['translation'][1] += .1
        self.assertFalse(check(g)['ok'])

    def test_mirrored_hand_geometry_fails_export_check(self):
        g = GLB.load(self.model)
        node = g.j['nodes'][g.find('nodes', 'R_hand_digits')]
        p = g.j['meshes'][node['mesh']]['primitives'][0]
        verts = g.array(p['attributes']['POSITION'])
        verts[:, 2] *= -1
        p['attributes']['POSITION'] = g.accessor(verts, 'VEC3')
        self.assertFalse(check(g)['ok'])

    def test_reversed_winding_fails_export_check(self):
        g = GLB.load(self.model)
        node = g.j['nodes'][g.find('nodes', 'L_hand_armor')]
        p = g.j['meshes'][node['mesh']]['primitives'][0]
        faces = g.array(p['indices']).reshape(-1, 3)[:, ::-1].ravel()
        p['indices'] = g.accessor(faces, 'SCALAR', 34963)
        self.assertFalse(check(g)['ok'])

    def test_missing_hand_node_fails_export_check(self):
        g = GLB.load(self.model)
        node = g.j['nodes'][g.find('nodes', 'R_hand_palm')]
        node['name'] = 'renamed'
        self.assertFalse(check(g)['ok'])

    def test_changed_side_fails_export_check(self):
        g = GLB.load(self.model)
        g.j['extras']['ai3d_hands'][0]['spec']['side'] = 'left'
        self.assertFalse(check(g)['ok'])

    def test_negative_scale_fails_export_check(self):
        g = GLB.load(self.model)
        g.j['nodes'][g.find('nodes', 'R_hand_digits')]['scale'] = [-1, 1, 1]
        self.assertFalse(check(g)['ok'])

    def test_old_models_are_not_falsely_certified(self):
        g = GLB.load(self.model)
        del g.j['extras']['ai3d_hands']
        row = check(g)
        self.assertEqual(row['status'], 'not_checked')
        self.assertEqual(row['checked'], 0)

    def test_invalid_hand_metadata_rejected(self):
        g = GLB.load(self.model)
        g.j['extras']['ai3d_hands'] = {'bad': 'record'}
        self.assertFalse(check(g)['ok'])

    def test_nonobject_extras_are_unannotated(self):
        g = GLB.load(self.model)
        g.j['extras'] = 'ordinary application metadata'
        self.assertEqual(check(g)['status'], 'not_checked')

    def test_rebuild_glb_is_identical(self):
        dst = self.home / 'rebuild'
        build(self.data, ROOT / 'examples', dst, render='none')
        self.assertEqual(self.model.read_bytes(), (dst / 'model.glb').read_bytes())

    def test_audit_rechecks_hands(self):
        report = audit(self.project, latest=True)
        self.assertTrue(report['ok'], report)
        self.assertEqual(report['hands'][0]['checked'], 2)

    def test_cli_hands_reports_exported_mesh(self):
        result = subprocess.run([sys.executable, '-B', str(ROOT / 'kit.py'), 'hands', str(self.model)],
                                capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(result.stdout)['checked'], 2)

    def test_raised_arm_export_is_checked(self):
        data = recipe()
        for part in data['parts']:
            part['rot'] = [90, 0, 0]
        for h in data['hands']:
            h['palm'] = [0, 1, 0]
        dst = self.home / 'raised'
        build(data, ROOT / 'examples', dst, render='none')
        row = check(dst / 'model.glb')
        self.assertTrue(row['ok'], row)
        self.assertTrue(all(h['finger_direction'][2] < -.99 for h in row['hands']))

    def test_bent_wrist_export_is_checked(self):
        data = recipe()
        for h in data['hands']:
            h['direction'] = [0, -1, .45]
        dst = self.home / 'bent'
        build(data, ROOT / 'examples', dst, render='none')
        self.assertTrue(check(dst / 'model.glb')['ok'])

    def test_oversized_metadata_list_rejected(self):
        g = GLB.load(self.model)
        g.j['extras']['ai3d_hands'] *= 5
        self.assertFalse(check(g)['ok'])

    def test_duplicate_metadata_name_rejected(self):
        g = GLB.load(self.model)
        g.j['extras']['ai3d_hands'].append(copy.deepcopy(g.j['extras']['ai3d_hands'][0]))
        self.assertFalse(check(g)['ok'])

    def test_invalid_direction_shape_rejected(self):
        for value in (1, [1, 2], [0, 0, 0]):
            with self.assertRaises(ValueError):
                frame([0, 1, 0], [0, 0, 0], [0, 0, 1], value)

    def test_generated_geometry_is_deterministic(self):
        a, _ = meshes(self.data['hands'][0])
        b, _ = meshes(self.data['hands'][0])
        for key in a:
            np.testing.assert_array_equal(a[key].v, b[key].v)
            np.testing.assert_array_equal(a[key].f, b[key].f)

    def test_side_mirroring_preserves_shape(self):
        right, _ = meshes(self.data['hands'][0])
        left, _ = meshes({**self.data['hands'][0], 'side': 'left'})
        for role, mesh in right.items():
            error = cKDTree(left[role].v).query(mesh.v * [-1, 1, 1])[0].max()
            self.assertLess(error, 1e-10)


if __name__ == '__main__':
    unittest.main()
