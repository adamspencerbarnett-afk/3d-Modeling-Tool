# Changelog

## 11.3-kit — 2026-09-18

- Release the project under MIT with a project-level copyright notice.
- Simplify the README, chat startup prompt, and contributor/release documentation.
- Consolidate external credits and retain offline dependency license snapshots.
- Preserve MIT and the shader credit inside the viewer so generated HTML previews retain their code notices.
- Remove personal recognition, superseded publication-status documents, and redundant audit inventories.
- Keep the 11.2 modeling, materials, hand-placement, and validation algorithms unchanged.
- Add release checks for licensing, documentation consistency, notice integrity, and startup instructions.

## 11.2-kit — 2026-09-18

- Add declared mechanical hands with anatomical left/right, elbow/wrist anchors, palm direction, curl, spread, and shared material definitions.
- Place hands using a common local frame and proper rotations instead of negative object scales.
- Add exported-geometry checks during build and audit, the `hands` command, saved declarations, and an editable two-hand example.
- Reject misplaced declared geometry, stale anchors, incorrect thumb placement, mirrored fingers, and reversed winding. Report unannotated custom/imported hands as `not_checked`.

## 11.1-kit — 2026-09-18

- Remove unused helpers/imports, inactive accelerator options, duplicate file utilities, and unused overwrite paths.
- Centralize version metadata and bounded JSON/file hashing. Preserve documented CLI and recipe capabilities.
- Add source packaging, broader manifest checks, CI configuration, code documentation, and release regressions.
- Keep procedural example artwork separate from detailed model projects.

## 11.0-kit

- Expand material channels, image preparation, selected-node retexturing, custom/metric/atlas UVs, edge wear, convex prisms, and texture/render inspection.

## 10.0-kit

- Extract the static modeling workflow into one lightweight CLI without the studio server, desktop interface, neural adapters, or bundled model weights.
