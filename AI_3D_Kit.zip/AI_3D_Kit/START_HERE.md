# Start making 3D models

Attach this kit ZIP to a chat with accessible file uploads and Python execution. Send the following message, followed by a description or reference files:

> Open the attached AI 3D Kit ZIP. Read START_HERE.md and AGENTS.md, safely extract this copy, and run python kit.py boot. Use the kit to build the model I describe or reuse models and reference images I attach. Add appropriate textures, check hand placement when relevant, inspect actual model renders, and return a GLB, PNG previews, and an editable project ZIP. If I have not described a model yet, ask what I want to make.

## What the assistant does

The assistant reads [AGENTS.md](AGENTS.md), extracts the archive into a fresh folder, and runs `python kit.py boot`. Startup checks the dependencies and release files and performs a tiny real build and render. It does not install packages, start a server, or call an external service.

After setup, the assistant builds or reuses geometry, adds appropriate materials, checks actual exported-model images, makes targeted corrections, and packages the result. Newly authored mechanical hands use [HANDS.md](HANDS.md) for left/right and palm placement.

## What to ask for

Describe the object, style, and important details. Attach front/side/back references when available. Supply a target size or triangle budget when it matters. For existing models, a self-contained static GLB is the most direct input; OBJ/STL/PLY use an optional converter.

For example:

> Make a worn steel equipment case with yellow corner guards. Use textured materials and show the finished model from the front and rear.

The assistant should use a supplied brief immediately. It only needs to ask what to make when no brief was supplied.

## Your files

The deliverable is a GLB, actual model previews, and an editable project ZIP. Textures are embedded in the GLB; generated PNG maps can also be included. Save the kit and project ZIP together for later editing. The offline viewer is `preview.html`; larger models must be selected with its file picker.

## When setup cannot run

The kit needs Python 3.11+, NumPy, SciPy, Pillow, and jsonschema. Compatible installed packages should be reused. Optional trimesh is needed only for OBJ/STL/PLY conversion. The ZIP cannot add file access or execution to a chat that lacks those tools, and uploading it does not automatically run its contents. The assistant should report an unavailable tool or dependency accurately, not claim a model was built.

[OpenAI's documentation](https://help.openai.com/en/articles/8437071-data-analysis-with-chatgpt) describes file and Python capabilities and their account-dependent availability. For local use, follow the [README](README.md).

[Modeling guide](GUIDE.md) · [Texture guide](TEXTURES.md) · [Hand placement](HANDS.md) · [MIT License](LICENSE)
