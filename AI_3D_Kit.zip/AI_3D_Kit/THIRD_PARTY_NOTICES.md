# Third-party notices

AI 3D Kit Lite is released under the [MIT License](LICENSE). That license covers the project's code, documentation, and included procedural examples; it does not replace third-party terms.

## Separately installed libraries

The ZIP contains no Python interpreter, package source, wheels, native libraries, font files, or model weights. The kit calls the following installed libraries through their public APIs. Complete license-file snapshots from the tested installations are included for offline reference, with versions and hashes in [docs/dependencies.json](docs/dependencies.json).

| Component | Credit | Top-level license | Included notice | Upstream |
|---|---|---|---|---|
| NumPy | NumPy Developers and contributors | BSD-3-Clause | [numpy.txt](docs/licenses/numpy.txt) | [License](https://raw.githubusercontent.com/numpy/numpy/v2.3.5/LICENSE.txt) |
| SciPy | Enthought, Inc.; SciPy Developers and contributors | BSD-3-Clause | [scipy.txt](docs/licenses/scipy.txt) | [License](https://raw.githubusercontent.com/scipy/scipy/v1.17.0/LICENSE.txt) |
| Pillow / PIL | Jeffrey 'Alex' Clark and contributors; Fredrik Lundh and contributors; Secret Labs AB | MIT-CMU | [pillow.txt](docs/licenses/pillow.txt) | [License](https://raw.githubusercontent.com/python-pillow/Pillow/12.3.0/LICENSE) |
| jsonschema | Julian Berman and contributors | MIT | [jsonschema.txt](docs/licenses/jsonschema.txt) | [License](https://raw.githubusercontent.com/python-jsonschema/jsonschema/v4.26.0/COPYING) |
| trimesh, optional | Michael Dawson-Haggerty and contributors | MIT | [trimesh.txt](docs/licenses/trimesh.txt) | [License](https://raw.githubusercontent.com/mikedh/trimesh/4.11.1/LICENSE.md) |
| Python | Python Software Foundation and the other credited contributors | PSF-2.0 and historical notices | [python.txt](docs/licenses/python.txt) | [Licenses](https://docs.python.org/3/license.html) |

The jsonschema dependency graph can also install [attrs](docs/licenses/attrs.txt), [referencing](docs/licenses/referencing.txt), [rpds-py](docs/licenses/rpds-py.txt), [jsonschema-specifications](docs/licenses/jsonschema-specifications.txt), and [typing_extensions](docs/licenses/typing_extensions.txt). Their copyright notices and full license texts are preserved in those files. The first four use MIT at the recorded versions; typing_extensions uses Python-derived terms. Installed versions and platform choices can change the dependency graph.

Some included snapshots contain additional notices for native libraries packaged by their upstream distributors. Those libraries are not included in this kit. These snapshots are not a lockfile or a substitute for the notices accompanying the exact distributions you use. When bundling packages in an executable, container, or installer, retain their applicable notices and review all shipped transitive/native components. Do not relabel them as MIT solely because the kit is MIT-licensed.

## Included graphics contribution

`core/viewer.html`, shader function `aces`, uses the fitted tone-mapping coefficients from **Krzysztof Narkowicz**, [“ACES Filmic Tone Mapping Curve” (2016)](https://knarkowicz.wordpress.com/2016/01/06/aces-filmic-tone-mapping-curve/). The sample is offered under CC0 or MIT; this kit uses the offered [CC0-1.0 option](https://creativecommons.org/publicdomain/zero/1.0/legalcode.en). The source comment retains the author's credit and source links. The viewer also embeds its MIT notice so generated HTML previews preserve both notices. This applies to the small fitted curve, not the full ACES reference implementation.

The [Khronos glTF 2.0 specification](https://github.com/KhronosGroup/glTF/blob/main/specification/2.0/Specification.adoc) informs the interchange and material conventions. No Khronos validator is bundled or conformance certification implied.

## Fonts and example image

Text decals use Pillow's available default font. In the tested environment it is a subset of **DOT COLON's Aileron Regular**, identified by [Pillow's implementation](https://raw.githubusercontent.com/python-pillow/Pillow/12.3.0/src/PIL/ImageFont.py). The [Aileron page](https://dotcolon.net/fonts/aileron/) states “No Rights Reserved.” Only rasterized lettering appears in the included procedural example; no font file is distributed. A different user-supplied font keeps its own terms.

The documentation example is rendered from an included procedural recipe. It is not an external photograph or stock model; see [docs/ASSETS.md](docs/ASSETS.md). User-supplied models, images, decals, and other project assets are not relicensed by the kit.

## Repository automation

The GitHub workflow references `actions/checkout` and `actions/setup-python`, both credited to **GitHub, Inc. and contributors**, under MIT. Their source and runtimes are not bundled. The shared license text is retained in [actions.txt](docs/licenses/actions.txt); upstream notices are available for the pinned [checkout](https://raw.githubusercontent.com/actions/checkout/3d3c42e5aac5ba805825da76410c181273ba90b1/LICENSE) and [setup-python](https://raw.githubusercontent.com/actions/setup-python/5fda3b95a4ea91299a34e894583c3862153e4b97/LICENSE) commits. These tools are for repository checks, not model creation.
