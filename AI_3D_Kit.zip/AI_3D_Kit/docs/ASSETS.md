# Included example

[images/example.png](images/example.png) is an actual CPU render of [examples/textured_prism.json](../examples/textured_prism.json). Geometry, materials, and surface wear are procedural. There is no reference-image or imported-model input.

The recipe and documentation render are included under the project's [MIT License](../LICENSE). The `KIT 03` lettering was rasterized using Pillow's available default Aileron Regular subset; its external font credit appears in [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md). No font file is included.

[assets.json](assets.json) records the example and recipe hashes. Regeneration may change pixels across renderer, numerical-library, or font versions. Use a small procedural example in the source kit and keep detailed model projects in separate downloads.

For new assets, record the creator/source, license or permission, required credit, and any modifications. The kit's MIT license does not relicense user-supplied models, photographs, fonts, or other project inputs.
