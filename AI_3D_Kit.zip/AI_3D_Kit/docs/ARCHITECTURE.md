# Architecture

`kit.py` is the only user-facing program. It dispatches commands and emits JSON results. `agent/schema.py` and task schemas in `agent/work.py` describe the accepted inputs. No studio server, background queue, desktop GUI, neural adapter, or machine-specific installer is retained.

| Area | Modules and responsibility |
|---|---|
| Mesh and interchange | `core/mesh.py` owns mesh data, transforms, primitive foundations and static GLB IO; `core/optimize.py` compacts storage; `core/validate.py` checks supported semantics. |
| Recipe geometry | `agent/geom.py`, `curves.py`, `hard.py`, `sculpt.py`, and `stamps.py` create and modify geometry. |
| Materials | `mats.py`, `bake.py`, `uv.py`, `wear.py`, `photo.py`, `paint.py`, and `presets.py` prepare maps and node-specific material work. |
| Orchestration | `build.py` stages recipe projects; `work.py` handles tasks; `files.py` imports and extracts bounded assets; `state.py` centralizes files, fingerprints and dependency checks. |
| Inspection | `quality.py` inspects/export maps; `preview.py` renders actual triangles; `core/viewer.html` provides a self-contained browser viewer. |
| Maintenance | `tools/release.py` creates/checks the release inventory; `tests/` exercises the supported workflows and release boundaries. |

The `agent` name identifies modeling operations; it is not a separate model or autonomous account integration. The host assistant supplies design interpretation.

## Coordinate and material conventions

Recipes use meters, +Y up and +Z front. Low-level lathe/cylinder meshes use a Z axis and are rotated by the recipe adapter. glTF matrices are column-major in JSON; NumPy geometry uses row-vector operations. Normals require inverse transformation under nonuniform scale. Mirrored instances require winding/handedness handling.

Base-color and emissive images are sRGB-encoded; normal and scalar data are linear. ORM stores occlusion in red, roughness in green and metallic in blue; separate occlusion is also supported. Height changes shading unless a geometric stroke/stamp explicitly changes the mesh. Tangent-space conventions are documented in the texture guide.

## Source and project snapshots

Release fingerprints include code, examples, tests, docs, license notices, and CI. Model-project reports record the release fingerprint and input hashes. Updating docs therefore intentionally changes `--latest` checks for previously built projects. Old project artifacts remain valid snapshots, but rebuild them to claim a current-source match.

A source ZIP is different from a project ZIP. Source packaging uses only the release inventory. Project packaging audits the model output and includes its recipe/task, inputs, textures and previews. Neither transfers rights in an external image or model.

## Deliberate limits

Recipe instances can share stored geometry without reducing visible triangle counts. Exact compaction is not a triangle decimator. Mesh assembly does not Boolean-union parts. Planar chart packing is not general organic unwrapping. CPU and WebGL inspection use approximate lighting, and the browser alone uses the credited ACES-fit curve. Optional importer interface methods are retained even when no direct local caller is visible.

## Declared hands

`agent/hands.py` expands a recipe's bounded `hands` entries into four static mesh
parts per hand, in a shared wrist-local frame. `agent/build.py` retains the compact
source declaration for replay and passes its contract to the GLB exporter. Builds
and audits compare the actual exported hand geometry and placement to a regenerated
template. This component adds no new runtime dependency. It does not alter the
importer or pretend to recognize hands in unannotated models.
