# Hand construction and placement

Added in **11.2-kit**. This is a static mechanical-hand component, not a rig,
a general anatomy detector, or a replacement for reviewing the reference.

## Why this exists

The previous android project placed dorsal hand plates on one face but curled
the fingers toward that same face. Successful mesh and texture checks did not
catch the anatomical inconsistency. The new component builds the palm, fingers,
thumb, joints, and dorsal plates together in one explicit local frame, then places
that assembly at the wrist.

## Coordinate contract

In hand-local space, the wrist is the origin, **+Y points toward the fingers**, and
**+Z points out through the palm**. The right thumb is on +X; the left thumb is on
-X. Index, middle, ring, and little fingers run from the thumb side outward.
Digit flexion moves toward +Z. Protective plates remain on the dorsal side.

`side` means the **character's own** left or right, not the viewer's left or right.
The kit's usual body frame is +Y up and +Z front; a front-facing character's
anatomical right normally lies on -X. Do not decide handedness from world X alone:
the character may be turned, the arms may be crossed, or the pose may be asymmetric.

Placement uses the elbow-to-wrist vector and an explicit `palm` direction.
The palm hint is projected perpendicular to the finger axis. Zero-length anchors,
near-parallel hints, backward axes, and unsupported wrist bends fail with an error.
The computed frame has determinant +1. Left hands are constructed with their own
thumb layout; a negative object scale is not used to disguise a right hand as a left.

## Use the built-in example

From the kit directory:

```sh
python kit.py build examples/hands.json --out ../hand_example
python kit.py hands ../hand_example/model.glb
python kit.py audit ../hand_example --latest
```

`examples/hands.json` is a complete two-hand recipe with short forearms. Its relaxed
pose has the palms facing inward and the thumbs pointing approximately forward.
That is a pose choice, **not a universal rule**: palms-forward, palms-backward, raised
arms, and a bent wrist need their own explicit hints.

## Recipe fields

Add `hands` alongside `parts` and `materials`. The following is the complete hand
entry used for the right side of a character whose elbow and wrist parts already
exist in the recipe:

```json
{
  "name": "R_hand",
  "side": "right",
  "elbow": {"part": "R_elbow_housing"},
  "wrist": {"part": "R_wrist_housing"},
  "palm": [1, 0, -0.12],
  "size": [0.074, 0.083, 0.03],
  "curl": 32,
  "spread": 5,
  "mat": "trim",
  "joint_mat": "mech",
  "armor_mat": "armor_small"
}
```

| Field | Meaning |
|---|---|
| `name` | Unique component name, at most 48 characters. |
| `side` | `left` or `right`, from the character's perspective. |
| `elbow`, `wrist` | A world-coordinate point, or `{"part": "name", "point": [x, y, z]}` with a part-local point. The default local point is the part origin. |
| `palm` | Required world-space palm-facing direction, not a position. |
| `direction` | Optional world-space wrist-to-fingers direction. Otherwise follows elbow to wrist. Supported bend is at most 80 degrees from the forearm axis. |
| `size` | Palm width, palm length, and palm depth in meters. Default `[0.075, 0.085, 0.03]`; this is not the complete hand's bounding box. |
| `curl` | Shared four-finger flexion parameter, 0–60 degrees, default 28. Individual segments use increasing fractions of this parameter. The thumb has a fixed opposed relaxed shape. |
| `spread` | Four-finger spread parameter, 0–15 degrees, default 5. |
| `mat` | Existing recipe material for palm/frame and finger links. |
| `joint_mat` | Existing recipe material for hinges and wrist connection. |
| `armor_mat` | Existing recipe material for dorsal plates. |

The anchor parts must remain present at every exported LOD. Direct point anchors
are supported for simple scenes but cannot independently verify that a particular
forearm actually occupies those points. Prefer named part anchors for characters.
An anchor refers to the existing part's local coordinates before its `pos`, `rot`,
and `scale` transform; it does not automatically select the nearest surface.

Each hand adds four named material groups: `_palm`, `_digits`, `_armor`, and `_joints`.
Up to eight hand declarations are supported, subject to the normal 256-part,
triangle, and texture budgets. Generated topology is fixed across LODs. This
component has no independent finger posing, skinning, inverse kinematics, grasp
solver, or collision/contact solver.

Query the exact supported contract with:

```sh
python kit.py schema --section hand
```

## Automatic build and audit checks

A recipe with declared hands automatically produces `hands.json`. Its GLB embeds
the hand specifications and generated node names under `extras.ai3d_hands`.
During build and again during `audit`, the kit checks:

- Named wrist/elbow anchors, a proper placement rotation, and all four hand groups.
- Five digit paths, anatomical thumb side, finger ordering, and palm-side flexion.
- Actual exported positions against regenerated template geometry, triangle counts,
  face centers, and triangle winding. Stale rotations, misplaced parts, mirrored
  finger geometry, and reversed winding are rejected.

The check uses a numeric tolerance scaled to palm size. It does not require
byte-identical index ordering after export optimization. It does require the same
supported template geometry: an intentional custom topology or pose edit needs a
matching rebuilt declaration, not an old placement record copied onto new geometry.
The input recipe keeps its short `hands` entries, so rebuilding does not require an
authoring script or duplicate thousands of hand vertices in the saved JSON.

`kit.py hands MODEL.glb` runs the same check independently. A model without hand
metadata returns **`status: "not_checked"`, `checked: 0`**. Its `ok` value describes
whether the check command encountered an error, not whether unannotated hands are
correct. Importing an old model does not retroactively infer its anatomy.

## Custom hands and visual review

Do not replace a user's detailed custom hand mesh solely to obtain a template pass.
Keep it and inspect its wrist pivot, thumb side, palm/back distinction, knuckle row,
individual finger bends, materials, and contact against front, rear, and oblique
views. Report that its anatomical placement was manually reviewed; it does not have
an automatic template check. Never silently label it as checked by this feature.

Even generated hands need visual inspection. Two valid individually placed hands
may still intersect the body, one another, or nearby objects. The check does not
establish biological accuracy, a natural pose, valid joint limits for a specific
robot, printability, or fidelity to a reference image.
