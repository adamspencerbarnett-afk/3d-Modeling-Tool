## Change

Describe the problem and focused fix. Identify any CLI or schema changes.

## Validation

Record tests and actual model views inspected, including checks not run.

## New components and assets

State the source and terms of added code or assets. Retain required third-party notices. Do not attach secrets, private data, or material without redistribution permission.

## Release inventory

After reviewing changes, refresh the manifest and run tests plus `python -B -m tools.release --check`.
