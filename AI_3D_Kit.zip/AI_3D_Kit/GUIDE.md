# Modeling guide

Commands below are run by the assistant. Start from the kit directory and use a separate sibling work folder. The user normally supplies a brief, not commands.

## Commands

| Task | Command |
|---|---|
| Verify declared hand placement and exported geometry | `python kit.py hands ../3d_work/model.glb` |
| Check setup and a tiny real build/render | `python kit.py boot` |
| Create a model from a recipe | `python kit.py build ../3d_work/chair.json --out ../3d_work/chair_v1` |
| Import a supported static model | `python kit.py import ../3d_work/chair.glb --out ../3d_work/imported` |
| Inspect counts, node names and materials | `python kit.py inspect ../3d_work/chair.glb --full` |
| Apply node edits | `python kit.py edit ../3d_work/chair.glb ../3d_work/edits.json --out ../3d_work/edited` |
| Run an import, assembly or relief task | `python kit.py run ../3d_work/task.json --out ../3d_work/result` |
| Extract a model-and-texture ZIP | `python kit.py unpack ../3d_work/assets.zip --out ../3d_work/assets` |
| Render a model to a new folder | `python kit.py render ../3d_work/chair.glb --out ../3d_work/views` |
| Check an output project | `python kit.py audit ../3d_work/result --latest` |
| Package an output project | `python kit.py pack ../3d_work/result --out ../3d_work/result.zip` |

Build/import/edit/relief/run accept `--size 384`, `--no-render` and `--max-triangles 200000`. A recipe's own triangle budget is also enforced; the lower limit wins. Defaults: recipe 10,000 triangles, import tasks 200,000, one LOD, 256-pixel baked maps. Preview size range is 64–1600. Write task budgets with care; many tiny triangles can make a software renderer slow even when the model file is small.

Additional texture commands and complete examples are in **TEXTURES.md**. `build --quality draft|standard|high` supplies missing resolution/budget defaults; it does not override explicit settings or improve geometry automatically. `render --review --aa 2` adds front/side/top, unlit base-color and UV views. `render --angle 20 --elev 12 --mode normal` produces one custom view; modes also include beauty, clay, rough, metal, ao and emission. Specify `--angle` when choosing a custom elevation.

`template` creates one of `pillar`, `crate`, `barrel`, `arch` as an editable JSON file. `schema --section recipe|part|material|sculpt|stamp|use|task|edit` prints precise supported fields. Unknown fields fail validation. Source files in `examples/` are small working recipes, not binary demos.

## Recipes

A complete minimal recipe:

```json
{
  "schema": "ai3d.recipe/1",
  "name": "Blue_Box",
  "max_triangles": 1000,
  "texture_size": 256,
  "lods": [1],
  "materials": {
    "blue": {"kind": "solid", "color": [0.08, 0.3, 0.6], "rough": 0.7}
  },
  "parts": [
    {"name": "body", "shape": "box", "mat": "blue", "size": [1, 0.6, 0.5], "bevel": 0.03, "pos": [0, 0.3, 0]}
  ]
}
```

Units are meters. +Y is up, +Z is front. Coordinates are object coordinates, not screen coordinates. `pos`, `rot` and `scale` are three-component arrays; rotations are XYZ Euler degrees. Scale must be strictly positive. Mesh parts overlap unless authored to fit; creating several intersecting shapes does not perform a Boolean union.

| Shape | Main fields |
|---|---|
| `box` | `size: [x,y,z]`, `bevel` less than every half-dimension |
| `cylinder` | `radius`, `length`, optional `top`, `inner`, `steps`, `rings`; axis is Y |
| `sphere` | `radius`, `steps`, `rings` |
| `ellipsoid` | `size: [x,y,z]`, `steps`, `rings` |
| `torus` | major `radius`, `tube`, `steps`, `rings`; verify orientation in views |
| `bowl` | `size`, wall `depth`, `steps`, `rings`, optional `power`, `taper`, `lean` |
| `lathe` | `profile: [[radius,height],...]`, `steps`; axis is Y, author the cap profile explicitly |
| `hose` | 3D `points`, `radius`, `steps`, `samples` |
| `plate` | convex 2D `points`, `depth` along Z |
| `prism` | strictly convex XY `points`, Z `depth`, optional `bevel` and `taper` (.1–1); taper changes Z thickness with Y |
| `mesh` | 3D vertices `v` and triangle indices `f`; flat normals; optional vertex-aligned `uvs` pairs, or generated mapping |

UV choices also include `metric` (local-space `uv_size` meters per repeat) and `atlas` (separate planar charts packed into 0–1). Atlas mapping is intended for hard surfaces, not seamless organic unwrapping. Preserve authored UVs when retexturing imported organic assets. Avoid tiny charts and check the UV view.

Set `min_lod` only when a part should disappear in a coarser level. LODs such as `[1, 0.5]` create separate GLBs; they do not configure automatic switching in a game engine. Sampling is reduced, not arbitrary imported topology. Duplicate levels are omitted. Repeated identical parts can share stored geometry, but each visible instance still contributes rendered triangles.

A recipe can contain at most 256 parts, 32 materials and 200,000 rendered triangles. These are limits, not recommended defaults. The kit has no rig/animation compiler or general Boolean solver.

## Materials, images and decals

Material kinds are `solid`, `wood`, `steel`, `paint`, `concrete`, `stone` and `image`. Fields include `color`, `rough`, `metal`, `bump`, `wear`, optional `emission`, `tex_size` and `layers`. Plain solid colors are stored as material factors with no image maps. Procedural/image materials can export base color, normal and packed occlusion/roughness/metallic maps.

This is a complete image-material recipe. The PNG must already exist beneath the JSON folder; its lighting is not automatically removed.

```json
{
  "schema": "ai3d.recipe/1",
  "name": "Image_Box",
  "texture_size": 256,
  "materials": {
    "surface": {"kind": "image", "image": "assets/color.png", "source": "provided", "rough": 0.85}
  },
  "parts": [
    {"name": "body", "shape": "box", "mat": "surface", "size": [1, 1, 1]}
  ]
}
```

`source` and `prompt` are provenance metadata, not commands. Setting `source: "generated"` does not call an image service. A reference picture does not become a model merely by appearing in this field.

Layer kinds are `image`, `text`, `polygon`, `stripe`, `crack`, `stain`, `speckle` and `scratches`. A polygon needs normalized `points`; an image can take an RGB `tint`. Use normalized `rect: [u,v,width,height]` and `opacity`. RGBA image layers composite alpha into the material; they do not cut holes. A base image material is opaque. Supplied `normal`, `height` and `orm` paths are optional. Material `height` and layer `height` change shading, not silhouette. Use geometry stamps or sculpt strokes for real surface changes.

Use `uv: "box"` for a box with unique face labels or projected decals. Its 3-column, 2-row atlas is: +Z, -Z, +X across the top; -X, +Y, -Y across the bottom. Do not tile this atlas. Projected per-part `decals` also require a `side` and appropriate unique UVs. Use `uv: "atlas"` for projected decals on a prism, plate, hose or custom mesh. This packs planar charts; it is not a seamless organic unwrap. Box decals accept their box atlas or a generated planar atlas.

## Sculpt strokes and geometry stamps

`examples/sculpt.json` contains a working geometric carve. Strokes live in a part's `sculpt` array. Brushes are `draw`, `carve`, `inflate`, `grab`, `pinch`, `crease`, `flatten` and `smooth`. Use `center` or `path`, `radius`, and brush-appropriate `depth`, `strength`, `move` or `normal`. Coordinates default to part-local space; query the schema before using other fields. Inspect the resulting mesh, not just the report. A coarse surface may need more sampling before it can express a small crease.

A complete geometric-stamp example:

```json
{
  "schema": "ai3d.recipe/1",
  "name": "Dented_Block",
  "max_triangles": 5000,
  "texture_size": 128,
  "materials": {"stone": {"kind": "stone"}},
  "stamps": {"dent": {"kind": "dent", "size": 128}},
  "parts": [
    {
      "name": "body", "shape": "box", "mat": "stone", "size": [1, 1, 1], "uv": "box",
      "stamps": [{"stamp": "dent", "side": "front", "mode": "carve", "depth": 0.08, "res": 16}]
    }
  ]
}
```

Presets include `crack`, `chip`, `bark`, `rosette`, `dent`, plus explicit `height` maps. Modes `carve`, `raise` and `signed` change geometry; `bump` does not. Stamps are local height fields, not Boolean holes, undercuts or full reconstruction. Thin walls, self-intersections and contact need visual or external geometric review. Stamps on custom mesh/hose/plate recipe parts are unsupported. These recipe operations are not an automatic sculpt pipeline for arbitrary uploaded characters.

## Reuse and edit uploaded models

Prefer a self-contained GLB with core metallic-roughness materials. Supported data are static triangle meshes with embedded PNG/JPEG textures, ordinary accessors and UV set 0. Rigged/animated/morph-target models, required extensions, Draco/meshopt compression, GPU instancing, sparse accessors and additional UV sets must be converted externally first. Native GLB import preserves supported geometry and materials; OBJ/PLY/STL conversion is not a universal lossless interchange promise.

`import --scale 0.001` treats millimeter-valued coordinates as meters. `import --up z` rotates Z-up coordinates to Y-up. Default `--scale 1 --up y` does not infer original units. All models are static and unrigged in this workflow.

Inspect first to find the exact node. An edits file is a complete JSON array:

```json
[
  {"node": "cushion", "color": [0.02, 0.07, 0.15, 1], "rough": 0.9},
  {"node": "backrest", "pos": [0, 0.05, 0]}
]
```

A node can be its exact unique name or integer index. Transforms are **deltas in the parent coordinate frame**, left-multiplied onto the existing local transform, not absolute replacement coordinates. Nonuniform scales and rotations are therefore meaningful; inspect the result. Material changes apply only to that mesh node, not its children or every instance sharing the old material. `color` multiplies any existing base-color texture. It does not repaint or remove the texture. Negative scales, arbitrary vertex editing and hierarchy-wide material propagation are not exposed by this edit command.

Use an assembly task to combine saved GLBs:

```json
{
  "schema": "ai3d.task/1",
  "name": "Two_Chairs",
  "op": "assemble",
  "items": [
    {"name": "left", "model": "assets/chair.glb", "pos": [-0.5, 0, 0]},
    {"name": "right", "model": "assets/chair.glb", "pos": [0.5, 0, 0], "rot": [0, 20, 0]}
  ]
}
```

Assembly keeps the component geometry and supported material data. It does not fuse overlapping surfaces or produce a single printable solid. Assembly currently rejects cameras and glTF extensions. Duplicate input files are not automatically instance-deduplicated by this task route.

## Image relief

```text
python kit.py relief ../3d_work/height.png --mode height --width 1 --depth 0.06 --base 0.02 --res 48 --out ../3d_work/relief
```

This makes a closed-back height surface facing +Z. Width is in meters; aspect ratio follows the image. `depth` controls maximum forward displacement, `base` the backing thickness, and `res` the longest grid side. A denser grid is not better evidence of source depth.

Height mode accepts single-channel unsigned 8/16-bit maps or floating maps in [0,1]. RGB photos are rejected. Brightness mode is a separate, explicitly artistic option. It cannot distinguish shading, paint and depth. There is no segmentation, hidden-surface recovery or automatic conversion from a photo to measured depth.

A relief task can add an existing texture:

```json
{
  "schema": "ai3d.task/1",
  "name": "Textured_Relief",
  "op": "relief",
  "image": "assets/height.png",
  "color_image": "assets/color.png",
  "mode": "height",
  "width": 1,
  "depth": 0.06,
  "base": 0.02,
  "res": 48
}
```

## Rebuild, preview and validation

A recipe project rebuilds with `build PROJECT/recipe.json --out NEW_PROJECT`. An imported, assembled or relief project rebuilds with `run PROJECT/task.json --out NEW_PROJECT`. Task projects save normalized source GLBs or the image assets necessary to repeat the operation. The project ZIP does not duplicate the whole kit; reuse this kit alongside it.

The CPU renderer draws actual exported triangles, without a GPU requirement. Hero, back and clay images are generated by default. Base-color, normal, packed roughness/metallic, separate occlusion and emissive maps are read with their respective color conventions. Vertex RGB, masked vertex alpha, normal scale and repeat/clamp/mirror sampling are supported. A primary-light shadow map and analytic studio lighting improve inspection but are not path tracing or measured environment illumination. CPU sampling has no mipmap chain; `--aa 2` reduces jaggies. Alpha-blended transparency is still rendered opaque. Clay views ignore cutout alpha by design. Test complex imported materials in their target application.

The browser viewer was updated for separate AO/emissive maps and vertex colors. Its JavaScript parses, and the offline still-image/download fallback was exercised; WebGL 2 was unavailable in the release test browser, so interactive shader output remains unverified. Browser and CPU lighting are not identical. Neither viewer is a complete glTF material conformance renderer.

`audit` rechecks exported GLBs and recorded project-file hashes. `--latest` also checks that the current kit source matches the build source. It is not the official Khronos Validator. Reports retain `review_required: true`; an actual visual review is a separate assistant action. Do not modify files inside an audited project; rebuild into a new folder.

For kit maintenance, run `python -B -m unittest discover -s tests -v`. Normal users should not run the full suite for every model.

## Mechanical hands

See [HANDS.md](HANDS.md) and `examples/hands.json` for explicit left/right, wrist-relative mechanical hands. The builder saves the declarative component, embeds its placement contract in the GLB, and automatically checks actual exported hand geometry. Unannotated imported or custom hands are not automatically certified.
