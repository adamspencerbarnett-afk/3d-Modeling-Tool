"""Rebuild or check the release manifest and create a deterministic source ZIP.

Package the reviewed source snapshot for repository downloads.
The unsigned checksum detects changes; it does not authenticate a publisher.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path

from agent import DATE, VERSION
from agent.state import ROOT, code_files, output_path, read, verify, write
from core.hash import digest


def manifest() -> dict:
    """Return the same inventory and digest used by startup verification."""
    files = code_files()
    return {
        'version': VERSION,
        'date': DATE,
        'files': files,
        'source_sha256': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
    }


def pack(out: str | Path) -> dict:
    """Package only manifest-tracked files with fixed timestamps and permissions."""
    out = output_path(out)
    if out.suffix.lower() != '.zip':
        raise ValueError('The release output must use the .zip suffix.')
    check = verify()
    if not check['ok'] or not check['release_verified']:
        raise ValueError('Refresh the release manifest before packaging.')
    saved = read(ROOT / 'MANIFEST.json')
    files = dict(saved['files'])
    files['MANIFEST.json'] = digest(ROOT / 'MANIFEST.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    stamp = tuple(int(part) for part in DATE.split('-')) + (0, 0, 0)
    with tempfile.TemporaryDirectory(prefix='.release-', dir=out.parent) as tmp:
        staged = Path(tmp) / out.name
        with zipfile.ZipFile(staged, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, expected in sorted(files.items()):
                payload = (ROOT / name).read_bytes()
                if hashlib.sha256(payload).hexdigest() != expected:
                    raise ValueError(f'Source changed while packaging: {name}')
                info = zipfile.ZipInfo('AI_3D_Kit/' + name, date_time=stamp)
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, payload)
        # Exclusive creation prevents a concurrent publisher from being overwritten.
        created = False
        try:
            with out.open('xb') as target, staged.open('rb') as source:
                created = True
                while block := source.read(1024 * 1024):
                    target.write(block)
        except BaseException:
            if created:
                out.unlink(missing_ok=True)
            raise
    return {
        'ok': True,
        'file': str(out),
        'files': len(files),
        'bytes': out.stat().st_size,
        'sha256': digest(out)
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Verify without modifying the manifest.')
    parser.add_argument('--out', help='Create a source ZIP outside the repository.')
    args = parser.parse_args()
    try:
        if args.check:
            result = verify()
            if not result['ok'] or not result['release_verified']:
                print(json.dumps(result, indent=2))
                return 1
        else:
            write(ROOT / 'MANIFEST.json', manifest())
            result = verify()
        if args.out:
            result = pack(args.out)
        print(json.dumps(result, indent=2))
        return 0
    except (OSError, ValueError) as error:
        print(json.dumps({'ok': False, 'error': str(error)}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
