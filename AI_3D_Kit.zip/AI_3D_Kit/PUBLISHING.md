# Repository and release guide

The folder containing `kit.py` is the repository root. Commit its source files, documentation, notices, examples, tests, and `.github/` configuration. Keep generated model projects, textures, credentials, caches, virtual environments, and previous release ZIPs outside that tree.

## Build the downloadable kit

After reviewing intentional changes, refresh the manifest, run the tests and startup check, then build the ZIP:

```bash
python -B -m tools.release
python -B -m unittest discover -s tests -v
python -B kit.py boot
python -B -m tools.release --check
python -B -m tools.release --check --out ../AI_3D_Kit_Lite_v11_3.zip
```

Use a new output filename rather than overwriting an existing ZIP. Extract the ZIP into a fresh folder and repeat startup and tests there. The source package contains only manifest-tracked files with fixed timestamps and permissions. Its SHA-256 fingerprint detects changes; it is not a digital signature or publisher authentication.

## Publish on GitHub

Create a version tag matching `agent/__init__.py`, create its release, and attach the tested ZIP and a SHA-256 checksum file. The Releases ZIP is the recommended download for chat users. Keep `README.md`, `START_HERE.md`, `CHATGPT_START.txt`, and the relative documentation images together.

The checked-in workflow runs tests and startup on its configured platforms; it does not publish releases automatically. Configure repository visibility, branch protection, and private vulnerability reporting in GitHub. A generated ZIP does not change those account settings or publish itself.

## Maintain the distribution

The project is [MIT-licensed](LICENSE). Keep that notice and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) in releases. Update dependency notices when changing or bundling external components, and document the source and terms of added assets. Detailed model examples belong in separate downloads rather than the small source kit.

Changes to documentation and notices also change the source fingerprint. Old model projects remain usable, but rebuild them before claiming a match to the current kit with `audit --latest`.
