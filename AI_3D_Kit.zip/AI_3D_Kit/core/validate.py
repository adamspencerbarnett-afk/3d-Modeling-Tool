"""Check the supported static GLB subset and report counts and dimensions.

These checks do not replace the Khronos Validator or certify printability."""

from __future__ import annotations
import io
from pathlib import Path
import numpy as np
from PIL import Image
from core.mesh import GLB
from core.hash import digest as file_hash


def check(path):
    """Return validation errors, warnings, and geometry/material inventory."""
    path = Path(path)
    result = {
        'file': path.name,
        'sha256': file_hash(path),
        'bytes': path.stat().st_size,
        'scope': 'Internal checks for the supported static-GLB subset, not a Khronos Validator certificate or a realism assessment',
        'errors': [],
        'warnings': []
    }
    errors, warnings = (result['errors'], result['warnings'])
    try:
        g = GLB.load(path)
        worlds = g.worlds()
        result['nodes'] = len(g.j['nodes'])
        result['active_nodes'] = len(worlds)
        result['meshes'] = len(g.j.get('meshes', []))
        result['materials'] = len(g.j.get('materials', []))
        result['images'] = len(g.j.get('images', []))
        if len(worlds) < len(g.j['nodes']):
            warnings.append('Some nodes are detached from the active scene; their stored geometry is retained.')
        for i, v in enumerate(g.j.get('bufferViews', [])):
            start, length = (v.get('byteOffset', 0), v['byteLength'])
            if v.get('buffer', 0) != 0 or start < 0 or length <= 0 or (start + length > len(g.b)):
                errors.append(f'bufferView {i}: invalid range.')
            if start % 4:
                errors.append(f'bufferView {i}: offset is not 4-byte aligned.')
        arrays = {}
        for i, a in enumerate(g.j.get('accessors', [])):
            try:
                x = g.array(i)
                arrays[i] = x
                if not np.all(np.isfinite(x)):
                    errors.append(f'Accessor {i}: non-finite values.')
                if 'min' in a and x.ndim == 2 and (not np.allclose(
                    x.min(0),
                    a['min'],
                    atol=1e-05,
                    rtol=1e-05
                )):
                    errors.append(f'Accessor {i}: min bounds disagree with data.')
                if 'max' in a and x.ndim == 2 and (not np.allclose(
                    x.max(0),
                    a['max'],
                    atol=1e-05,
                    rtol=1e-05
                )):
                    errors.append(f'Accessor {i}: max bounds disagree with data.')
            except Exception as exc:
                errors.append(f'Accessor {i}: {exc}')
        tris = {}
        vertices = 0
        degenerate = 0
        for mi, m in enumerate(g.j.get('meshes', [])):
            tris[mi] = 0
            for pi, p in enumerate(m['primitives']):
                label = f'Mesh {mi}, primitive {pi}'
                try:
                    attrs = p['attributes']
                    v = arrays[attrs['POSITION']]
                    if v.ndim != 2 or v.shape[1] != 3:
                        raise ValueError('Position array must be VEC3.')
                    idx = arrays[p['indices']] if 'indices' in p else np.arange(len(v))
                    if idx.ndim != 1 or len(idx) % 3 or np.any(idx < 0) or np.any(idx >= len(v)) or (not np.issubdtype(idx.dtype, np.integer)):
                        raise ValueError('Invalid triangle indices.')
                    tri = v[idx.reshape(-1, 3)].astype(np.float64)
                    area = np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1)
                    degenerate += int(np.count_nonzero(area < 1e-20))
                    for key, ai in attrs.items():
                        if len(arrays[ai]) != len(v):
                            raise ValueError(f'{key} count differs from POSITION count.')
                    if 'NORMAL' in attrs:
                        lengths = np.linalg.norm(arrays[attrs['NORMAL']], axis=1)
                        if np.any(np.abs(lengths - 1) > 0.01):
                            raise ValueError('Normals are not unit length within 1%.')
                    else:
                        warnings.append(label + ': no stored normals.')
                    if 'material' in p and (not 0 <= p['material'] < len(g.j.get('materials', []))):
                        raise ValueError('Material index is out of range.')
                    tris[mi] += len(idx) // 3
                    vertices += len(v)
                except Exception as exc:
                    errors.append(label + ': ' + str(exc))
        lo, hi = (np.full(3, np.inf), np.full(3, -np.inf))
        drawn = 0
        for ni, mat in worlds.items():
            n = g.j['nodes'][ni]
            if 'mesh' not in n:
                continue
            if n['mesh'] not in tris:
                errors.append(f'Node {ni}: mesh index is out of range.')
                continue
            drawn += tris[n['mesh']]
            for p in g.j['meshes'][n['mesh']]['primitives']:
                ai = p['attributes']['POSITION']
                if ai not in arrays:
                    continue
                v = arrays[ai].astype(np.float64) @ mat[:3, :3].T + mat[:3, 3]
                lo = np.minimum(lo, v.min(0))
                hi = np.maximum(hi, v.max(0))
        if not drawn:
            errors.append('Active scene contains no triangles.')
        if degenerate:
            errors.append(f'{degenerate} zero-area or extremely tiny triangles found.')
        if np.all(np.isfinite([lo, hi])):
            result['bounds_m'] = [lo.tolist(), hi.tolist()]
            result['dimensions_m'] = (hi - lo).tolist()
        result['stored_triangles'] = sum(tris.values())
        result['rendered_triangles'] = drawn
        result['stored_vertices'] = vertices
        result['degenerate_triangles'] = degenerate
        image_info = []
        for i, im in enumerate(g.j.get('images', [])):
            try:
                raw = g.image_bytes(i)
                with Image.open(io.BytesIO(raw)) as image:
                    size, fmt = (image.size, image.format)
                    if image.width * image.height > 16777216:
                        raise ValueError('Texture exceeds the 16-million-pixel safety limit.')
                    image.load()
                image_info.append({'index': i, 'name': im.get('name'), 'size': list(size), 'format': fmt})
            except Exception as exc:
                errors.append(f'Image {i}: {exc}')
        for i, tex in enumerate(g.j.get('textures', [])):
            if not 0 <= tex.get('source', -1) < len(g.j.get('images', [])):
                errors.append(f'Texture {i}: invalid image reference.')
            if 'sampler' in tex and (not 0 <= tex['sampler'] < len(g.j.get('samplers', []))):
                errors.append(f'Texture {i}: invalid sampler reference.')

        def texture_refs(obj, prefix):
            if not isinstance(obj, dict):
                return
            for key, value in obj.items():
                if key.endswith('Texture') and isinstance(value, dict):
                    if not 0 <= value.get('index', -1) < len(g.j.get('textures', [])):
                        errors.append(prefix + '.' + key + ': invalid texture index.')
                if isinstance(value, dict):
                    texture_refs(value, prefix + '.' + key)
        for i, m in enumerate(g.j.get('materials', [])):
            texture_refs(m, f'Material {i}')
            p = m.get('pbrMetallicRoughness', {})
            for key in ('metallicFactor', 'roughnessFactor'):
                if key in p and (not 0 <= p[key] <= 1):
                    errors.append(f'Material {i}: {key} is outside [0, 1].')
            for owner, key, count in [(p, 'baseColorFactor', 4), (m, 'emissiveFactor', 3)]:
                if key in owner and (len(owner[key]) != count or not np.all(np.isfinite(owner[key])) or min(owner[key]) < 0 or (max(owner[key]) > 1)):
                    errors.append(f'Material {i}: invalid {key}.')
        result['image_info'] = image_info
    except Exception as exc:
        errors.append(str(exc))
    result['passed'] = not errors
    return result
