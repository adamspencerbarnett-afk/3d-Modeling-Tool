"""Deduplicate and compact GLB storage while checking semantic preservation.

This is not mesh simplification: visible instances still count toward budgets."""

from __future__ import annotations
import copy
import hashlib
import json
import tempfile
from pathlib import Path
import numpy as np
from core.mesh import DT, NC, GLB
from core.hash import digest as file_hash
from core.validate import check


def key(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def guard(obj):
    if isinstance(obj, dict):
        if obj.get('extensions') or obj.get('extensionsUsed') or obj.get('extensionsRequired'):
            raise ValueError('Lossless compaction accepts core static glTF only; extensions must not be silently remapped.')
        for name, value in obj.items():
            if name != 'extras':
                guard(value)
    elif isinstance(obj, list):
        for value in obj:
            guard(value)


def raw(g, i):
    a = g.j['accessors'][i]
    v = g.j['bufferViews'][a['bufferView']]
    dt = np.dtype(DT[a['componentType']])
    n = NC[a['type']]
    off = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    stride = v.get('byteStride', n * dt.itemsize)
    g.array(i)
    return np.ndarray((a['count'], n), dtype=dt, buffer=g.b, offset=off, strides=(stride, dt.itemsize)).copy()


def slots(mat):
    pbr = mat.get('pbrMetallicRoughness', {})
    for owner, name in [
        (pbr, 'baseColorTexture'),
        (pbr, 'metallicRoughnessTexture'),
        (mat, 'normalTexture'),
        (mat, 'occlusionTexture'),
        (mat, 'emissiveTexture')
    ]:
        if name in owner:
            yield owner[name]


def live_nodes(g):
    found = set()

    def walk(i, stack):
        if not isinstance(i, int) or not 0 <= i < len(g.j['nodes']) or i in stack:
            raise ValueError('Invalid node reference or cycle.')
        if i in found:
            return
        found.add(i)
        for ch in g.j['nodes'][i].get('children', []):
            walk(ch, stack | {i})
    for scene in g.j.get('scenes', []):
        for i in scene.get('nodes', []):
            walk(i, set())
    return sorted(found)


def signature(g):
    guard(g.j)
    live_nodes(g)
    memo = {}

    def material(i):
        m = copy.deepcopy(g.j['materials'][i])
        for info in slots(m):
            t = copy.deepcopy(g.j['textures'][info.pop('index')])
            im = copy.deepcopy(g.j['images'][t.pop('source')])
            view = g.j['bufferViews'][im.pop('bufferView')]
            off = view.get('byteOffset', 0)
            im['payload_sha256'] = digest(bytes(g.b[off:off + view['byteLength']]))
            t['image'] = im
            if 'sampler' in t:
                t['sampler'] = g.j['samplers'][t['sampler']]
            info['texture'] = t
        return m

    def mesh(i):
        m = copy.deepcopy(g.j['meshes'][i])
        for p in m['primitives']:
            attrs = p.pop('attributes')
            idx = raw(g, p.pop('indices')).ravel().astype(np.int64) if 'indices' in p else np.arange(len(raw(g, attrs['POSITION'])))
            p['corners'] = {}
            for name, ai in sorted(attrs.items()):
                a = g.j['accessors'][ai]
                values = raw(g, ai)[idx]
                p['corners'][name] = {
                    'component': a['componentType'],
                    'type': a['type'],
                    'normalized': a.get('normalized', False),
                    'count': len(idx),
                    'sha256': digest(values.tobytes())
                }
            if 'material' in p:
                p['material'] = material(p['material'])
        return m

    def node(i):
        if i in memo:
            return memo[i]
        n = copy.deepcopy(g.j['nodes'][i])
        if 'mesh' in n:
            n['mesh'] = mesh(n['mesh'])
        if 'camera' in n:
            n['camera'] = g.j['cameras'][n['camera']]
        if 'children' in n:
            n['children'] = [node(ch) for ch in n['children']]
        memo[i] = digest(key(n).encode())
        return memo[i]
    scenes = copy.deepcopy(g.j['scenes'])
    for s in scenes:
        s['nodes'] = [node(i) for i in s.get('nodes', [])]
    return digest(key({'scene': g.j.get('scene', 0), 'scenes': scenes}).encode())


def stats(path):
    path = Path(path)
    g = GLB.load(path)
    prims = [p for m in g.j.get('meshes', []) for p in m['primitives']]
    pos = {p['attributes']['POSITION'] for p in prims}
    idx = {p['indices'] for p in prims if 'indices' in p}
    drawn = 0
    calls = 0
    for i in g.worlds():
        n = g.j['nodes'][i]
        if 'mesh' not in n:
            continue
        for p in g.j['meshes'][n['mesh']]['primitives']:
            count = g.j['accessors'][p['indices'] if 'indices' in p else p['attributes']['POSITION']]['count']
            drawn += count // 3
            calls += 1
    return {
        'bytes': path.stat().st_size,
        'buffer_bytes': len(g.b),
        'nodes': len(g.j['nodes']),
        'meshes': len(g.j.get('meshes', [])),
        'unique_vertices': sum((g.j['accessors'][i]['count'] for i in pos)),
        'drawn_triangles': drawn,
        'primitive_instances': calls,
        'index_bytes': sum((g.j['accessors'][i]['count'] * np.dtype(DT[g.j['accessors'][i]['componentType']]).itemsize for i in idx)),
        'images': len(g.j.get('images', [])),
        'image_bytes': sum((len(g.image_bytes(i)) for i in range(len(g.j.get('images', [])))))
    }


def compact(g):
    guard(g.j)
    doc = copy.deepcopy(g.j)
    doc.update({n: [] for n in [
        'nodes',
        'meshes',
        'materials',
        'textures',
        'images',
        'samplers',
        'accessors',
        'bufferViews'
    ]})
    out = GLB(doc)
    maps = {n: {} for n in ['nodes', 'meshes', 'materials', 'textures', 'images', 'samplers']}
    views = {}
    accessors = {}

    def view(data, target=None):
        k = (target, digest(data))
        if k not in views:
            views[k] = out.view(data, target)
        return views[k]

    def acc(values, meta, target):
        a = copy.deepcopy(meta)
        a.pop('bufferView', None)
        a.pop('byteOffset', None)
        a['count'] = len(values)
        if 'min' in a:
            a['min'] = values.min(axis=0).tolist()
        if 'max' in a:
            a['max'] = values.max(axis=0).tolist()
        data = np.ascontiguousarray(values).tobytes()
        k = (key(a), target, digest(data))
        if k not in accessors:
            a['bufferView'] = view(data, target)
            accessors[k] = len(out.j['accessors'])
            out.j['accessors'].append(a)
        return accessors[k]

    def copy_item(kind, i):
        if i in maps[kind]:
            return maps[kind][i]
        d = copy.deepcopy(g.j[kind][i])
        if kind == 'images':
            d['bufferView'] = view(g.image_bytes(i))
        elif kind == 'textures':
            d['source'] = copy_item('images', d['source'])
            if 'sampler' in d:
                d['sampler'] = copy_item('samplers', d['sampler'])
        elif kind == 'materials':
            for info in slots(d):
                info['index'] = copy_item('textures', info['index'])
        elif kind == 'meshes':
            for p in d['primitives']:
                attrs = p['attributes']
                names = sorted(attrs)
                arrays = [raw(g, attrs[name]) for name in names]
                n = len(arrays[0])
                if any((len(a) != n for a in arrays)):
                    raise ValueError('Attribute counts do not match.')
                old = raw(g, p['indices']).ravel().astype(np.int64) if 'indices' in p else np.arange(n)
                if len(old) % 3 or np.any(old < 0) or np.any(old >= n):
                    raise ValueError('Invalid triangle indices.')
                used = np.unique(old)
                rows = np.concatenate(
                    [np.ascontiguousarray(a[used]).view(np.uint8).reshape(len(used), -1) for a in arrays],
                    axis=1
                )
                keys = np.ascontiguousarray(rows).view(np.dtype((np.void, rows.shape[1]))).ravel()
                _, first, inv = np.unique(keys, return_index=True, return_inverse=True)
                order = np.argsort(first)
                rank = np.empty(len(order), dtype=np.int64)
                rank[order] = np.arange(len(order))
                remap = np.empty(n, dtype=np.int64)
                remap[used] = rank[inv]
                keep = used[first[order]]
                for name, values in zip(names, arrays):
                    attrs[name] = acc(values[keep], g.j['accessors'][attrs[name]], 34962)
                new = remap[old]
                short = int(new.max()) < 65535
                values = new.astype('<u2' if short else '<u4').reshape(-1, 1)
                meta = {'componentType': 5123 if short else 5125, 'count': len(new), 'type': 'SCALAR'}
                p['indices'] = acc(values, meta, 34963)
                if 'material' in p:
                    p['material'] = copy_item('materials', p['material'])
        maps[kind][i] = len(out.j[kind])
        out.j[kind].append(d)
        return maps[kind][i]
    nodes = live_nodes(g)
    maps['nodes'] = {old: new for new, old in enumerate(nodes)}
    for i in nodes:
        n = copy.deepcopy(g.j['nodes'][i])
        if 'mesh' in n:
            n['mesh'] = copy_item('meshes', n['mesh'])
        if 'children' in n:
            n['children'] = [maps['nodes'][ch] for ch in n['children']]
        out.j['nodes'].append(n)
    for scene in out.j['scenes']:
        scene['nodes'] = [maps['nodes'][i] for i in scene.get('nodes', [])]
    return out


def optimize(src, dst):
    """Compact GLB references only after checking equivalent rendered semantics."""
    src, dst = (Path(src).resolve(), Path(dst).resolve())
    if src == dst:
        raise ValueError('Optimization is non-destructive. Choose a different output path.')
    if dst.exists():
        raise FileExistsError('Optimization output already exists: ' + str(dst))
    report = check(src)
    if not report['passed']:
        raise ValueError('Input failed validation: ' + '; '.join(report['errors']))
    g = GLB.load(src)
    before = signature(g)
    out = compact(g)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=dst.parent, prefix='.opt_') as temp:
        temp_path = out.save(Path(temp) / 'model.glb')
        valid = check(temp_path)
        after = signature(GLB.load(temp_path))
        if not valid['passed'] or before != after:
            raise RuntimeError('Lossless verification failed; no optimized model was published.')
        used = temp_path.stat().st_size < src.stat().st_size
        dst.write_bytes((temp_path if used else src).read_bytes())
    a, b = (stats(src), stats(dst))
    result = {
        'mode': 'exact',
        'applied': used,
        'before': a,
        'after': b,
        'saved_bytes': a['bytes'] - b['bytes'],
        'saved_percent': round((1 - b['bytes'] / a['bytes']) * 100, 3),
        'surface_signature_before': before,
        'surface_signature_after': after,
        'surface_signature_equal': before == after,
        'validation_passed': valid['passed'],
        'source_sha256': file_hash(src),
        'output_sha256': file_hash(dst),
        'preserved': [
            'ordered triangle-corner attribute bytes',
            'texture image bytes',
            'material settings and names',
            'all scene hierarchies and node names',
            'node transforms'
        ],
        'not_performed': [
            'decimation',
            'quantization',
            'texture resizing or re-encoding',
            'LOD generation',
            'GPU instancing'
        ],
        'scope': 'Core static glTF only. Export compaction may change indices and discard unreachable resources; keep the editable source.'
    }
    return result
