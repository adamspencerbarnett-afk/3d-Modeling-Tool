"""File hashing shared by build, validation, and release checks."""
import hashlib
from pathlib import Path


def digest(path: str | Path) -> str:
    """Hash a file in bounded chunks instead of loading its full contents."""
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()
