"""Build mesh primitives and read or write self-contained static GLB files.

Low-level lathe primitives are Z-axis; the recipe adapter converts to Y-up."""

from __future__ import annotations
import copy
import io
import json
import struct
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.interpolate import make_interp_spline
from scipy.spatial import ConvexHull
from scipy.spatial.transform import Rotation
from agent import VERSION
# glTF uses little-endian numeric component types and four-byte chunk alignment.
DT = {5120: 'i1', 5121: 'u1', 5122: '<i2', 5123: '<u2', 5125: '<u4', 5126: '<f4'}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def unit(a):
    a = np.asarray(a, dtype=np.float64)
    d = np.linalg.norm(a, axis=-1, keepdims=True)
    if np.any(d < 1e-14):
        raise ValueError('A direction vector has zero length.')
    return a / d


def matrix(pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
    p, r, s = (np.asarray(pos, float), np.asarray(rot, float), np.asarray(scale, float))
    if p.shape != (3,) or r.shape != (3,) or s.shape != (3,):
        raise ValueError('Position, Euler rotation and scale need three values each.')
    if not np.all(np.isfinite([p, r, s])) or np.any(s <= 0):
        raise ValueError('Transforms must be finite, with strictly positive scales.')
    m = np.eye(4)
    m[:3, :3] = Rotation.from_euler('xyz', r, degrees=True).as_matrix() @ np.diag(s)
    m[:3, 3] = p
    return m


def node_matrix(n):
    """Convert glTF column-major matrices or TRS fields to a NumPy transform."""
    if 'matrix' in n:
        m = np.asarray(n['matrix'], float).reshape(4, 4, order='F')
    else:
        m = np.eye(4)
        m[:3, :3] = Rotation.from_quat(n.get('rotation', [0, 0, 0, 1])).as_matrix() @ np.diag(n.get('scale', [1, 1, 1]))
        m[:3, 3] = n.get('translation', [0, 0, 0])
    if not np.all(np.isfinite(m)) or abs(np.linalg.det(m[:3, :3])) < 1e-12:
        raise ValueError('Invalid or singular node transform.')
    return m


@dataclass
class Mesh:
    """Positions, triangle indices, per-corner normals, and primary UV coordinates."""
    v: np.ndarray
    f: np.ndarray
    n: np.ndarray
    uv: np.ndarray

    def transformed(self, m):
        """Transform normals correctly under nonuniform scaling and mirrored instances."""
        v = self.v @ m[:3, :3].T + m[:3, 3]
        # Row-vector normals use the inverse matrix; positions use its transpose.
        n = unit(self.n @ np.linalg.inv(m[:3, :3]))
        f = self.f[:, ::-1].copy() if np.linalg.det(m[:3, :3]) < 0 else self.f.copy()
        return Mesh(v, f, n, self.uv.copy())


def flat(v, f):
    v, f = (np.asarray(v, float), np.asarray(f, np.uint32))
    tri = v[f]
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    good = np.linalg.norm(n, axis=1) > 1e-13
    tri, n = (tri[good], unit(n[good]))
    lo, span = (v.min(0), np.maximum(np.ptp(v, axis=0), 1e-10))
    uv = np.empty((len(tri), 3, 2))
    for axis in range(3):
        mask = np.argmax(np.abs(n), axis=1) == axis
        axes = [a for a in range(3) if a != axis]
        uv[mask] = ((tri[mask] - lo) / span)[:, :, axes]
    return Mesh(
        tri.reshape(-1, 3),
        np.arange(len(tri) * 3, dtype=np.uint32).reshape(-1, 3),
        np.repeat(n, 3, axis=0),
        uv.reshape(-1, 2)
    )


def hull(points):
    p = np.unique(np.asarray(points, float), axis=0)
    h = ConvexHull(p)
    f = h.simplices.copy()
    a = p[f]
    n = np.cross(a[:, 1] - a[:, 0], a[:, 2] - a[:, 0])
    flip = np.einsum('ij,ij->i', n, h.equations[:, :3]) < 0
    f[flip] = f[flip, ::-1]
    return flat(p, f)


def box(size=(1, 1, 1), bevel=0.035):
    d = np.asarray(size, float) * 0.5
    if d.shape != (3,) or np.any(d <= 0) or bevel < 0 or (bevel >= d.min()):
        raise ValueError('Box sizes must be positive; bevel must be smaller than every half-size.')
    pts = []
    for x in (-1, 1):
        for y in (-1, 1):
            for z in (-1, 1):
                s = np.array([x, y, z])
                if bevel == 0:
                    pts.append(s * d)
                else:
                    for axis in range(3):
                        q = d - bevel
                        q[axis] = d[axis]
                        pts.append(s * q)
    return hull(pts)


def plate(points, depth=0.08):
    p = np.asarray(points, float)
    if p.ndim != 2 or p.shape[1] != 2 or len(p) < 3 or (depth <= 0):
        raise ValueError('A plate needs at least three XY points and a positive depth.')
    h = ConvexHull(p)
    if len(h.vertices) != len(p):
        raise ValueError('Plate outlines must be strictly convex; concave profiles are not supported.')
    return hull([[x, y, z] for x, y in p for z in (-depth / 2, depth / 2)])


def merge(parts):
    if not parts:
        raise ValueError('Cannot merge an empty mesh list.')
    v, n, uv, f, offset = ([], [], [], [], 0)
    for p in parts:
        v.append(p.v)
        n.append(p.n)
        uv.append(p.uv)
        f.append(p.f + offset)
        offset += len(p.v)
    return Mesh(np.concatenate(v), np.concatenate(f), np.concatenate(n), np.concatenate(uv))


def lathe(profile, steps=48):
    """Revolve radius/height samples around the low-level Z axis."""
    if steps < 3:
        raise ValueError('A lathe needs at least three radial steps.')
    p = np.asarray(profile, float)
    if p.ndim != 2 or p.shape[1] != 2 or np.any(p[:, 0] < 0):
        raise ValueError('Lathe profiles are radius/height pairs with nonnegative radii.')
    theta = np.linspace(0, 2 * np.pi, steps + 1)
    co, si = (np.cos(theta), np.sin(theta))
    out, total = ([], max(np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1)), 1e-12))
    dist = 0.0
    for a, b in zip(p[:-1], p[1:]):
        dr, dz = b - a
        seg = np.hypot(dr, dz)
        if seg < 1e-12:
            continue
        v = np.concatenate([np.column_stack([r * co, r * si, np.full(steps + 1, z)]) for r, z in (a, b)])
        no = np.column_stack([dz * co, dz * si, np.full(steps + 1, -dr)]) / seg
        n = np.concatenate([no, no])
        uv = np.concatenate([np.column_stack([
            theta / (2 * np.pi),
            np.full(steps + 1, d / total)
        ]) for d in (dist, dist + seg)])
        f = []
        for i in range(steps):
            f += [[i, i + 1, i + steps + 1], [i + 1, i + steps + 2, i + steps + 1]]
        f = np.asarray(f, np.uint32)
        tri = v[f]
        f = f[np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1) > 1e-13]
        if len(f):
            out.append(Mesh(v, f, n, uv))
        dist += seg
    return merge(out)


def cylinder(radius=0.1, length=0.3, steps=48, inner=0.0, top=None):
    top = radius if top is None else top
    if radius <= 0 or length <= 0 or top <= 0 or (inner < 0) or (inner >= min(radius, top)):
        raise ValueError('Invalid cylinder dimensions.')
    return lathe(
        [
            (inner, -length / 2),
            (radius, -length / 2),
            (top, length / 2),
            (inner, length / 2),
            (inner, -length / 2)
        ],
        steps
    )


def hose(points, radius=0.025, steps=12, samples=48):
    p = np.asarray(points, float)
    if p.ndim != 2 or p.shape[1] != 3 or len(p) < 2 or (radius <= 0) or (samples < 2) or (steps < 3):
        raise ValueError('Invalid hose path or dimensions.')
    ds = np.linalg.norm(np.diff(p, axis=0), axis=1)
    if np.any(ds < 1e-10):
        raise ValueError('Consecutive hose control points must be distinct.')
    s = np.r_[0.0, np.cumsum(ds)]
    t = np.linspace(0, s[-1], samples)
    pts = make_interp_spline(s, p, k=min(3, len(p) - 1))(t)
    tang = unit(np.gradient(pts, axis=0))
    theta = np.linspace(0, 2 * np.pi, steps + 1)
    v, n, uv = ([], [], [])
    u = unit(np.cross(tang[0], np.eye(3)[np.argmin(np.abs(tang[0]))]))
    for i, (c, w) in enumerate(zip(pts, tang)):
        u = unit(u - w * np.dot(u, w))
        vv = np.cross(w, u)
        ring = np.cos(theta)[:, None] * u + np.sin(theta)[:, None] * vv
        v.extend(c + radius * ring)
        n.extend(ring)
        uv.extend(np.column_stack([
            theta / (2 * np.pi),
            np.full(steps + 1, t[i] / max(2 * np.pi * radius, 1e-08))
        ]))
    f = []
    for i in range(samples - 1):
        for j in range(steps):
            a = i * (steps + 1) + j
            b = a + steps + 1
            f += [[a, a + 1, b], [a + 1, b + 1, b]]
    body = Mesh(np.array(v), np.array(f, np.uint32), np.array(n), np.array(uv))
    caps = []
    for i, sign in ((0, -1), (samples - 1, 1)):
        ring = body.v[i * (steps + 1):(i + 1) * (steps + 1)]
        cv = np.vstack([pts[i], ring])
        cf = np.array([[0, j + 1, j + 2] for j in range(steps)], np.uint32)
        if sign < 0:
            cf = cf[:, ::-1]
        caps.append(flat(cv, cf))
    return merge([body] + caps)


class GLB:

    """A JSON document plus embedded bytes for the supported glTF 2 subset."""
    def __init__(self, doc=None, data=b''):
        self.j = copy.deepcopy(doc) if doc is not None else {'asset': {'version': '2.0', 'generator': f'AI 3D Kit {VERSION}'}, 'scene': 0, 'scenes': [{'nodes': []}], 'nodes': [], 'meshes': [], 'materials': [], 'textures': [], 'images': [], 'samplers': [], 'accessors': [], 'bufferViews': [], 'buffers': [{'byteLength': 0}]}
        self.b = bytearray(data)

    @classmethod
    def load(cls, path):
        """Read aligned GLB chunks and reject unsupported or external-buffer features."""
        p = Path(path)
        raw = p.read_bytes()
        if len(raw) < 20:
            raise ValueError('File is too short to be a GLB.')
        magic, ver, total = struct.unpack_from('<4sII', raw)
        if magic != b'glTF' or ver != 2 or total != len(raw):
            raise ValueError('Invalid GLB 2 header or file size.')
        off, chunks = (12, [])
        while off < len(raw):
            if off + 8 > len(raw):
                raise ValueError('Truncated GLB chunk header.')
            length, kind = struct.unpack_from('<II', raw, off)
            if length % 4 or off + 8 + length > len(raw):
                raise ValueError('Invalid GLB chunk length or alignment.')
            chunks.append((kind, raw[off + 8:off + 8 + length]))
            off += 8 + length
        if len(chunks) not in (1, 2) or chunks[0][0] != 1313821514 or (len(chunks) == 2 and chunks[1][0] != 5130562):
            raise ValueError('Only standard JSON plus optional BIN GLB chunks are supported.')
        j = json.loads(chunks[0][1].decode('utf-8'))
        data = chunks[1][1] if len(chunks) == 2 else b''
        if len(j.get('buffers', [])) != 1 or 'uri' in j['buffers'][0]:
            raise ValueError('This kit requires a self-contained GLB with exactly one embedded buffer.')
        length = j['buffers'][0]['byteLength']
        if length > len(data) or len(data) - length > 3:
            raise ValueError('Embedded buffer size is inconsistent.')
        if any(('uri' in im for im in j.get('images', []))):
            raise ValueError('External/data-URI images are not supported; embed images in the GLB first.')
        if j.get('skins') or j.get('animations'):
            raise ValueError('Editing rigged or animated models is intentionally disabled in this static-asset kit.')
        if j.get('extensionsRequired'):
            raise ValueError('Required glTF extensions are not supported by this editor.')
        blocked = {'KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'EXT_mesh_gpu_instancing'}
        if blocked.intersection(j.get('extensionsUsed', [])):
            raise ValueError('Compressed or GPU-instanced GLBs must be expanded before use.')
        if any(('sparse' in a or a['type'] not in NC for a in j.get('accessors', []))):
            raise ValueError('Sparse accessors and MAT2/MAT3 accessors are not supported.')
        if any((p.get('mode', 4) != 4 or p.get('targets') for m in j.get('meshes', []) for p in m['primitives'])):
            raise ValueError('Only triangle meshes without morph targets are supported.')
        return cls(j, data[:length])

    def save(self, path):
        """Write a self-contained GLB with aligned JSON and binary chunks."""
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.j['buffers'] = [{'byteLength': len(self.b)}]
        j = json.dumps(self.j, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')
        j += b' ' * (-len(j) % 4)
        b = bytes(self.b) + b'\x00' * (-len(self.b) % 4)
        raw = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(j) + 8 + len(b))
        raw += struct.pack('<II', len(j), 1313821514) + j + struct.pack('<II', len(b), 5130562) + b
        tmp = p.with_name(p.name + '.tmp')
        tmp.write_bytes(raw)
        tmp.replace(p)
        return p

    def view(self, data, target=None):
        self.b.extend(b'\x00' * (-len(self.b) % 4))
        d = {'buffer': 0, 'byteOffset': len(self.b), 'byteLength': len(data)}
        if target is not None:
            d['target'] = target
        self.b.extend(data)
        arr = self.j.setdefault('bufferViews', [])
        arr.append(d)
        return len(arr) - 1

    def accessor(self, array, kind, target=34962):
        a = np.ascontiguousarray(array, dtype='<u4' if kind == 'SCALAR' else '<f4')
        if not a.size or not np.all(np.isfinite(a)):
            raise ValueError('Empty or non-finite geometry.')
        if a.ndim != (1 if kind == 'SCALAR' else 2) or (kind != 'SCALAR' and a.shape[1] != NC[kind]):
            raise ValueError('Accessor shape does not match its type.')
        d = {
            'bufferView': self.view(a.tobytes(), target),
            'componentType': 5125 if kind == 'SCALAR' else 5126,
            'count': len(a),
            'type': kind
        }
        if kind == 'VEC3':
            d['min'] = a.min(axis=0).tolist()
            d['max'] = a.max(axis=0).tolist()
        arr = self.j.setdefault('accessors', [])
        arr.append(d)
        return len(arr) - 1

    def array(self, index):
        a = self.j['accessors'][index]
        if 'bufferView' not in a:
            raise ValueError('Accessor has no bufferView.')
        v = self.j['bufferViews'][a['bufferView']]
        if v.get('buffer', 0) != 0:
            raise ValueError('Only buffer zero is supported.')
        dtype, width = (np.dtype(DT[a['componentType']]), NC[a['type']])
        offset = v.get('byteOffset', 0) + a.get('byteOffset', 0)
        row = dtype.itemsize * width
        stride = v.get('byteStride', row)
        end = offset + max(a['count'] - 1, 0) * stride + row
        if a['count'] <= 0 or stride < row or end > len(self.b) or (end > v.get('byteOffset', 0) + v['byteLength']):
            raise ValueError('Accessor exceeds its bufferView or has invalid stride/count.')
        x = np.ndarray(
            (a['count'], width),
            dtype=dtype,
            buffer=self.b,
            offset=offset,
            strides=(stride, dtype.itemsize)
        ).copy()
        if a.get('normalized') and a['componentType'] != 5126:
            info = np.iinfo(dtype)
            x = np.maximum(
                x.astype(np.float64) / info.max,
                -1
            ) if info.min < 0 else x.astype(np.float64) / info.max
        return x[:, 0] if width == 1 else x

    def find(self, kind, name):
        items = self.j.get(kind, [])
        if isinstance(name, int):
            if 0 <= name < len(items):
                return name
            raise ValueError(f'{kind} index is out of range: {name}')
        found = [i for i, x in enumerate(items) if x.get('name') == name]
        if len(found) != 1:
            raise ValueError(f'Expected exactly one {kind} named {name!r}; found {len(found)}. Use an index for duplicate names.')
        return found[0]

    def material(
        self,
        name,
        color=(0.4, 0.4, 0.4, 1),
        metal=0.0,
        rough=0.6,
        emission=None,
        maps=None,
        normal_scale=1,
        wrap='repeat'
    ):
        """Create a core metallic-roughness material and embed its supplied texture maps."""
        if any((m.get('name') == name for m in self.j.get('materials', []))):
            raise ValueError(f'Material already exists: {name}')
        if len(color) != 4 or min(color) < 0 or max(color) > 1 or (not 0 <= metal <= 1) or (not 0 <= rough <= 1):
            raise ValueError('Invalid material factors.')
        d = {
            'name': name,
            'pbrMetallicRoughness': {
                'baseColorFactor': [float(x) for x in color],
                'metallicFactor': float(metal),
                'roughnessFactor': float(rough)
            }
        }
        if emission is not None:
            if len(emission) != 3 or min(emission) < 0 or max(emission) > 1:
                raise ValueError('Emission needs three linear values in [0, 1].')
            d['emissiveFactor'] = [float(x) for x in emission]
        for key, path in (maps or {}).items():
            tex = self.texture(Path(path).read_bytes(), str(Path(path).stem))
            if key == 'base':
                d['pbrMetallicRoughness']['baseColorTexture'] = {'index': tex}
            elif key == 'normal':
                d['normalTexture'] = {'index': tex}
            elif key == 'orm':
                d['pbrMetallicRoughness']['metallicRoughnessTexture'] = {'index': tex}
                d['occlusionTexture'] = {'index': tex}
            elif key == 'emissive':
                d['emissiveTexture'] = {'index': tex}
                if emission is None:
                    d['emissiveFactor'] = [1, 1, 1]
            else:
                raise ValueError(f'Unknown map key: {key}')
            mode = {'repeat': 10497, 'clamp': 33071, 'mirror': 33648}.get(wrap)
            if mode is None:
                raise ValueError('Unknown texture wrap mode.')
            sam = {'magFilter': 9729, 'minFilter': 9987, 'wrapS': mode, 'wrapT': mode}
            if sam not in self.j['samplers']:
                self.j['samplers'].append(sam)
            self.j['textures'][tex]['sampler'] = self.j['samplers'].index(sam)
        if 'normalTexture' in d:
            d['normalTexture']['scale'] = float(normal_scale)
        arr = self.j.setdefault('materials', [])
        arr.append(d)
        return len(arr) - 1

    def image_bytes(self, index):
        im = self.j['images'][index]
        v = self.j['bufferViews'][im['bufferView']]
        start = v.get('byteOffset', 0)
        return bytes(self.b[start:start + v['byteLength']])

    def texture(self, data, name, template=None):
        with Image.open(io.BytesIO(data)) as im:
            im.verify()
            mime = {'PNG': 'image/png', 'JPEG': 'image/jpeg'}.get(im.format)
        if mime is None:
            raise ValueError('Only PNG and JPEG textures are supported.')
        images = self.j.setdefault('images', [])
        images.append({'name': name, 'bufferView': self.view(data), 'mimeType': mime})
        if not self.j.get('samplers'):
            self.j['samplers'] = [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497}]
        t = copy.deepcopy(self.j['textures'][template]) if template is not None else {'sampler': 0}
        t['source'] = len(images) - 1
        textures = self.j.setdefault('textures', [])
        textures.append(t)
        return len(textures) - 1

    def add_mesh(self, name, mesh, material, parent=None, pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
        if any((n.get('name') == name for n in self.j['nodes'])):
            raise ValueError(f'Node already exists: {name}')
        mi = self.find('materials', material)
        mesh = mesh.transformed(matrix())
        if np.min(mesh.f) < 0 or np.max(mesh.f) >= len(mesh.v):
            raise ValueError('Mesh indices are out of range.')
        attrs = {
            'POSITION': self.accessor(mesh.v, 'VEC3'),
            'NORMAL': self.accessor(mesh.n, 'VEC3'),
            'TEXCOORD_0': self.accessor(mesh.uv, 'VEC2')
        }
        prim = {
            'attributes': attrs,
            'indices': self.accessor(mesh.f.ravel(), 'SCALAR', 34963),
            'material': mi,
            'mode': 4
        }
        meshes = self.j.setdefault('meshes', [])
        meshes.append({'name': name, 'primitives': [prim]})
        return self.group(name, parent, pos, rot, scale, len(meshes) - 1)

    def group(self, name, parent=None, pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1), mesh=None):
        if any((n.get('name') == name for n in self.j['nodes'])):
            raise ValueError(f'Node already exists: {name}')
        m = matrix(pos, rot, scale)
        n = {
            'name': name,
            'translation': m[:3, 3].tolist(),
            'rotation': Rotation.from_euler('xyz', rot, degrees=True).as_quat().tolist(),
            'scale': list(scale)
        }
        if mesh is not None:
            n['mesh'] = mesh
        ni = len(self.j['nodes'])
        if parent is None:
            self.j['scenes'][self.j.get('scene', 0)].setdefault('nodes', []).append(ni)
        else:
            pi = self.find('nodes', parent)
            self.j['nodes'][pi].setdefault('children', []).append(ni)
        self.j['nodes'].append(n)
        return ni

    def worlds(self):
        nodes = self.j['nodes']
        out = {}
        visiting = set()

        def walk(i, parent):
            if not 0 <= i < len(nodes) or i in visiting or i in out:
                raise ValueError('Scene has a cycle, repeated node, or invalid node index.')
            visiting.add(i)
            m = parent @ node_matrix(nodes[i])
            out[i] = m
            for ch in nodes[i].get('children', []):
                walk(ch, m)
            visiting.remove(i)
        for i in self.j['scenes'][self.j.get('scene', 0)].get('nodes', []):
            walk(i, np.eye(4))
        return out

    def inventory(self):
        worlds = self.worlds()
        return {
            'nodes': [
                {
                    'index': i,
                    'name': n.get('name', ''),
                    'mesh': n.get('mesh'),
                    'children': n.get('children', []),
                    'active': i in worlds,
                    'world_origin_m': worlds[i][:3, 3].tolist() if i in worlds else None
                } for i,
                n in enumerate(self.j['nodes'])
            ],
            'materials': [
                {'index': i, 'name': m.get('name', ''), 'settings': m} for i,
                m in enumerate(self.j.get('materials', []))
            ],
            'images': [
                {'index': i, 'name': im.get('name', ''), 'mimeType': im.get('mimeType')} for i,
                im in enumerate(self.j.get('images', []))
            ]
        }
