"""Geometry and GLB primitives for the supported static glTF subset."""


