"""Apply node-scoped material replacements while preserving other instances."""

from __future__ import annotations
import copy
import hashlib
import json
import numpy as np
from agent.geom import tangents
from agent.mats import make
from agent.uv import atlas, metric, stats
from core.mesh import Mesh, unit


def mesh(g, prim):
    a = prim['attributes']
    v = g.array(a['POSITION']).astype(float)
    f = (g.array(prim['indices']) if 'indices' in prim else np.arange(len(v))).reshape(-1, 3)
    uv = g.array(a['TEXCOORD_0']) if 'TEXCOORD_0' in a else np.zeros((len(v), 2))
    if 'NORMAL' in a:
        n = g.array(a['NORMAL'])
    else:
        n = np.zeros_like(v)
        tri = v[f]
        fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        for i in range(3):
            np.add.at(n, f[:, i], fn)
        n[np.linalg.norm(n, axis=1) < 1e-12] = [0, 1, 0]
        n = unit(n)
    return Mesh(v, f, n, uv)


def apply(g, job, folder):
    """Replace selected materials on private mesh copies, not all shared nodes."""
    cache, rows, done = ({}, [], set())
    area = 0
    for spec in job['assign']:
        key = spec['node']
        if key == '*':
            ids = [i for i, n in enumerate(g.j['nodes']) if 'mesh' in n]
        elif isinstance(key, int):
            ids = [key] if 0 <= key < len(g.j['nodes']) else []
        else:
            ids = [i for i, n in enumerate(g.j['nodes']) if n.get('name') == key]
        if not ids or (key != '*' and len(ids) != 1):
            raise ValueError(f'Texture assignment must match one node or use *: {key}')
        if spec['mat'] not in job['materials']:
            raise ValueError('Unknown texture material: ' + spec['mat'])
        for i in ids:
            if i in done:
                raise ValueError('A mesh node may be assigned only once per texture task.')
            done.add(i)
            node = g.j['nodes'][i]
            if 'mesh' not in node:
                raise ValueError('Texture assignment needs a mesh node, not a group.')
            src = copy.deepcopy(g.j['meshes'][node['mesh']])
            cfg = job['materials'][spec['mat']]
            for prim in src['primitives']:
                m = mesh(g, prim)
                original_f = m.f.copy()
                uv_mode = spec.get('uv', 'keep')
                if uv_mode == 'atlas':
                    m = atlas(m)
                elif uv_mode == 'metric':
                    m = metric(m, spec.get('uv_size', 1))
                elif 'TEXCOORD_0' not in prim['attributes'] or stats(m)['zero_uv_triangles']:
                    raise ValueError('Missing or degenerate UVs. Choose uv=atlas or uv=metric explicitly.')
                if (cfg.get('edge_wear', 0) or spec.get('decals')) and uv_mode != 'atlas':
                    raise ValueError('Mesh-aware wear and projected decals on imports require uv=atlas.')
                h = hashlib.sha256(json.dumps([cfg, spec.get('decals')], sort_keys=True).encode())
                custom = cfg.get('edge_wear', 0) or spec.get('decals')
                if custom:
                    for array in [m.v, m.f, m.n, m.uv]:
                        h.update(array.tobytes())
                key = h.hexdigest()[:20]
                if key not in cache:
                    size = cfg.get('tex_size', job.get('texture_size', 512))
                    area += size * size
                    if area > 16777216:
                        raise ValueError('Texture task exceeds 16 million baked texels. Lower tex_size.')
                    maps, meta = make(
                        cfg,
                        folder / 'textures' / key,
                        size,
                        cfg.get('seed', 42),
                        folder,
                        m if custom else None,
                        spec.get('decals')
                    )
                    name = 'texture_' + key
                    while any((a.get('name') == name for a in g.j.get('materials', []))):
                        name += '_'
                    mat = g.material(
                        name,
                        color=(1, 1, 1, 1),
                        metal=1,
                        rough=1,
                        emission=cfg.get('emission'),
                        maps=maps,
                        normal_scale=cfg.get('normal_scale', 1),
                        wrap=cfg.get('wrap', 'repeat')
                    )
                    cache[key] = mat
                    rows.append({'name': spec['mat'], 'material': mat, **meta})
                attrs = prim['attributes']
                if uv_mode != 'keep':
                    if 'COLOR_0' in attrs:
                        c = g.array(attrs['COLOR_0'])[original_f].reshape(
                            -1,
                            g.array(attrs['COLOR_0']).shape[-1]
                        )
                        attrs['COLOR_0'] = g.accessor(c, 'VEC' + str(c.shape[1]))
                    attrs['POSITION'] = g.accessor(m.v, 'VEC3')
                    attrs['NORMAL'] = g.accessor(m.n, 'VEC3')
                    attrs['TEXCOORD_0'] = g.accessor(m.uv, 'VEC2')
                    prim['indices'] = g.accessor(m.f.ravel(), 'SCALAR', 34963)
                attrs['TANGENT'] = g.accessor(tangents(m), 'VEC4')
                prim['material'] = cache[key]
            node['mesh'] = len(g.j['meshes'])
            g.j['meshes'].append(src)
    return rows
