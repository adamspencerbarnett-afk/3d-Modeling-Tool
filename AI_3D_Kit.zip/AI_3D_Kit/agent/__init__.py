"""Single source of release version metadata."""

VERSION = '11.3-kit'
DATE = '2026-09-18'
