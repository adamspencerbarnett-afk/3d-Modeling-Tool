"""Generate metric projections and packed planar charts for hard-surface meshes.

This module is not a seamless organic UV unwrap solver."""

from __future__ import annotations
import numpy as np
from core.mesh import Mesh, unit


def metric(mesh, size=1.0):
    if not np.isfinite(size) or size <= 0:
        raise ValueError('uv_size must be positive and finite.')
    tri = mesh.v[mesh.f]
    n = unit(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]))
    uv = np.zeros((len(tri), 3, 2))
    for i, normal in enumerate(n):
        u, v = basis(normal)
        uv[i] = np.column_stack([tri[i] @ u, tri[i] @ v]) / size
    return split(mesh, uv)


def basis(n):
    a = int(np.argmax(np.abs(n)))
    if a == 0:
        u = np.array([0.0, 0.0, -1.0 if n[0] > 0 else 1.0])
    else:
        u = np.array([1.0 if n[a] > 0 or a == 1 else -1.0, 0.0, 0.0])
    u = unit(u - n * (u @ n))
    return (u, -np.cross(n, u))


def split(mesh, uv):
    return Mesh(
        mesh.v[mesh.f].reshape(-1, 3),
        np.arange(mesh.f.size, dtype=np.uint32).reshape(-1, 3),
        mesh.n[mesh.f].reshape(-1, 3),
        np.asarray(uv, float).reshape(-1, 2)
    )


def atlas(mesh, pad=0.006):
    """Pack planar charts with padding while retaining corresponding mesh attributes."""
    if not 0 < pad < 0.05:
        raise ValueError('Atlas padding must be between 0 and .05.')
    tri = mesh.v[mesh.f]
    fn = unit(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]))
    span = max(float(np.ptp(mesh.v, axis=0).max()), 1e-08)
    planes = np.column_stack([fn, np.einsum('ij,ij->i', fn, tri[:, 0]) / span])
    _, inverse = np.unique(np.round(planes, 7), axis=0, return_inverse=True)
    charts = []
    for k in range(int(inverse.max()) + 1):
        ids = np.flatnonzero(inverse == k)
        u, v = basis(fn[ids[0]])
        pts = tri[ids]
        coords = np.stack([pts @ u, pts @ v], axis=-1)
        lo = coords.min(axis=(0, 1))
        ext = np.maximum(coords.max(axis=(0, 1)) - lo, span * 1e-07)
        charts.append((ids, coords - lo, ext))
    if len(charts) > 4096:
        raise ValueError('Atlas exceeds 4096 planar charts. Supply authored UVs for dense curved meshes.')
    charts.sort(key=lambda row: float(row[2][1]), reverse=True)

    def pack(scale):
        x = y = row_h = 0.0
        result = []
        for _, _, ext in charts:
            w, h = ext * scale + 2 * pad
            if w > 1 or h > 1:
                return None
            if x + w > 1 + 1e-12:
                x, y, row_h = (0.0, y + row_h, 0.0)
            if y + h > 1 + 1e-12:
                return None
            result.append((x + pad, y + pad))
            x += w
            row_h = max(row_h, h)
        return result
    low, high = (0.0, 1 / max((max(c[2]) for c in charts)))
    if pack(low) is None:
        raise ValueError('Too many charts for the atlas padding; provide authored UVs.')
    for _ in range(45):
        mid = (low + high) / 2
        if pack(mid) is None:
            high = mid
        else:
            low = mid
    uv = np.empty((len(tri), 3, 2))
    for (ids, pts, _), offset in zip(charts, pack(low)):
        uv[ids] = pts * low + offset
    return split(mesh, uv)


def stats(mesh):
    tri = mesh.v[mesh.f]
    area = np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1) / 2
    uv = mesh.uv[mesh.f]
    a, b = (uv[:, 1] - uv[:, 0], uv[:, 2] - uv[:, 0])
    ua = np.abs(a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]) / 2
    bad = (ua < 1e-12) & (area > 1e-12)
    return {
        'triangles': len(area),
        'zero_uv_triangles': int(bad.sum()),
        'uv_min': mesh.uv.min(0).tolist(),
        'uv_max': mesh.uv.max(0).tolist(),
        'uv_area_sum': float(ua.sum()),
        'surface_area_m2': float(area.sum()),
        'overlap_checked': False
    }
