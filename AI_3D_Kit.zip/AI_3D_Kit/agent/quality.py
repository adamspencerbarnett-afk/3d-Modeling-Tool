"""Inspect UV/material links and optionally extract exact embedded image bytes."""

from __future__ import annotations
import hashlib
import io
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
from agent.paint import mesh
from agent.state import write
from agent.uv import stats
from core.mesh import GLB
SLOTS = {
    'base': ('pbrMetallicRoughness', 'baseColorTexture'),
    'normal': (None, 'normalTexture'),
    'orm': ('pbrMetallicRoughness', 'metallicRoughnessTexture'),
    'ao': (None, 'occlusionTexture'),
    'emissive': (None, 'emissiveTexture')
}


def inspect(model, folder=None):
    """Check texture/UV coverage and optionally extract exact images and channel sheets."""
    g = GLB.load(model)
    rows, uv_rows, issues, used = ([], [], [], set())
    for ni in g.worlds():
        node = g.j['nodes'][ni]
        if 'mesh' not in node:
            continue
        for pi, prim in enumerate(g.j['meshes'][node['mesh']]['primitives']):
            mat = g.j.get('materials', [])[prim['material']] if 'material' in prim else {}
            if 'material' in prim:
                used.add(prim['material'])
            slots = [
                mat.get(parent, {}).get(key) if parent else mat.get(key) for parent,
                key in SLOTS.values()
            ]
            has_maps = any(slots)
            if has_maps and 'TEXCOORD_0' not in prim['attributes']:
                issues.append({
                    'level': 'error',
                    'node': ni,
                    'message': 'Textured primitive has no TEXCOORD_0.'
                })
            m = mesh(g, prim)
            row = {
                'node': ni,
                'name': node.get('name', str(ni)),
                'primitive': pi,
                'material': prim.get('material'),
                'textured': has_maps,
                **stats(m)
            }
            uv_rows.append(row)
            if has_maps and row['zero_uv_triangles']:
                issues.append({
                    'level': 'error',
                    'node': ni,
                    'message': 'Textured primitive has zero-area UV triangles.'
                })
    thumbs = []
    image_cache = {}
    for i in sorted(used):
        mat = g.j['materials'][i]
        maps = {}
        for channel, (parent, key) in SLOTS.items():
            slot = mat.get(parent, {}).get(key) if parent else mat.get(key)
            if not slot:
                continue
            idx = g.j['textures'][slot['index']]['source']
            if idx not in image_cache:
                raw = g.image_bytes(idx)
                with Image.open(io.BytesIO(raw)) as im:
                    im.load()
                    rgb = im.convert('RGB')
                    a = np.asarray(rgb, np.float32) / 255
                    image_cache[idx] = (
                        raw,
                        rgb,
                        {
                            'image': idx,
                            'size': list(im.size),
                            'bytes': len(raw),
                            'sha256': hashlib.sha256(raw).hexdigest(),
                            'mean': a.mean(axis=(0, 1)).tolist(),
                            'std': a.std(axis=(0, 1)).tolist()
                        }
                    )
            raw, im, info = image_cache[idx]
            maps[channel] = dict(info)
            if folder:
                path = Path(folder) / f'mat_{i}' / (channel + ('.png' if raw[:8] == b'\x89PNG\r\n\x1a\n' else '.jpg'))
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)
                maps[channel]['file'] = path.relative_to(folder).as_posix()
            if channel != 'ao' or maps.get('orm', {}).get('image') != idx:
                thumbs.append((f"{i}: {mat.get('name', 'material')[:22]} / {channel}", im))
            if channel == 'normal':
                n = np.asarray(im, np.float32) / 127.5 - 1
                length = np.linalg.norm(n, axis=2)
                if np.mean((length < 0.6) | (length > 1.4)) > 0.1:
                    issues.append({
                        'level': 'warning',
                        'material': i,
                        'message': 'Normal map contains many non-unit vectors.'
                    })
        rows.append({
            'index': i,
            'name': mat.get('name', str(i)),
            'maps': maps,
            'base_factor': mat.get('pbrMetallicRoughness', {}).get('baseColorFactor', [1, 1, 1, 1]),
            'emission_factor': mat.get('emissiveFactor', [0, 0, 0]),
            'textured': bool(maps)
        })
    result = {
        'ok': not any((i['level'] == 'error' for i in issues)),
        'active_materials': len(used),
        'textured_materials': sum((bool(r['maps']) for r in rows)),
        'embedded_images_used': len(image_cache),
        'materials': rows,
        'uv': uv_rows,
        'issues': issues,
        'scope': 'Channel references, image decoding and UV degeneracy checks; not texture likeness, overlap, or aesthetic certification.'
    }
    if folder:
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        write(folder / 'textures.json', result)
        if thumbs:
            cols = min(4, len(thumbs))
            sheet = Image.new('RGB', (cols * 256, int(np.ceil(len(thumbs) / cols)) * 280), (23, 26, 30))
            draw = ImageDraw.Draw(sheet)
            font = ImageFont.load_default(size=12)
            for i, (name, im) in enumerate(thumbs):
                x, y = (i % cols * 256, i // cols * 280)
                sheet.paste(ImageOps.fit(im, (248, 248)), (x + 4, y + 4))
                draw.text((x + 5, y + 258), name, fill=(226, 231, 237), font=font)
            sheet.save(folder / 'contact.png')
    return result
