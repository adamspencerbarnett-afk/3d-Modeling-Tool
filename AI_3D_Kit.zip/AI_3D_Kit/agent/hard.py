"""Construct chamfered convex prisms without a general Boolean dependency."""

from __future__ import annotations
import numpy as np
from scipy.spatial import ConvexHull
from core.mesh import hull


def prism(points, depth=0.1, bevel=0.0, taper=1.0):
    """Extrude a convex outline with tapered or chamfered hard-surface edges."""
    p = np.asarray(points, float)
    if p.ndim != 2 or p.shape[1] != 2 or len(p) < 3 or (not np.isfinite(p).all()):
        raise ValueError('Prism points must contain at least three finite XY pairs.')
    if not np.isfinite(depth) or depth <= 0 or (not np.isfinite(bevel)) or (not 0 <= bevel < depth / 2):
        raise ValueError('Prism bevel must be nonnegative and smaller than half its depth.')
    h = ConvexHull(p)
    if len(h.vertices) != len(p):
        raise ValueError('Prism outline must be strictly convex without duplicate or interior points.')
    p = p[h.vertices]
    if not 0.1 <= taper <= 1 or not np.isfinite(taper):
        raise ValueError('Prism taper must be in [.1, 1].')

    def finish(q):
        q = np.asarray(q, float)
        y = (q[:, 1] - p[:, 1].min()) / max(float(np.ptp(p[:, 1])), 1e-12)
        q[:, 2] *= 1 - y * (1 - taper)
        return hull(q)
    if not bevel:
        return finish([[x, y, z] for x, y in p for z in [-depth / 2, depth / 2]])
    edge = np.roll(p, -1, axis=0) - p
    ns = np.column_stack([edge[:, 1], -edge[:, 0]])
    ns /= np.linalg.norm(ns, axis=1, keepdims=True)
    d = np.einsum('ij,ij->i', ns, p) - bevel
    inset = []
    for i in range(len(p)):
        inset.append(np.linalg.solve(np.stack([ns[i - 1], ns[i]]), [d[i - 1], d[i]]))
    inset = np.asarray(inset)
    if np.any(inset @ ns.T - d > 1e-08):
        raise ValueError('Bevel is too wide for this prism outline.')
    q = [[x, y, z] for x, y in p for z in [-depth / 2 + bevel, depth / 2 - bevel]]
    q += [[x, y, z] for x, y in inset for z in [-depth / 2, depth / 2]]
    return finish(q)
