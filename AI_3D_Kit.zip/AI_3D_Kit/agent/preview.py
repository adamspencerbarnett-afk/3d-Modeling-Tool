"""Render actual exported triangles with a CPU fallback and an offline viewer.

Lighting is an inspection approximation, not a material-conformance renderer."""

from __future__ import annotations
import base64
import html
import io
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
from core.mesh import GLB, unit
from agent.geom import tangents
from agent.state import ROOT
from agent.mats import linear, srgb


class Scene(list):
    shadow = None


def tex(g, slot, srgb=False, alpha=False):
    if not slot:
        return None
    texture = g.j['textures'][slot['index']]
    raw = g.image_bytes(texture['source'])
    with Image.open(io.BytesIO(raw)) as im:
        a = np.asarray(im.convert('RGBA' if alpha else 'RGB'), np.float32) / 255
    if alpha:
        a = np.repeat(a[..., 3:4], 3, axis=2)
    if srgb:
        a = linear(a)
    sam = g.j['samplers'][texture['sampler']] if 'sampler' in texture else {}
    return {
        'pixels': a,
        's': sam.get('wrapS', 10497),
        't': sam.get('wrapT', 10497),
        'nearest': sam.get('magFilter') == 9728
    }


def sample(tex, uv, default):
    if tex is None:
        return np.broadcast_to(np.asarray(default, dtype=float), (len(uv), 3)).copy()
    a = tex['pixels'] if isinstance(tex, dict) else tex
    ws, wt = (tex['s'], tex['t']) if isinstance(tex, dict) else (10497, 10497)

    def index(i, n, wrap):
        if wrap == 33071:
            return np.clip(i, 0, n - 1)
        if wrap == 33648:
            i = i % (2 * n)
            return np.where(i < n, i, 2 * n - 1 - i)
        return i % n
    x, y = (uv[:, 0] * a.shape[1] - 0.5, uv[:, 1] * a.shape[0] - 0.5)
    if isinstance(tex, dict) and tex['nearest']:
        return a[
            index(np.floor(y + 0.5).astype(int), a.shape[0], wt),
            index(np.floor(x + 0.5).astype(int), a.shape[1], ws)
        ]
    x0, y0 = (np.floor(x).astype(int), np.floor(y).astype(int))
    fx, fy = ((x - x0)[:, None], (y - y0)[:, None])
    x1, y1 = (index(x0 + 1, a.shape[1], ws), index(y0 + 1, a.shape[0], wt))
    x0, y0 = (index(x0, a.shape[1], ws), index(y0, a.shape[0], wt))
    return (a[y0, x0] * (1 - fx) + a[y0, x1] * fx) * (1 - fy) + (a[y1, x0] * (1 - fx) + a[y1, x1] * fx) * fy


def prepare(model):
    """Read exported geometry and decode supported texture channels for rendering."""
    from agent.paint import mesh as read_mesh
    g = GLB.load(model)
    items, cache = (Scene(), {})
    for ni, world in g.worlds().items():
        node = g.j['nodes'][ni]
        if 'mesh' not in node:
            continue
        for p in g.j['meshes'][node['mesh']]['primitives']:
            attrs = p['attributes']
            mesh = read_mesh(g, p).transformed(world)
            vc = g.array(attrs['COLOR_0']) if 'COLOR_0' in attrs else None
            mesh.color = vc[:, :3] if vc is not None else None
            mesh.alpha = vc[:, 3] if vc is not None and vc.shape[1] == 4 else None
            mat = g.j.get('materials', [])[p['material']] if 'material' in p else {}
            pbr = mat.get('pbrMetallicRoughness', {})
            mi = p.get('material', -1)
            if mi not in cache:
                cache[mi] = [
                    tex(g, pbr.get('baseColorTexture'), True),
                    tex(g, mat.get('normalTexture')),
                    tex(g, pbr.get('metallicRoughnessTexture')),
                    tex(
                        g,
                        pbr.get('baseColorTexture'),
                        alpha=True
                    ) if mat.get('alphaMode') == 'MASK' else None,
                    tex(g, mat.get('occlusionTexture')),
                    tex(g, mat.get('emissiveTexture'), True)
                ]
            if 'TANGENT' in attrs:
                ts = g.array(attrs['TANGENT']).astype(float)
                ts[:, :3] = unit(ts[:, :3] @ world[:3, :3].T)
                ts[:, 3] *= np.sign(np.linalg.det(world[:3, :3]))
            else:
                ts = tangents(mesh)
            items.append((mesh, mat, cache[mi], ts))
    return items


def camera(direction):
    direction = unit(direction)
    ref = [0, 1, 0] if abs(direction[1]) < 0.99999 else [0, 0, -1]
    right = unit(np.cross(ref, direction))
    return np.column_stack([right, np.cross(direction, right), direction])


def pixels(tri, size):
    x0, y0 = np.maximum(np.floor(tri[:, :2].min(0)).astype(int), 0)
    x1, y1 = np.minimum(np.ceil(tri[:, :2].max(0)).astype(int), size - 1)
    if x1 < x0 or y1 < y0:
        return None
    den = (tri[1, 1] - tri[2, 1]) * (tri[0, 0] - tri[2, 0]) + (tri[2, 0] - tri[1, 0]) * (tri[0, 1] - tri[2, 1])
    if abs(den) < 1e-12:
        return None
    y, x = np.mgrid[y0:y1 + 1, x0:x1 + 1]
    px, py = (x + 0.5, y + 0.5)
    w0 = ((tri[1, 1] - tri[2, 1]) * (px - tri[2, 0]) + (tri[2, 0] - tri[1, 0]) * (py - tri[2, 1])) / den
    w1 = ((tri[2, 1] - tri[0, 1]) * (px - tri[2, 0]) + (tri[0, 0] - tri[2, 0]) * (py - tri[2, 1])) / den
    w2 = 1 - w0 - w1
    use = (w0 >= -1e-07) & (w1 >= -1e-07) & (w2 >= -1e-07)
    if not use.any():
        return None
    w = np.column_stack([w0[use], w1[use], w2[use]])
    return (y[use], x[use], w, w @ tri[:, 2])


def shadow(items):
    size = 768
    light = unit([-0.58, 0.85, 1.0])
    frame = camera(light)
    pts = np.concatenate([m.v @ frame for m, _, _, _ in items])
    lo, hi = (pts.min(0), pts.max(0))
    center = (lo + hi) / 2
    scale = 0.92 * size / max(float((hi - lo)[:2].max()), 1e-06)
    depth = np.full((size, size), -np.inf, np.float32)
    for m, mat, tx, _ in items:
        p = m.v @ frame
        screen = np.column_stack([
            (p[:, 0] - center[0]) * scale + size / 2,
            size / 2 - (p[:, 1] - center[1]) * scale,
            p[:, 2]
        ])
        for f in m.f:
            result = pixels(screen[f], size)
            if result is None:
                continue
            y, x, w, z = result
            use = z > depth[y, x]
            if mat.get('alphaMode') == 'MASK':
                alpha = sample(tx[3], w @ m.uv[f], [1, 1, 1])[:, 0]
                alpha *= mat.get('pbrMetallicRoughness', {}).get('baseColorFactor', [1, 1, 1, 1])[3]
                if m.alpha is not None:
                    alpha *= w @ m.alpha[f]
                use &= alpha >= mat.get('alphaCutoff', 0.5)
            depth[y[use], x[use]] = z[use]
    return (depth, frame, center, scale, float(np.max(hi - lo)) * 0.0018)


def visibility(pos, data):
    depth, frame, center, scale, bias = data
    n = len(depth)
    p = pos @ frame
    x = np.floor((p[:, 0] - center[0]) * scale + n / 2).astype(int)
    y = np.floor(n / 2 - (p[:, 1] - center[1]) * scale).astype(int)
    result = np.zeros(len(pos), np.float32)
    for dy, dx in [(0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)]:
        xx, yy = (np.clip(x + dx, 0, n - 1), np.clip(y + dy, 0, n - 1))
        result += (p[:, 2] + bias >= depth[yy, xx]) | (x < 0) | (x >= n) | (y < 0) | (y >= n)
    return (result / 5)[:, None]


def shade(n, look, base, rough, metal, ao, vis):
    """Evaluate approximate metallic-roughness lighting in linear color space."""
    nv = np.maximum(n @ look, 0.001)[:, None]
    f0 = 0.04 * (1 - metal) + base * metal
    fres = f0 + (1 - f0) * (1 - nv) ** 5
    refl = 2 * nv * n - look
    env = np.array([0.32, 0.38, 0.47]) * (0.7 + 0.5 * np.clip(refl[:, 1:2], -1, 1))
    power = 3 + 38 * (1 - rough) ** 3
    for d, energy in [([-0.6, 1, 1], [2.4, 2.2, 1.9]), ([1, 0.6, -0.4], [1.7, 1.9, 2.4])]:
        env += np.maximum(refl @ unit(d), 0)[:, None] ** power * energy
    col = (base * (1 - metal) * (0.22 + 0.16 * np.clip(n[:, 1:2], 0, 1)) + env * fres * (0.65 + 0.25 * (1 - rough))) * ao
    lights = [
        ([-0.58, 0.85, 1.0], [3.2, 2.95, 2.6]),
        ([1, 0.5, 0.4], [0.75, 0.9, 1.1]),
        ([0.1, 0.9, -1], [1.2, 1.4, 1.65])
    ]
    for i, (direction, energy) in enumerate(lights):
        l = unit(direction)
        half = unit(l + look)
        nl = np.maximum(n @ l, 0)[:, None]
        nh = np.maximum(n @ half, 0)[:, None]
        hv = max(float(half @ look), 0)
        a2 = np.maximum(rough, 0.06) ** 4
        d = a2 / (np.pi * (nh * nh * (a2 - 1) + 1) ** 2 + 1e-08)
        k = (rough + 1) ** 2 / 8
        geom = nv / (nv * (1 - k) + k) * (nl / (nl * (1 - k) + k + 1e-08))
        f = f0 + (1 - f0) * (1 - hv) ** 5
        spec = d * geom * f / (4 * nv * nl + 1e-06)
        diff = (1 - f) * (1 - metal) * base / np.pi
        col += (diff + spec) * nl * energy * (vis if i == 0 else 1)
    return col


def cpu(
    model,
    out,
    size=640,
    angle=35,
    clay=False,
    prepared=None,
    elev=17,
    mode='beauty',
    aa=1,
    exposure=1.0,
    bloom=0.0
):
    """Render the exported mesh, not a concept illustration or height-map mockup."""
    modes = {'beauty', 'clay', 'base', 'normal', 'rough', 'metal', 'ao', 'emission', 'uv'}
    if not 64 <= size <= 1600 or aa not in [1, 2] or mode not in modes:
        raise ValueError('Use size 64..1600, aa 1 or 2, and a supported render mode.')
    if not np.isfinite([
        angle,
        elev,
        exposure,
        bloom
    ]).all() or not -90 <= elev <= 90 or (not 0 < exposure <= 8) or (not 0 <= bloom <= 1):
        raise ValueError('Invalid camera or exposure/bloom settings.')
    target_size, size = (size, size * aa)
    if clay:
        mode = 'clay'
    a, e = np.deg2rad([angle, elev])
    look = np.array([np.sin(a) * np.cos(e), np.sin(e), np.cos(a) * np.cos(e)])
    frame = camera(look)
    items = prepare(model) if prepared is None else prepared
    if not items:
        raise ValueError('No visible mesh.')
    pts = np.concatenate([m.v @ frame for m, _, _, _ in items])
    lo, hi = (pts.min(0), pts.max(0))
    center = (lo + hi) / 2
    scale = 0.86 * size / max(np.max(hi[:2] - lo[:2]), 1e-06)
    bg = 0.017 + 0.012 * (1 - np.arange(size)[:, None] / size)
    rgb = np.broadcast_to(
        np.stack([bg * 0.87, bg * 0.95, bg * 1.1], axis=2),
        (size, size, 3)
    ).astype(np.float32).copy()
    depth = np.full((size, size), -np.inf, np.float32)
    glow = np.zeros_like(rgb) if bloom else None
    lit = mode in {'beauty', 'clay'}
    if lit and getattr(items, 'shadow', None) is None:
        data = shadow(items)
        if isinstance(items, Scene):
            items.shadow = data
    else:
        data = getattr(items, 'shadow', None)
    if lit and look[1] > 0.07:
        floor = min((m.v[:, 1].min() for m, _, _, _ in items)) - 0.001
        xrow = (np.arange(size) + 0.5 - size / 2) / scale + center[0]
        for first in range(0, size, 64):
            last = min(size, first + 64)
            sx = np.tile(xrow, last - first)
            sy = np.repeat((size / 2 - np.arange(first, last) - 0.5) / scale + center[1], size)
            z = (floor - frame[1, 0] * sx - frame[1, 1] * sy) / look[1]
            pos = np.column_stack([sx, sy, z]) @ frame.T
            vis = visibility(pos, data).reshape(last - first, size, 1)
            rgb[first:last] *= 0.72 + 0.28 * vis
    for mesh, mat, tx, ts in items:
        pv = mesh.v @ frame
        screen = np.column_stack([
            (pv[:, 0] - center[0]) * scale + size / 2,
            size / 2 - (pv[:, 1] - center[1]) * scale,
            pv[:, 2]
        ])
        pbr = mat.get('pbrMetallicRoughness', {})
        color = np.asarray(pbr.get('baseColorFactor', [1, 1, 1, 1])[:3])
        for face in mesh.f:
            fn = np.cross(mesh.v[face[1]] - mesh.v[face[0]], mesh.v[face[2]] - mesh.v[face[0]])
            if fn @ look <= 0 and (not mat.get('doubleSided', False)):
                continue
            result = pixels(screen[face], size)
            if result is None:
                continue
            yi, xi, w, z = result
            keep = z > depth[yi, xi]
            yi, xi, w, z = (yi[keep], xi[keep], w[keep], z[keep])
            if not len(w):
                continue
            uv = w @ mesh.uv[face]
            if mat.get('alphaMode') == 'MASK' and mode != 'clay':
                alpha = sample(tx[3], uv, [1, 1, 1])[:, 0] * pbr.get('baseColorFactor', [1, 1, 1, 1])[3]
                if mesh.alpha is not None:
                    alpha *= w @ mesh.alpha[face]
                keep = alpha >= mat.get('alphaCutoff', 0.5)
                yi, xi, w, uv, z = (yi[keep], xi[keep], w[keep], uv[keep], z[keep])
                if not len(w):
                    continue
            n = unit(w @ mesh.n[face])
            if mat.get('doubleSided') and fn @ look < 0:
                n = -n
            if mode == 'clay':
                base = np.full((len(w), 3), 0.32)
                rough, metal, ao = (np.full((len(w), 1), 0.8), np.zeros((len(w), 1)), np.ones((len(w), 1)))
                em = np.zeros_like(base)
            else:
                base = sample(tx[0], uv, [1, 1, 1]) * color
                if mesh.color is not None:
                    base *= w @ mesh.color[face]
                orm = sample(tx[2], uv, [1, 1, 1])
                rough = np.clip(orm[:, 1:2] * pbr.get('roughnessFactor', 1), 0.06, 1)
                metal = orm[:, 2:3] * pbr.get('metallicFactor', 1)
                oc = sample(tx[4], uv, [1, 1, 1])[:, :1]
                ao = 1 + mat.get('occlusionTexture', {}).get('strength', 1) * (oc - 1)
                em = sample(tx[5], uv, [1, 1, 1]) * mat.get('emissiveFactor', [0, 0, 0])
                if tx[1] is not None and mode not in {'base', 'rough', 'metal', 'ao', 'emission', 'uv'}:
                    tn = sample(tx[1], uv, [0.5, 0.5, 1]) * 2 - 1
                    tn[:, :2] *= mat.get('normalTexture', {}).get('scale', 1)
                    t = w @ ts[face, :3]
                    t = unit(t - n * np.sum(n * t, axis=1, keepdims=True))
                    sign = np.where(w @ ts[face, 3] < 0, -1, 1)
                    b = np.cross(n, t) * sign[:, None]
                    n = unit(t * tn[:, :1] + b * tn[:, 1:2] + n * tn[:, 2:3])
            if lit:
                out_col = shade(n, look, base, rough, metal, ao, visibility(w @ mesh.v[face], data)) + em
            elif mode == 'base':
                out_col = base
            elif mode == 'emission':
                out_col = em
            elif mode == 'normal':
                out_col = linear(n * 0.5 + 0.5)
            elif mode == 'uv':
                c = np.mod(np.floor(uv * 12).sum(1), 2)
                out_col = linear(np.column_stack([0.15 + c * 0.6, 0.3 + c * 0.45, 0.45 + c * 0.3]))
            else:
                channel = {'rough': rough, 'metal': metal, 'ao': ao}[mode]
                out_col = linear(np.repeat(channel, 3, axis=1))
            rgb[yi, xi] = out_col
            if glow is not None:
                glow[yi, xi] = em
            depth[yi, xi] = z
    if lit:
        rgb *= exposure
        if bloom:
            rgb += gaussian_filter(glow, (max(1, size / 150), max(1, size / 150), 0)) * bloom
        rgb = np.clip(rgb, 0, 1)
    im = Image.fromarray(np.uint8(np.rint(srgb(rgb.clip(0, 1)) * 255).clip(0, 255)))
    if aa == 2:
        im = im.resize((target_size, target_size), Image.Resampling.LANCZOS)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    im.save(out)
    return {
        'file': str(out),
        'backend': 'cpu',
        'mode': mode,
        'angle': angle,
        'elevation': elev,
        'aa': aa,
        'scope': 'Actual exported mesh; approximate PBR and analytic environment, primary-light shadow map. Not path tracing.'
    }


def render(model, folder, size=384, review=False, aa=1):
    """Produce consistent real-mesh views, plus inspection channels when requested."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    frames = [('hero', 35, 17, 'beauty'), ('back', 215, 17, 'beauty'), ('clay', 35, 17, 'clay')]
    if review:
        frames += [
            ('front', 0, 0, 'beauty'),
            ('side', 90, 0, 'beauty'),
            ('top', 0, 90, 'beauty'),
            ('base', 35, 17, 'base'),
            ('uv', 35, 17, 'uv')
        ]
    prepared = prepare(model)
    return [cpu(model, folder / f'{name}.png', size, angle, prepared=prepared, elev=elev, mode=mode, aa=aa) for name, angle, elev, mode in frames]


def page(model, folder, name):
    """Embed the local model and stills in a portable, network-free HTML preview."""
    folder, model = (Path(folder), Path(model))
    title = html.escape(name)
    viewer = (ROOT / 'core/viewer.html').read_text(encoding='utf-8')
    data = base64.b64encode(model.read_bytes()).decode() if model.stat().st_size <= 12 * 1048576 else ''
    images = ''
    for frame in ['hero', 'back', 'clay']:
        path = folder / 'views' / f'{frame}.png'
        if path.is_file():
            image = base64.b64encode(path.read_bytes()).decode()
            images += f'<figure><img src="data:image/png;base64,{image}" alt="Actual {frame} mesh render"><figcaption>{frame.title()} — actual model render</figcaption></figure>'
    note = 'Embedded model ready.' if data else 'Large model: choose the accompanying model.glb to open the interactive view.'
    text = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><style>
body{{background:#101820;color:#e4e8ec;font:16px system-ui;margin:28px auto;max-width:1100px;padding:0 18px}}
h1{{font-size:28px}}p{{line-height:1.55;color:#b7c2cc}}iframe{{width:100%;height:520px;border:1px solid #445;border-radius:8px}}
section{{display:flex;flex-wrap:wrap;gap:12px}}figure{{margin:0;flex:1;min-width:200px}}img{{width:100%;border-radius:6px}}
figcaption{{padding:8px 0;color:#abb7c4}}a{{color:#8ecbff}}input{{margin:10px 0 18px}}
</style></head><body><h1>{title}</h1>
<p>AI 3D Kit · Offline inspection · Drag to orbit and scroll to zoom.<br>Approximate lighting; these previews do not certify printability or reconstruction accuracy.</p>
<p id="status">{note}</p><input id="pick" type="file" accept=".glb" aria-label="Choose a GLB model">
<a id="save" download="model.glb" hidden>Save displayed GLB</a>
<iframe id="view" title="3D viewport" srcdoc="{html.escape(viewer, quote=True)}"></iframe>
<section>{images}</section><script id="asset" type="application/octet-stream">{data}</script>
<script>
const frame=document.getElementById('view'),save=document.getElementById('save'),status=document.getElementById('status');
let blobUrl=null,started=false;
async function show(buf){{
try{{if(blobUrl)URL.revokeObjectURL(blobUrl);blobUrl=URL.createObjectURL(new Blob([buf],{{type:'model/gltf-binary'}}));
save.href=blobUrl;save.hidden=false;
if(!frame.contentWindow.loadAsset){{status.textContent=frame.contentWindow.viewerError||'Interactive rendering is unavailable. Use the actual still renders below.';return;}}
await frame.contentWindow.loadAsset(buf,'model');
status.textContent=frame.contentWindow.viewerError||'Model loaded. WebGL 2 provides the interactive view; still renders remain available below.';
}}catch(e){{status.textContent=e.message;}}
}}
function boot(){{if(started||(!frame.contentWindow.loadAsset&&!frame.contentWindow.viewerError))return;started=true;
const data=document.getElementById('asset').textContent.trim();
if(data)show(Uint8Array.from(atob(data),c=>c.charCodeAt(0)).buffer);
}}
frame.addEventListener('load',boot);boot();
document.getElementById('pick').addEventListener('change',async e=>{{const f=e.target.files[0];if(f)show(await f.arrayBuffer());}});
</script></body></html>'''
    path = folder / 'preview.html'
    path.write_text(text, encoding='utf-8')
    return str(path)
