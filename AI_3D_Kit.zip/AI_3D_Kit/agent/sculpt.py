"""Apply localized geometric strokes with adaptive refinement and safety limits."""

from __future__ import annotations
from dataclasses import dataclass
import time
import numpy as np
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from core.mesh import Mesh, unit
from agent.stamps import groups, split, corrected_normals
BRUSHES = ('draw', 'carve', 'inflate', 'grab', 'pinch', 'crease', 'flatten', 'smooth')


@dataclass
class Session:
    rest: Mesh
    mesh: Mesh
    layers: list
    stats: dict

    def save(self, path):
        data = {
            'v': self.rest.v,
            'f': self.rest.f,
            'n': self.rest.n,
            'uv': self.rest.uv,
            'final': self.mesh.v
        }
        for i, layer in enumerate(self.layers):
            data[f'ids_{i}'] = layer['ids']
            data[f'delta_{i}'] = layer['delta']
        np.savez_compressed(path, **data)


def _points(s, bounds):
    p = np.asarray(s.get('path', [s.get('center')]), float)
    if p.ndim != 2 or p.shape[1] != 3 or (not 1 <= len(p) <= 128) or (not np.isfinite(p).all()):
        raise ValueError('A sculpt stroke needs a finite center or a path of 1..128 XYZ points.')
    if s.get('space', 'local') == 'bounds':
        if np.any((p < 0) | (p > 1)):
            raise ValueError('Bounds-space sculpt coordinates must be in [0,1].')
        p = bounds[0] + p * bounds[1]
    return p


def validate(s):
    from agent.schema import SCULPT, finite
    finite(s)
    from jsonschema import Draft202012Validator
    e = next(iter(Draft202012Validator(SCULPT).iter_errors(s)), None)
    if e:
        raise ValueError('sculpt: ' + e.message)
    if ('center' in s) == ('path' in s):
        raise ValueError('Use exactly one of center and path for a sculpt stroke.')
    for k in ('normal', 'move'):
        if k in s and (not np.isfinite(s[k]).all()):
            raise ValueError('Sculpt vectors must be finite.')
    if 'normal' in s and np.linalg.norm(s['normal']) < 1e-10:
        raise ValueError('Sculpt normal must be nonzero.')
    brush = s['brush']
    if brush in ('draw', 'carve', 'inflate', 'crease') and 'depth' not in s:
        raise ValueError('This sculpt brush requires depth in local meters.')
    if brush in ('carve', 'crease') and s.get('depth', 0) < 0:
        raise ValueError('Carve and crease take positive inward depths.')
    if abs(s.get('depth', 0)) > s['radius'] * 0.75:
        raise ValueError('Sculpt depth must not exceed 0.75 times its radius; use several broad form edits.')
    if brush == 'grab' and 'move' not in s:
        raise ValueError('Grab requires a move vector in local meters.')
    if brush == 'grab' and np.linalg.norm(s['move']) > s['radius'] * 0.75:
        raise ValueError('Grab distance must not exceed 0.75 times its radius.')
    if brush == 'flatten' and ('normal' not in s or 'path' in s):
        raise ValueError('Flatten requires a center and plane normal, not a path.')


def _variants(s, bounds):
    p = _points(s, bounds)
    n = unit(np.array(s['normal'], float)) if 'normal' in s else np.zeros(3)
    move = np.array(s.get('move', [0.0, 0.0, 0.0]), float)
    result = [(p, n, move)]
    if s.get('symmetry', 'none') != 'none':
        ax = 'xyz'.index(s['symmetry'])
        plane = s.get('plane', 0.0)
        q = p.copy()
        q[:, ax] = 2 * plane - q[:, ax]
        nn, mm = (n.copy(), move.copy())
        nn[ax] *= -1
        mm[ax] *= -1
        if not np.allclose(q, p, rtol=0, atol=1e-12):
            result.append((q, nn, mm))
    return result


def closest(v, path):
    if len(path) == 1:
        q = np.broadcast_to(path[0], v.shape).copy()
        return (np.linalg.norm(v - q, axis=1), q)
    d = np.full(len(v), np.inf)
    q = np.empty_like(v)
    for a, b in zip(path, path[1:]):
        ab = b - a
        den = float(ab @ ab)
        t = np.zeros(len(v)) if den < 1e-24 else np.clip((v - a) @ ab / den, 0, 1)
        pp = a + t[:, None] * ab
        dd = np.sum((v - pp) ** 2, axis=1)
        take = dd < d
        d[take], q[take] = (dd[take], pp[take])
    return (np.sqrt(d), q)


def _samples(path, r):
    p = [path[0]]
    for a, b in zip(path, path[1:]):
        count = max(1, int(np.ceil(np.linalg.norm(b - a) / r)))
        if count > 20000:
            raise ValueError('Stroke path is too long for its radius.')
        p.extend((a + (b - a) * t for t in np.linspace(0, 1, count + 1)[1:]))
    return np.array(p)


def candidates(tree, path, r):
    rows = tree.query_ball_point(_samples(path, r), r * 1.51)
    return np.unique(np.concatenate([np.asarray(row, dtype=np.int64) for row in rows]))


def _edges(f):
    wedges = np.stack([f[:, [0, 1]], f[:, [1, 2]], f[:, [2, 0]]], axis=1)
    e, inv = np.unique(np.sort(wedges.reshape(-1, 2), axis=1), axis=0, return_inverse=True)
    return (e, inv.reshape(-1, 3))


def _refine(mesh, strokes, bounds, limit, lod):
    specs = [
        (s, p, n, s['step'] / lod) for s in strokes if s.get('step', 0) > 0 for p,
        n,
        _ in _variants(s, bounds)
    ]
    if not specs:
        return (mesh, 0)
    for it in range(12):
        e, inv = _edges(mesh.f)
        mid = mesh.v[e].mean(1)
        length = np.linalg.norm(mesh.v[e[:, 0]] - mesh.v[e[:, 1]], axis=1)
        ns = unit(mesh.n[e].mean(1))
        chosen = np.zeros(len(e), bool)
        for s, p, n, step in specs:
            ids = np.flatnonzero(length > step * 1.01)
            if len(ids) == 0:
                continue
            d, _ = closest(mid[ids], p)
            ok = d < s['radius'] + length[ids] * 0.5
            if 'normal' in s:
                ok &= ns[ids] @ n >= np.cos(np.deg2rad(s.get('angle', 80)))
            chosen[ids[ok]] = True
        if not chosen.any():
            return (mesh, it)
        seam = groups(mesh.v)
        _, eg = np.unique(np.sort(seam[e], axis=1), axis=0, return_inverse=True)
        take = np.zeros(eg.max() + 1, bool)
        np.logical_or.at(take, eg, chosen)
        chosen = take[eg]
        estimate = len(mesh.f) + int(chosen[inv].sum())
        if estimate > limit:
            raise ValueError(f'Sculpt refinement needs {estimate} triangles; sculpt_limit={limit}. Increase step or explicitly raise the budget.')
        mesh = split(mesh, chosen, e, inv)
    raise ValueError('Sculpt refinement did not converge in 12 passes.')


def _linked(ids, v, path, f, seam):
    selected = np.zeros(int(seam.max()) + 1, bool)
    selected[seam[ids]] = True
    e, _ = _edges(seam[f])
    keep = selected[e].all(1)
    e = e[keep]
    vals = np.ones(len(e), dtype=np.int8)
    graph = coo_matrix((vals, (e[:, 0], e[:, 1])), shape=(len(selected), len(selected))).tocsr()
    _, labels = connected_components(graph, directed=False)
    seed = ids[np.argmin(np.linalg.norm(v[ids] - path[0], axis=1))]
    return ids[labels[seam[ids]] == labels[seam[seed]]]


def _smooth(v, f, seam):
    e, _ = _edges(seam[f])
    n = int(seam.max()) + 1
    vv = np.zeros((n, 3))
    np.add.at(vv, seam, v)
    vv /= np.bincount(seam)[:, None]
    total = np.zeros_like(vv)
    count = np.zeros(n)
    for a, b in ((0, 1), (1, 0)):
        np.add.at(total, e[:, a], vv[e[:, b]])
        np.add.at(count, e[:, a], 1)
    avg = total / np.maximum(count[:, None], 1)
    avg[count == 0] = vv[count == 0]
    return (avg - vv)[seam]


def _safe(ref, v):
    a, b = (ref.v[ref.f], v[ref.f])
    ca = np.cross(a[:, 1] - a[:, 0], a[:, 2] - a[:, 0])
    cb = np.cross(b[:, 1] - b[:, 0], b[:, 2] - b[:, 0])
    if not np.isfinite(v).all() or np.any(np.sum(ca * cb, axis=1) <= 0):
        raise ValueError('Sculpt stroke inverted or collapsed a triangle. Reduce depth or strength, broaden the brush, or refine explicitly.')


def apply(mesh, strokes, limit=50000, lod=1.0, history=False, mask=None):
    """Refine and displace a local surface while enforcing the configured budget."""
    started = time.perf_counter()
    if not 0 < lod <= 2 or not 1 <= len(strokes) <= 192:
        raise ValueError('Sculpt requires 1..192 strokes and a positive LOD up to 2.')
    for s in strokes:
        validate(s)
    if mask is not None:
        mask = np.asarray(mask, float)
        if mask.shape != (len(mesh.v),) or not np.isfinite(mask).all() or np.any((mask < 0) | (mask > 1)):
            raise ValueError('Sculpt mask must have one [0,1] weight per vertex.')
        if any(('step' in s for s in strokes)):
            raise ValueError('Refine before supplying a per-vertex mask.')
    if len(mesh.f) > limit:
        raise ValueError('Base mesh exceeds sculpt_limit.')
    bounds = (mesh.v.min(0), np.maximum(np.ptp(mesh.v, axis=0), 1e-12))
    base, passes = _refine(mesh, strokes, bounds, limit, lod)
    current = Mesh(base.v.copy(), base.f.copy(), base.n.copy(), base.uv.copy())
    seam = groups(base.v)
    if mask is not None:
        lo = np.full(int(seam.max()) + 1, np.inf)
        hi = np.full(len(lo), -np.inf)
        np.minimum.at(lo, seam, mask)
        np.maximum.at(hi, seam, mask)
        if np.any(hi - lo > 1e-10):
            raise ValueError('Coincident seam vertices require equal mask weights.')
    layers, rows = ([], [])
    for si, s in enumerate(strokes):
        previous = current
        tree = cKDTree(previous.v, copy_data=True)
        best = np.zeros(len(previous.v))
        delta = np.zeros_like(previous.v)
        queried = 0
        for path, normal, move in _variants(s, bounds):
            ids = candidates(tree, path, s['radius'])
            queried += len(ids)
            if not len(ids):
                continue
            d, q = closest(previous.v[ids], path)
            ok = d < s['radius']
            if 'normal' in s:
                ok &= previous.n[ids] @ normal >= np.cos(np.deg2rad(s.get('angle', 80)))
            ids, d, q = (ids[ok], d[ok], q[ok])
            if not len(ids):
                continue
            if s.get('connected', False):
                linked = _linked(ids, previous.v, path, previous.f, seam)
                keep = np.isin(ids, linked)
                ids, d, q = (ids[keep], d[keep], q[keep])
            t = np.clip(1 - d / s['radius'], 0, 1)
            w = t * t * (3 - 2 * t)
            if mask is not None:
                w *= mask[ids]
            w *= s.get('weight', 1.0)
            pos, ns = (previous.v[ids], previous.n[ids])
            brush = s['brush']
            depth = s.get('depth', 0.0)
            strength = s.get('strength', 0.25)
            change = np.zeros_like(pos)
            if brush in ('draw', 'inflate', 'carve', 'crease'):
                sign = -1 if brush in ('carve', 'crease') else 1
                change += ns * (sign * depth * w)[:, None]
            if brush in ('pinch', 'crease'):
                toward = q - pos
                toward -= ns * np.sum(toward * ns, axis=1, keepdims=True)
                change += toward * (w * strength)[:, None]
            elif brush == 'grab':
                change = move * w[:, None]
            elif brush == 'flatten':
                off = (path[0] - pos) @ normal
                change = normal * (off * w * strength)[:, None]
            elif brush == 'smooth':
                change = _smooth(previous.v, previous.f, seam)[ids] * (w * strength)[:, None]
            better = w > best[ids]
            delta[ids[better]] = change[better]
            best[ids[better]] = w[better]
        sums = np.zeros((int(seam.max()) + 1, 3))
        np.add.at(sums, seam, delta)
        delta = (sums / np.bincount(seam)[:, None])[seam]
        ids = np.flatnonzero(np.linalg.norm(delta, axis=1) > 1e-12)
        if not len(ids) and s.get('weight', 1.0) != 0:
            raise ValueError(f'Sculpt stroke {si} moved no vertices. Check coordinates, radius, facing and mesh resolution.')
        v = previous.v + delta
        _safe(previous, v)
        current = Mesh(v, previous.f, corrected_normals(previous, v), previous.uv)
        if history:
            layers.append({'ids': ids, 'delta': delta[ids].copy()})
        rows.append({'index': si, 'name': s.get('name', f"{s['brush']}_{si}"), 'brush': s['brush'], 'candidate_vertices': queried, 'changed_vertices': len(ids), 'max_move_m': float(np.linalg.norm(delta, axis=1).max()), 'requested_depth_m': s.get('depth'), 'weight': s.get('weight', 1.0)})
    stats = {
        'base_triangles': len(mesh.f),
        'final_triangles': len(current.f),
        'refine_passes': passes,
        'changed_vertices': int(np.count_nonzero(np.linalg.norm(current.v - base.v, axis=1) > 1e-12)),
        'max_move_m': float(np.linalg.norm(current.v - base.v, axis=1).max()),
        'strokes': rows,
        'seconds': round(time.perf_counter() - started, 6),
        'topology_change': 'local subdivision only; no remeshing or booleans'
    }
    return (current, Session(base, current, layers, stats))
