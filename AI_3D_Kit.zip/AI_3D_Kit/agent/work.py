"""Replay import, assembly, relief, edit, and texturing tasks as saved projects."""

from __future__ import annotations
import copy
import io
import shutil
import tempfile
import time
import zipfile
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps
from agent import VERSION
from agent.build import artifact_hashes, audit
from agent.files import LIMIT, join, load, wrap
from agent.preview import page, render
from agent.schema import NAME, PATH, MAT, DECAL, arr, finite, num, obj, vec
from agent.state import output_path, safe, source, write
from core.hash import digest
from core.mesh import GLB, Mesh, flat, matrix, merge, node_matrix, unit
from core.validate import check
TRS = {'pos': vec(3), 'rot': vec(3, -36000, 36000), 'scale': vec(3, 1e-06, 10000)}
EDIT = obj(
    {
        'node': {'oneOf': [{'type': 'integer', 'minimum': 0}, {'type': 'string', 'minLength': 1}]},
        **TRS,
        'color': vec(4, 0, 1),
        'rough': num(0, 1),
        'metal': num(0, 1)
    },
    ['node']
)
ITEM = obj({'name': NAME, 'model': PATH, **TRS}, ['name', 'model'])
ASSIGN = obj(
    {
        'node': {'oneOf': [{'type': 'integer', 'minimum': 0}, {'type': 'string', 'minLength': 1}]},
        'mat': NAME,
        'uv': {'enum': ['keep', 'atlas', 'metric']},
        'uv_size': num(0.0001, 10000),
        'decals': arr(DECAL, hi=24)
    },
    ['node', 'mat']
)
TASK = obj(
    {
        'schema': {'const': 'ai3d.task/1'},
        'name': NAME,
        'op': {'enum': ['import', 'assemble', 'relief', 'texture']},
        'materials': {
            'type': 'object',
            'minProperties': 1,
            'maxProperties': 32,
            'propertyNames': NAME,
            'additionalProperties': MAT
        },
        'assign': arr(ASSIGN, 1, 256),
        'texture_size': {'enum': [64, 128, 256, 512, 1024, 2048]},
        'model': PATH,
        'image': PATH,
        'color_image': PATH,
        'edits': arr(EDIT, hi=256),
        'items': arr(ITEM, 1, 64),
        **TRS,
        'mode': {'enum': ['height', 'brightness']},
        'width': num(0.001, 1000),
        'depth': num(1e-05, 100),
        'base': num(1e-05, 100),
        'res': {'type': 'integer', 'minimum': 4, 'maximum': 128},
        'invert': {'type': 'boolean'}
    },
    ['schema', 'name', 'op']
)


def validate_task(data):
    from jsonschema import Draft202012Validator
    finite(data)
    error = next(iter(Draft202012Validator(TASK).iter_errors(data)), None)
    if error:
        raise ValueError(f'Task {list(error.absolute_path)}: {error.message}')
    base = {'schema', 'name', 'op'}
    allowed = {
        'import': base | set(TRS) | {'model', 'edits'},
        'assemble': base | {'items'},
        'texture': base | {'model', 'materials', 'assign', 'texture_size'},
        'relief': base | {'image', 'color_image', 'mode', 'width', 'depth', 'base', 'res', 'invert'}
    }
    extra = set(data) - allowed[data['op']]
    if extra:
        raise ValueError(f"Fields do not apply to {data['op']}: {sorted(extra)}")
    need = {'import': 'model', 'assemble': 'items', 'relief': 'image', 'texture': 'model'}[data['op']]
    if need not in data:
        raise ValueError(f"{data['op']} requires {need}.")
    if data['op'] == 'texture':
        if not data.get('materials') or not data.get('assign'):
            raise ValueError('Texture tasks require materials and assign.')
        from agent.schema import validate
        fixture = {
            'schema': 'ai3d.recipe/1',
            'name': data['name'],
            'materials': data['materials'],
            'parts': [
                {'name': 'check_' + str(i), 'shape': 'box', 'mat': key, 'uv': 'atlas'} for i,
                key in enumerate(data['materials'])
            ]
        }
        validate(fixture)
    if data['op'] == 'relief' and 'mode' not in data:
        raise ValueError('Choose mode=height for a supplied height map, or mode=brightness for artistic relief.')
    if data['op'] == 'assemble':
        names = [i['name'] for i in data['items']]
        if len(set(names)) != len(names):
            raise ValueError('Assembly item names must be unique.')
    return data


def edit(g, changes):
    for cfg in changes:
        key = cfg['node']
        if isinstance(key, int):
            if not 0 <= key < len(g.j['nodes']):
                raise ValueError(f'Node index out of range: {key}')
            index = key
        else:
            found = [i for i, n in enumerate(g.j['nodes']) if n.get('name') == key]
            if len(found) != 1:
                raise ValueError(f'Node name must match exactly one node: {key}. Use its index from inspect.')
            index = found[0]
        node = g.j['nodes'][index]
        if any((k in cfg for k in TRS)):
            delta = matrix(**{k: cfg[k] for k in TRS if k in cfg})
            old = node_matrix(node)
            for key in ['translation', 'rotation', 'scale', 'matrix']:
                node.pop(key, None)
            node['matrix'] = (delta @ old).flatten(order='F').tolist()
        if any((k in cfg for k in ['color', 'rough', 'metal'])):
            if 'mesh' not in node:
                raise ValueError('Material edits need a mesh node, not a transform group.')
            mesh = copy.deepcopy(g.j['meshes'][node['mesh']])
            node['mesh'] = len(g.j['meshes'])
            g.j['meshes'].append(mesh)
            for prim in mesh['primitives']:
                mats = g.j.setdefault('materials', [])
                mat = copy.deepcopy(mats[prim['material']]) if 'material' in prim else {}
                pbr = mat.setdefault('pbrMetallicRoughness', {})
                for name, prop in [
                    ('color', 'baseColorFactor'),
                    ('rough', 'roughnessFactor'),
                    ('metal', 'metallicFactor')
                ]:
                    if name in cfg:
                        pbr[prop] = cfg[name]
                if 'color' in cfg and cfg['color'][3] < 1:
                    mat['alphaMode'] = 'BLEND'
                prim['material'] = len(mats)
                mats.append(mat)


def relief(path, cfg, color=None):
    with Image.open(path) as raw:
        if raw.width * raw.height > 16777216 or min(raw.size) < 2:
            raise ValueError('Relief images need at least 2 pixels per side and at most 16 million pixels.')
        raw = ImageOps.exif_transpose(raw)
        size = raw.size
        if cfg['mode'] == 'brightness':
            data = np.asarray(raw.convert('L'), dtype=np.float64) / 255
        else:
            if raw.mode not in {'L', 'I', 'F', 'I;16', 'I;16B', 'I;16L'}:
                raise ValueError('Height mode requires a single-channel 8-bit, 16-bit or normalized floating image, not an RGB photograph.')
            data = np.asarray(raw, dtype=np.float64)
            if raw.mode == 'L':
                data /= 255
            elif raw.mode != 'F':
                data /= 65535
            if not np.isfinite(data).all() or data.min() < 0 or data.max() > 1:
                raise ValueError('Height values must be normalized floats or unsigned 8/16-bit values.')
    res = cfg.get('res', 48)
    nx, ny = (
        res,
        max(4, round(res * size[1] / size[0]))
    ) if size[0] >= size[1] else (max(4, round(res * size[0] / size[1])), res)
    data = np.asarray(
        Image.fromarray(data.astype(np.float32)).resize((nx, ny), Image.Resampling.BILINEAR),
        dtype=np.float64
    )
    if cfg.get('invert', False):
        data = 1 - data
    width = cfg.get('width', 1)
    height = width * size[1] / size[0]
    depth, base = (cfg.get('depth', 0.06), cfg.get('base', 0.02))
    u, v = np.meshgrid(np.linspace(0, 1, nx), np.linspace(0, 1, ny))
    verts = np.stack([(u - 0.5) * width, (0.5 - v) * height, data * depth], axis=2).reshape(-1, 3)
    uv = np.column_stack([u.ravel(), v.ravel()])
    ids = np.arange(nx * ny).reshape(ny, nx)
    a, b, c, d = (ids[:-1, :-1].ravel(), ids[:-1, 1:].ravel(), ids[1:, :-1].ravel(), ids[1:, 1:].ravel())
    faces = np.vstack([np.column_stack([a, c, b]), np.column_stack([b, c, d])]).astype(np.uint32)
    dy, dx = np.gradient(data * depth, height / (ny - 1), width / (nx - 1))
    normals = unit(np.stack([-dx, dy, np.ones_like(dx)], axis=2).reshape(-1, 3))
    top = Mesh(verts, faces, normals, uv)
    back = verts.copy()
    back[:, 2] = -base
    bottom = Mesh(back, faces[:, ::-1], np.tile([0, 0, -1], (len(back), 1)), uv.copy())
    edges = np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]])
    _, inv, count = np.unique(np.sort(edges, axis=1), axis=0, return_inverse=True, return_counts=True)
    boundary = edges[count[inv] == 1]
    a, b = (boundary[:, 0], boundary[:, 1])
    n = len(verts)
    sides = np.vstack([np.column_stack([b, a, a + n]), np.column_stack([b, a + n, b + n])])
    side = flat(np.vstack([verts, back]), sides)
    g = GLB()
    if color:
        with Image.open(color) as img:
            if img.width * img.height > 16777216:
                raise ValueError('Color image exceeds 16 million pixels.')
            image = ImageOps.exif_transpose(img).convert('RGB')
            image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
            data = io.BytesIO()
            image.save(data, format='PNG')
            tex = g.texture(data.getvalue(), 'surface')
            mat = g.material('surface', color=(1, 1, 1, 1), rough=0.85)
            g.j['materials'][mat]['pbrMetallicRoughness']['baseColorTexture'] = {'index': tex}
    else:
        mat = g.material('surface', color=(0.65, 0.66, 0.68, 1), rough=0.85)
    g.add_mesh('relief', merge([top, bottom, side]), mat)
    return g


def warnings(g):
    result = []
    if any((m.get('alphaMode') == 'BLEND' for m in g.j.get('materials', []))):
        result.append('Alpha-blended transparency is retained in GLB but approximated as opaque in CPU preview.')
    result.append('Preview lighting is approximate. Validation does not certify watertightness, printability, realism or anatomy.')
    return result


def run(data, root, out, size=384, draw=True, limit=200000):
    """Execute a validated task and capture all inputs needed to replay the result."""
    start = time.perf_counter()
    validate_task(data)
    if not 64 <= size <= 1600 or not 12 <= limit <= 500000:
        raise ValueError('Preview size must be 64..1600 and triangle limit 12..500000.')
    out = output_path(out)
    root = Path(root).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.model-', dir=out.parent))
    job = copy.deepcopy(data)
    issues, inputs = ([], {})
    try:
        (stage / 'assets').mkdir()
        if job['op'] == 'import':
            path = safe(root, job['model'], LIMIT)
            g, notes = load(path)
            issues.extend(notes)
            inputs[job['model']] = digest(path)
            g.save(stage / 'assets/source.glb')
            job['model'] = 'assets/source.glb'
            edit(g, job.get('edits', []))
            if any((k in job for k in TRS)):
                wrap(g, **{k: job[k] for k in TRS if k in job})
        elif job['op'] == 'texture':
            from agent.paint import apply
            from agent.build import owners
            path = safe(root, job['model'], LIMIT)
            g, notes = load(path)
            issues.extend(notes)
            inputs[job['model']] = digest(path)
            g.save(stage / 'assets/source.glb')
            job['model'] = 'assets/source.glb'
            values = list(owners({'materials': job['materials'], 'parts': []}))
            values += [d for a in job['assign'] for d in a.get('decals', [])]
            for cfg in values:
                for key in [
                    'image',
                    'normal',
                    'height',
                    'orm',
                    'rough_map',
                    'metal_map',
                    'ao_map',
                    'emissive'
                ]:
                    if key in cfg:
                        path = safe(root, cfg[key])
                        inputs[cfg[key]] = digest(path)
                        dst = 'assets/' + digest(path) + path.suffix.lower()
                        if not (stage / dst).is_file():
                            shutil.copyfile(path, stage / dst)
                        cfg[key] = dst
            apply(g, job, stage)
        elif job['op'] == 'assemble':
            g = GLB()
            for i, item in enumerate(job['items']):
                path = safe(root, item['model'], LIMIT)
                part, notes = load(path)
                issues.extend(notes)
                inputs[item['model']] = digest(path)
                file = f'assets/part_{i}.glb'
                part.save(stage / file)
                item['model'] = file
                join(g, part, item['name'], **{k: item[k] for k in TRS if k in item})
        else:
            for key in ['image', 'color_image']:
                if key in job:
                    path = safe(root, job[key])
                    inputs[job[key]] = digest(path)
                    file = 'assets/' + key + path.suffix.lower()
                    shutil.copyfile(path, stage / file)
                    job[key] = file
            g = relief(
                stage / job['image'],
                job,
                stage / job['color_image'] if 'color_image' in job else None
            )
            issues.append('This is a closed-back 2.5D relief, not a full-object reconstruction. Unseen surfaces are not recovered.')
            if job['mode'] == 'brightness':
                issues.append('Height comes from image brightness as an artistic effect, not estimated or measured depth.')
        model = stage / 'model.glb'
        g.save(model)
        valid = check(model)
        if not valid['passed']:
            raise ValueError('Model validation failed: ' + '; '.join(valid['errors']))
        if valid['rendered_triangles'] > limit:
            raise ValueError(f"Triangle budget exceeded: {valid['rendered_triangles']} > {limit}. No silent decimation was applied.")
        from agent.quality import inspect as texture_check
        quality = texture_check(model)
        write(stage / 'quality.json', quality)
        if not quality['ok']:
            raise ValueError('Texture validation failed: ' + str(quality['issues']))
        write(stage / 'task.json', job)
        elapsed = time.perf_counter() - start
        if draw:
            render(model, stage / 'views', size=size)
        page(model, stage, job['name'])
        row = {k: valid[k] for k in [
            'bytes',
            'sha256',
            'rendered_triangles',
            'stored_triangles',
            'stored_vertices',
            'dimensions_m',
            'passed',
            'warnings'
        ]}
        row.update(file='model.glb', factor=1)
        report = {
            'ok': True,
            'version': VERSION,
            'name': job['name'],
            'kind': job['op'],
            'source_sha256': source(),
            'input_assets': inputs,
            'texture_quality': 'quality.json',
            'lods': [row],
            'build_seconds': round(elapsed, 4),
            'total_seconds': round(time.perf_counter() - start, 4),
            'timing_scope': 'Total includes loading, edits, validation, CPU previews and HTML; excludes chat planning and image generation.',
            'render_backend': 'cpu' if draw else 'none',
            'review_required': True,
            'limitations': list(dict.fromkeys(issues + warnings(g))),
            'artifacts': artifact_hashes(stage)
        }
        write(stage / 'report.json', report)
        if out.exists():
            raise FileExistsError('Output was created by another process.')
        stage.rename(out)
        return {**report, 'folder': str(out)}
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def pack(folder, out):
    """Audit a completed project before writing its portable artifact ZIP."""
    folder = Path(folder).resolve()
    out = output_path(out)
    if out.is_relative_to(folder):
        raise ValueError('Save the project ZIP outside the project being packed.')
    result = audit(folder)
    if not result['ok']:
        raise ValueError('Project audit failed. Rebuild rather than packaging changed or invalid files.')
    files = sorted((p for p in folder.rglob('*') if p.is_file()))
    if any((p.is_symlink() or not p.resolve().is_relative_to(folder) for p in files)):
        raise ValueError('Project must contain real files within its folder.')
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name('.' + out.name + '.tmp')
    if tmp.exists():
        raise FileExistsError('Temporary archive already exists.')
    try:
        with zipfile.ZipFile(tmp, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for p in files:
                z.write(p, folder.name + '/' + p.relative_to(folder).as_posix())
        if out.exists():
            raise FileExistsError('Output archive already exists.')
        tmp.rename(out)
    finally:
        tmp.unlink(missing_ok=True)
    return {'ok': True, 'file': str(out), 'bytes': out.stat().st_size, 'sha256': digest(out)}
