"""Create and sample local height stamps, keeping shared surface seams aligned.

Stamps displace existing surfaces; they are not Boolean cutters or reconstruction."""

from __future__ import annotations
from dataclasses import dataclass
import copy
import json
from pathlib import Path
import time
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from scipy.ndimage import distance_transform_edt, gaussian_filter, map_coordinates
from agent.bake import FACES, raster
from agent.geom import tangents
from agent.state import safe, write
from core.mesh import Mesh, unit
PRESETS = ('crack', 'chip', 'bark', 'rosette', 'dent')


@dataclass
class Stamp:
    h: np.ndarray
    a: np.ndarray
    color: np.ndarray | None
    cfg: dict


@dataclass
class Context:
    ref: Mesh
    mesh: Mesh
    bounds: tuple
    uses: list
    library: dict
    stats: dict


def resolve(cfg, root):
    if 'asset' not in cfg:
        return copy.deepcopy(cfg)
    path = safe(root, cfg['asset'])
    if path.stat().st_size > 65536:
        raise ValueError('A stamp definition must be at most 64 KiB.')
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('schema') != 'ai3d.stamp/1' or 'asset' in data:
        raise ValueError('A stamp asset needs schema ai3d.stamp/1 and cannot nest another asset.')
    from agent.schema import check_stamp
    check_stamp(data)
    for key in ('height', 'mask', 'image'):
        if key in data:
            p = safe(path.parent, data[key])
            if not p.is_relative_to(Path(root).resolve()):
                raise ValueError('Stamp inputs must remain inside the recipe folder.')
            data[key] = p.relative_to(Path(root).resolve()).as_posix()
    return data


def inputs(data, root):
    from core.hash import digest
    out = {}
    for cfg in data.get('stamps', {}).values():
        if 'asset' in cfg:
            out[cfg['asset']] = digest(safe(root, cfg['asset']))
        for key, value in resolve(cfg, root).items():
            if key in ('height', 'mask', 'image'):
                out[value] = digest(safe(root, value))
    return out


def scalar(path):
    path = Path(path)
    if path.suffix.lower() == '.npy':
        a = np.load(path, allow_pickle=False, mmap_mode='r')
        if a.ndim != 2 or min(a.shape) < 8 or a.size > 16777216 or (a.dtype.kind not in 'fui'):
            raise ValueError('Stamp arrays must be numeric 2D fields, at least 8 pixels per side and at most 16 million pixels.')
        a = np.asarray(a, np.float64)
    else:
        with Image.open(path) as im:
            if min(im.size) < 8 or im.width * im.height > 16777216:
                raise ValueError('Stamp maps must have at least 8 pixels per side and at most 16 million pixels.')
            im = ImageOps.exif_transpose(im)
            if im.mode not in ('1', 'L', 'I', 'F') and (not im.mode.startswith('I;16')):
                raise ValueError('Height and mask inputs must be grayscale data, not an RGB photograph. Supply an authored or inferred height map explicitly.')
            raw = np.asarray(im)
            a = raw.astype(np.float64)
            if im.mode.startswith('I;16') or (im.mode == 'I' and a.max() > 255):
                a /= 65535
            elif im.mode not in ('F', '1'):
                a /= 255
    if not np.isfinite(a).all():
        raise ValueError('Stamp maps cannot contain NaN or infinity.')
    return a


def resample(a, size):
    if a.shape[:2] == (size, size):
        return a.copy()
    if a.ndim == 3:
        return np.stack([resample(a[:, :, i], size) for i in range(a.shape[2])], axis=2)
    return np.asarray(
        Image.fromarray(a.astype(np.float32)).resize((size, size), Image.Resampling.BILINEAR),
        np.float64
    )


def preset(kind, n, seed):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:n, 0:n] / (n - 1)
    fine = gaussian_filter(rng.random((n, n)), 0.7)
    fine = (fine - fine.mean()) / max(float(fine.std()), 1e-09)
    broad = gaussian_filter(rng.random((n, n)), max(2, n / 25))
    broad = (broad - broad.mean()) / max(float(broad.std()), 1e-09)
    if kind == 'crack':
        im = Image.new('L', (n, n))
        draw = ImageDraw.Draw(im)
        yy = np.linspace(0.08, 0.92, 19)
        xx = 0.48 + np.cumsum(rng.normal(0, 0.038, len(yy)))
        xx = np.clip(xx, 0.25, 0.74)
        pts = list(zip(xx * n, yy * n))
        draw.line(pts, fill=255, width=max(1, n // 170))
        for j in (5, 9, 13):
            side = -1 if j == 9 else 1
            a, b = (xx[j], yy[j])
            dx = side * rng.uniform(0.13, 0.23)
            branch = [(a, b), (a + dx * 0.4, b - 0.08), (a + dx, b - 0.16)]
            draw.line([(int(u * n), int(v * n)) for u, v in branch], fill=255, width=max(1, n // 220))
        dist = distance_transform_edt(np.asarray(im) == 0) / n
        h = np.exp(-dist / 0.014) * (0.83 + 0.13 * np.tanh(broad))
        a = np.clip(1 - dist / 0.042, 0, 1)
    elif kind == 'chip':
        xx, yy = ((x - 0.5) * 2.35, (y - 0.5) * 2.2)
        r, ang = (np.hypot(xx, yy), np.arctan2(yy, xx))
        edge = 0.77 + 0.07 * np.sin(ang * 7 + seed) + 0.045 * np.cos(ang * 11)
        d = edge - r + 0.035 * np.tanh(broad)
        a = np.clip(d / 0.06, 0, 1)
        h = np.clip(d / 0.16, 0, 1) * (0.72 + 0.16 * np.tanh(broad) + 0.07 * np.tanh(fine))
    elif kind == 'bark':
        wave = x * 6.5 + 0.12 * np.sin(y * 11) + 0.045 * broad
        grooves = np.maximum(0, np.sin(2 * np.pi * wave)) ** 1.6
        plates = 0.68 + 0.2 * np.sin(y * 16 + x * 9) ** 2 + 0.05 * np.tanh(fine)
        h = grooves * plates
        a = np.ones((n, n))
    elif kind == 'rosette':
        xx, yy = ((x - 0.5) * 2, (y - 0.5) * 2)
        r, ang = (np.hypot(xx, yy), np.arctan2(yy, xx))
        petals = np.maximum(0, np.cos(ang * 8)) ** 2
        h = 0.58 * np.exp(-((r - 0.46) / 0.19) ** 2) * (0.24 + 0.76 * petals)
        h += 0.72 * np.exp(-(r / 0.16) ** 2) + 0.32 * np.exp(-((r - 0.76) / 0.04) ** 2)
        a = np.clip((0.85 - r) / 0.045, 0, 1)
    elif kind == 'dent':
        r = np.hypot((x - 0.5) * 2.4, (y - 0.5) * 2.4)
        h = np.clip(1 - r * r, 0, 1) ** 2
        a = np.clip((1 - r) / 0.08, 0, 1)
    else:
        raise ValueError('Unknown stamp preset.')
    h /= max(float(h.max()), 1e-09)
    h[a < 1e-06] = 0
    return (h, a, fine)


def prepare(cfg, root):
    cfg = resolve(cfg, root)
    n = cfg.get('size', 256)
    if cfg['kind'] == 'height':
        raw = scalar(safe(root, cfg['height']))
        if raw.shape[0] != raw.shape[1]:
            aspect = raw.shape[1] / raw.shape[0]
        else:
            aspect = 1.0
        h = (raw - cfg.get('zero', 0)) / cfg.get('range', 1)
        if h.min() < -1.00001 or h.max() > 1.00001:
            raise ValueError('Height values exceed [-1,1] after zero/range decoding. Set zero/range explicitly; no automatic contrast normalization is applied.')
        a = np.ones(raw.shape)
        fine = np.zeros((n, n))
        cfg = {**cfg, 'input_aspect': aspect}
    else:
        h, a, fine = preset(cfg['kind'], n, cfg.get('seed', 42))
        raw = h
    if 'mask' in cfg:
        m = scalar(safe(root, cfg['mask']))
        if m.shape != raw.shape:
            raise ValueError('Stamp height and mask must have identical pixel dimensions.')
        if m.min() < 0 or m.max() > 1:
            raise ValueError('Mask values must be between zero and one.')
        a *= m
    color = None
    if 'image' in cfg:
        with Image.open(safe(root, cfg['image'])) as im:
            if im.width * im.height > 16777216:
                raise ValueError('Stamp image exceeds 16 million pixels.')
            im = ImageOps.exif_transpose(im).convert('RGBA')
            if im.size != (raw.shape[1], raw.shape[0]):
                raise ValueError('Stamp color and height must have identical pixel dimensions.')
            rgba = np.asarray(im, np.float64) / 255
        color = rgba[:, :, :3]
        a *= rgba[:, :, 3]
    elif 'color' in cfg or cfg['kind'] != 'height':
        defaults = {
            'crack': [0.19, 0.17, 0.145],
            'chip': [0.43, 0.4, 0.34],
            'bark': [0.24, 0.13, 0.055],
            'rosette': [0.53, 0.34, 0.12],
            'dent': [0.34, 0.35, 0.36]
        }
        color = np.broadcast_to(
            np.asarray(cfg.get('color', defaults.get(cfg['kind'], [0.5] * 3)), dtype=np.float64),
            (n, n, 3)
        ).copy()
        color *= np.clip(1 + 0.08 * fine[:, :, None], 0.65, 1.3)
    h, a = (resample(h, n), resample(a, n))
    if color is not None:
        color = resample(color, n).clip(0, 1)
    if np.max(np.abs(h) * a) < 1e-08:
        raise ValueError('The stamp has no nonzero height within its mask.')
    if cfg['kind'] == 'bark' and color is not None:
        color *= 0.8 + 0.35 * h[:, :, None]
    return Stamp(h, a, color, cfg)


def library(data, root):
    return {name: prepare(cfg, root) for name, cfg in data.get('stamps', {}).items()}


def smooth(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def coords(pos, ns, bounds, use):
    lo, span = bounds
    ax, sign, ux, us, vx, vs = FACES[use['side']]
    q = (pos - lo) / span
    u = q[:, ux] if us > 0 else 1 - q[:, ux]
    v = q[:, vx] if vs > 0 else 1 - q[:, vx]
    x, y, w, h = use.get('rect', [0.1, 0.1, 0.8, 0.8])
    du, dv = ((u - x) / w - 0.5, (v - y) / h - 0.5)
    a = np.deg2rad(use.get('turn', 0))
    c, s = (np.cos(a), np.sin(a))
    uv = np.column_stack([0.5 + c * du + s * dv, 0.5 - s * du + c * dv])
    j0, j1 = (np.zeros(3), np.zeros(3))
    j0[ux], j1[vx] = (us / (span[ux] * w), vs / (span[vx] * h))
    jac = np.stack([c * j0 + s * j1, -s * j0 + c * j1])
    cutoff = np.cos(np.deg2rad(use.get('angle', 78)))
    facing = smooth((sign * ns[:, ax] - cutoff) / 0.15)
    depth = 1 - q[:, ax] if sign > 0 else q[:, ax]
    reach = use.get('reach', 0.49)
    facing *= (depth <= reach) & (depth >= -1e-05)
    return (uv, jac, facing)


def lookup(a, uv):
    co = [uv[:, 1] * (a.shape[0] - 1), uv[:, 0] * (a.shape[1] - 1)]
    if a.ndim == 3:
        return np.column_stack([map_coordinates(
            a[:, :, k],
            co,
            order=1,
            mode='constant',
            cval=0,
            prefilter=False
        ) for k in range(a.shape[2])])
    return map_coordinates(a, co, order=1, mode='constant', cval=0, prefilter=False)


def field(stamp, use, res=None):
    h = stamp.h
    mode = use['mode']
    if mode == 'carve':
        h = -np.abs(h)
    elif mode == 'raise':
        h = np.abs(h)
    h = h * stamp.a
    if res is not None:
        h = gaussian_filter(h, max(0.35, len(h) / max(res, 1) * 0.35), mode='constant')
    n = len(h)
    y, x = np.mgrid[0:n, 0:n] / (n - 1)
    feather = use.get('feather', 0.12)
    edge = smooth(np.minimum.reduce([x, 1 - x, y, 1 - y]) / feather)
    return (h * edge * use['depth'], stamp.a * edge)


def evaluate(pos, ns, bounds, use, h):
    uv, _, facing = coords(pos, ns, bounds, use)
    return lookup(h, uv) * facing


def groups(v):
    tol = max(float(np.max(np.ptp(v, axis=0))) * 1e-10, 1e-12)
    _, ids = np.unique(np.round(v / tol).astype(np.int64), axis=0, return_inverse=True)
    return ids


def split(mesh, chosen, edge_ids, edge_inv):
    f, v, n, uv = (mesh.f, mesh.v, mesh.n, mesh.uv)
    mask = chosen[edge_inv]
    count = mask.sum(1)
    ids = np.flatnonzero(chosen)
    mid = np.full(len(edge_ids), -1, np.int64)
    mid[ids] = len(v) + np.arange(len(ids))
    e = edge_ids[ids]
    v = np.vstack([v, v[e].mean(1)])
    n = np.vstack([n, unit(n[e].mean(1))])
    uv = np.vstack([uv, uv[e].mean(1)])
    mm = mid[edge_inv]
    rows = [f[count == 0]]
    for k in range(3):
        sel = (count == 1) & mask[:, k]
        a, b, c = [f[sel, (k + j) % 3] for j in range(3)]
        m = mm[sel, k]
        rows.extend([np.column_stack([a, m, c]), np.column_stack([m, b, c])])
        sel = (count == 2) & ~mask[:, k]
        a, b, c = [f[sel, (k + j) % 3] for j in range(3)]
        m, q = (mm[sel, (k + 1) % 3], mm[sel, (k + 2) % 3])
        rows.extend([np.column_stack([c, q, m]), np.column_stack([a, b, m]), np.column_stack([a, m, q])])
    sel = count == 3
    a, b, c = f[sel].T
    m, q, r = mm[sel].T
    rows.extend([
        np.column_stack([a, m, r]),
        np.column_stack([m, b, q]),
        np.column_stack([r, q, c]),
        np.column_stack([m, q, r])
    ])
    return Mesh(v, np.vstack(rows).astype(np.uint32), n, uv)


def region(mesh, bounds, use, support):
    uv, _, _ = coords(mesh.v, mesh.n, bounds, use)
    tri = uv[mesh.f]
    lo, hi = (tri.min(1), tri.max(1))
    inside = (hi[:, 0] >= 0) & (hi[:, 1] >= 0) & (lo[:, 0] <= 1) & (lo[:, 1] <= 1)
    lo = np.floor(np.clip(lo, 0, 1) * (len(support) - 2)).astype(int)
    hi = np.ceil(np.clip(hi, 0, 1) * (len(support) - 2)).astype(int) + 1
    amount = support[hi[:, 1], hi[:, 0]] - support[lo[:, 1], hi[:, 0]] - support[hi[:, 1], lo[:, 0]] + support[lo[:, 1], lo[:, 0]]
    ax, sign, *_ = FACES[use['side']]
    cutoff = np.cos(np.deg2rad(use.get('angle', 78)))
    inside &= np.max(sign * mesh.n[mesh.f, ax], axis=1) > cutoff
    depths = (mesh.v[:, ax] - bounds[0][ax]) / bounds[1][ax]
    if sign > 0:
        depths = 1 - depths
    inside &= depths[mesh.f].min(1) <= use.get('reach', 0.49)
    return inside & (amount > 0)


def refine(mesh, bounds, requests, lib, lod, limit):
    specs = []
    for use in requests:
        if use['mode'] == 'bump' or lod < use.get('geo_min', 0):
            continue
        res = max(4, round(use.get('res', 24) * lod))
        h, _ = field(lib[use['stamp']], use, res)
        support = np.pad(np.abs(h) > max(use['depth'] * 0.015, 1e-10), ((1, 0), (1, 0))).cumsum(0).cumsum(1)
        _, _, ux, _, vx, _ = FACES[use['side']]
        rect = use.get('rect', [0.1, 0.1, 0.8, 0.8])
        step = min(bounds[1][ux] * rect[2], bounds[1][vx] * rect[3]) / res
        specs.append((use, support, step))
    if not specs:
        return (mesh, 0)
    for iteration in range(16):
        f, v = (mesh.f, mesh.v)
        wedges = np.stack([f[:, [0, 1]], f[:, [1, 2]], f[:, [2, 0]]], axis=1)
        edges, inv = np.unique(np.sort(wedges.reshape(-1, 2), axis=1), axis=0, return_inverse=True)
        inv = inv.reshape(-1, 3)
        length = np.linalg.norm(v[edges[:, 0]] - v[edges[:, 1]], axis=1)
        chosen = np.zeros(len(edges), bool)
        for use, support, step in specs:
            active = region(mesh, bounds, use, support)
            take = np.zeros(len(edges), bool)
            take[inv[active].ravel()] = True
            chosen |= take & (length > step * 1.01)
        if not chosen.any():
            return (mesh, iteration)
        seam = groups(v)
        _, edge_group = np.unique(np.sort(seam[edges], axis=1), axis=0, return_inverse=True)
        mark = np.zeros(edge_group.max() + 1, bool)
        np.logical_or.at(mark, edge_group, chosen)
        chosen = mark[edge_group]
        estimate = len(f) + int(chosen[inv].sum())
        if estimate > limit:
            raise ValueError(f'Stamp refinement needs {estimate} triangles, above stamp_limit={limit}. Lower res or shrink the stamp, use bump mode, or explicitly raise the budget.')
        mesh = split(mesh, chosen, edges, inv)
    raise ValueError('Stamp refinement did not converge within 16 passes. Increase the stamp size or lower res.')


def corrected_normals(ref, v):
    tol = max(float(np.ptp(ref.v, axis=0).max()) * 1e-10, 1e-12)
    key = np.column_stack([np.round(ref.v / tol), np.round(ref.n * 10000)]).astype(np.int64)
    _, ids = np.unique(key, axis=0, return_inverse=True)
    result = []
    for pos in (ref.v, v):
        tri = pos[ref.f]
        cross = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        acc = np.zeros((int(ids.max()) + 1, 3))
        for k in range(3):
            np.add.at(acc, ids[ref.f[:, k]], cross)
        result.append(unit(acc)[ids])
    return unit(ref.n + result[1] - result[0])


def apply(mesh, uses, lib, lod=1, limit=30000, wall=None):
    """Apply geometric stamps and return the context required for aligned baking."""
    started = time.perf_counter()
    bounds = (mesh.v.min(0), np.maximum(np.ptp(mesh.v, axis=0), 1e-09))
    before = len(mesh.f)
    if before > limit:
        raise ValueError('Base mesh already exceeds stamp_limit.')
    ref, passes = refine(mesh, bounds, uses, lib, lod, limit)
    delta = np.zeros_like(ref.v)
    reports = []
    for use in uses:
        res = max(4, round(use.get('res', 24) * lod))
        h, _ = field(lib[use['stamp']], use, res)
        dh = evaluate(ref.v, ref.n, bounds, use, h)
        shading = use['mode'] == 'bump' or lod < use.get('geo_min', 0)
        count = int(np.count_nonzero(np.abs(dh) > 1e-09))
        if not shading and count < 3:
            raise ValueError(f"Stamp {use['stamp']} moved fewer than three vertices. Check side, rect, reach, mask or res.")
        if not shading:
            delta += ref.n * dh[:, None]
        reports.append({
            'stamp': use['stamp'],
            'mode': 'bump' if shading else use['mode'],
            'requested_depth_m': use['depth'],
            'affected_vertices': 0 if shading else count,
            'sampled_height_range_m': [float(dh.min()), float(dh.max())],
            'res': res,
            'source': lib[use['stamp']].cfg.get(
                'source',
                'provided' if lib[use['stamp']].cfg['kind'] == 'height' else 'procedural'
            )
        })
    ids = groups(ref.v)
    total = np.zeros((int(ids.max()) + 1, 3))
    np.add.at(total, ids, delta)
    delta = (total / np.bincount(ids)[:, None])[ids]
    inward = float(np.maximum(0, -np.sum(delta * ref.n, axis=1)).max())
    guard = 0.8 * wall if wall is not None else 0.45 * float(bounds[1].min())
    if inward > guard:
        raise ValueError(f'Stamp inward depth {inward:.6g} m exceeds the conservative target-thickness guard {guard:.6g} m. Reduce depth; stamps do not cut through surfaces.')
    v = ref.v + delta
    a, b = (ref.v[ref.f], v[ref.f])
    ca, cb = (np.cross(a[:, 1] - a[:, 0], a[:, 2] - a[:, 0]), np.cross(b[:, 1] - b[:, 0], b[:, 2] - b[:, 0]))
    if np.any(np.sum(ca * cb, axis=1) <= 0):
        raise ValueError('Stamp displacement inverted or collapsed a triangle. Reduce depth, avoid sharp corners, or split the placement.')
    out = Mesh(v, ref.f, corrected_normals(ref, v), ref.uv)
    stats = {
        'base_triangles': before,
        'final_triangles': len(out.f),
        'added_triangles': len(out.f) - before,
        'refine_passes': passes,
        'changed_vertices': int(np.count_nonzero(np.linalg.norm(delta, axis=1) > 1e-09)),
        'max_displacement_m': float(np.linalg.norm(delta, axis=1).max()),
        'uses': reports,
        'seconds': round(time.perf_counter() - started, 6),
        'operation': 'target displacement; no overlay or Boolean cutting'
    }
    return (out, Context(ref, out, bounds, uses, lib, stats))


def bake(ctx, base, normal, orm):
    started = time.perf_counter()
    ref, mesh = (ctx.ref, ctx.mesh)
    ids, w = raster(ref, len(base))
    ys, xs = np.where(ids >= 0)
    weights = np.column_stack([w[ys, xs], 1 - w[ys, xs].sum(1)])
    faces = ref.f[ids[ys, xs]]
    interp = lambda a: np.einsum('ij,ijk->ik', weights, a[faces])
    pos, ns = (interp(ref.v), unit(interp(ref.n)))
    actual = unit(interp(mesh.n))
    grad = np.zeros_like(pos)
    active = np.zeros(len(pos), bool)
    rows = []
    for use in ctx.uses:
        stamp = ctx.library[use['stamp']]
        h, alpha = field(stamp, use)
        uv, jac, facing = coords(pos, ns, ctx.bounds, use)
        a = lookup(alpha, uv) * facing * use.get('opacity', 1)
        gy, gx = np.gradient(h, 1 / (len(h) - 1))
        g = lookup(gx, uv)[:, None] * jac[0] + lookup(gy, uv)[:, None] * jac[1]
        grad += g * facing[:, None]
        active |= (np.abs(lookup(h, uv) * facing) > 1e-12) | (a > 1e-06)
        if stamp.color is not None:
            col = lookup(stamp.color, uv)
            base[ys, xs] = base[ys, xs] * (1 - a[:, None]) + col * a[:, None]
        for channel, key in ((1, 'rough'), (2, 'metal')):
            val = use.get(key, stamp.cfg.get(key))
            if val is not None:
                orm[ys, xs, channel] = orm[ys, xs, channel] * (1 - a) + val * a
        rows.append({'stamp': use['stamp'], 'pixels': int(np.count_nonzero(a > 1 / 255))})
    grad -= ns * np.sum(grad * ns, axis=1, keepdims=True)
    desired = unit(ns - grad)
    ts = tangents(mesh)
    t = interp(ts[:, :3])
    t = unit(t - actual * np.sum(t * actual, axis=1, keepdims=True))
    sign = np.sign(np.einsum('ij,ij->i', weights, ts[faces, 3]))
    b = np.cross(actual, t) * sign[:, None]
    residual = np.column_stack([
        np.sum(desired * t, axis=1),
        np.sum(desired * b, axis=1),
        np.sum(desired * actual, axis=1)
    ])
    prior = normal[ys, xs] * 2 - 1
    xy = prior[:, :2] / np.maximum(prior[:, 2:], 0.1) + residual[:, :2] / np.maximum(residual[:, 2:], 0.1)
    final = unit(np.column_stack([xy, np.ones(len(xy))])) * 0.5 + 0.5
    normal[ys[active], xs[active]] = final[active]
    mask = ids >= 0
    if not mask.all():
        dist, near = distance_transform_edt(~mask, return_indices=True)
        pad = ~mask & (dist <= 3)
        for a in (base, normal, orm):
            a[pad] = a[near[0][pad], near[1][pad]]
    return {
        'seconds': round(time.perf_counter() - started, 6),
        'stamps': rows,
        'normal_method': 'full field gradient relative to this LOD geometry; tangent-space residual',
        'warning': 'Height-field approximation; curvature derivatives and concave visibility are not solved.'
    }


def export_stamp(stamp, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    np.save(out / 'height.npy', stamp.h.astype(np.float32), allow_pickle=False)
    Image.fromarray(np.rint((stamp.h.clip(-1, 1) * 0.5 + 0.5) * 65535).astype(np.uint16)).save(out / 'height16.png')
    Image.fromarray(np.rint(stamp.a.clip(0, 1) * 255).astype(np.uint8)).save(out / 'mask.png')
    cfg = {
        'schema': 'ai3d.stamp/1',
        'kind': 'height',
        'height': 'height.npy',
        'mask': 'mask.png',
        'zero': 0,
        'range': 1,
        'size': len(stamp.h),
        'source': stamp.cfg.get('source', 'provided' if stamp.cfg['kind'] == 'height' else 'procedural')
    }
    for key in ('rough', 'metal'):
        if key in stamp.cfg:
            cfg[key] = stamp.cfg[key]
    if stamp.color is not None:
        Image.fromarray(np.rint(stamp.color.clip(0, 1) * 255).astype(np.uint8)).save(out / 'base.png')
        cfg['image'] = 'base.png'
    write(out / 'stamp.json', cfg)
    write(
        out / 'info.json',
        {
            'encoding': 'height.npy stores normalized signed float32; depth is specified per placement in meters',
            'height16_encoding': '(pixel/65535*2-1)',
            'source_definition': stamp.cfg,
            'height_range': [float(stamp.h.min()), float(stamp.h.max())]
        }
    )
    return {
        'ok': True,
        'asset': str((out / 'stamp.json').resolve()),
        'kind': stamp.cfg['kind'],
        'source': cfg['source']
    }
