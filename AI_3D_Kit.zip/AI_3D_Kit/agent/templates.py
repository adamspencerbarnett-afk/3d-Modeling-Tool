"""Provide small editable recipe templates, not saved binary demonstrations."""

from __future__ import annotations
import math


def base(name, brief, limit=5000):
    return {
        'schema': 'ai3d.recipe/1',
        'name': name,
        'brief': brief,
        'seed': 42,
        'texture_size': 512,
        'max_triangles': limit,
        'lods': [1, 0.5, 0.25],
        'materials': {},
        'parts': []
    }


def part(data, name, shape, mat, **kwargs):
    data['parts'].append(dict(name=name, shape=shape, mat=mat, **kwargs))


def pillar():
    d = base(
        'Weathered_Pillar',
        'A 2.9 meter aged stone pillar. Keep the profile in geometry and cracks in baked normal/color maps.',
        2500
    )
    d['materials'] = {
        'stone': {
            'kind': 'stone',
            'color': [0.62, 0.57, 0.46],
            'rough': 0.84,
            'bump': 0.0018,
            'layers': [
                {
                    'kind': 'stain',
                    'rect': [0.4, 0.72, 0.5, 0.25],
                    'color': [0.19, 0.23, 0.12],
                    'opacity': 0.5
                },
                {
                    'kind': 'crack',
                    'rect': [0.62, 0.17, 0.27, 0.5],
                    'color': [0.19, 0.16, 0.12],
                    'height': -0.003,
                    'opacity': 0.75,
                    'count': 4
                },
                {
                    'kind': 'crack',
                    'rect': [0.1, 0.38, 0.17, 0.27],
                    'color': [0.22, 0.2, 0.16],
                    'height': -0.002,
                    'seed': 15
                }
            ]
        },
        'base': {'kind': 'stone', 'color': [0.5, 0.46, 0.39], 'rough': 0.9, 'bump': 0.0012}
    }
    part(d, 'foot', 'box', 'base', size=[1.02, 0.22, 1.02], bevel=0.026, pos=[0, 0.11, 0])
    part(d, 'step', 'box', 'stone', size=[0.86, 0.16, 0.86], bevel=0.016, pos=[0, 0.3, 0])
    profile = [
        [0, 0],
        [0.37, 0],
        [0.37, 0.07],
        [0.32, 0.12],
        [0.305, 0.2],
        [0.28, 2.04],
        [0.31, 2.08],
        [0.35, 2.14],
        [0.35, 2.21],
        [0, 2.21]
    ]
    part(d, 'shaft', 'lathe', 'stone', profile=profile, steps=32, pos=[0, 0.38, 0])
    part(d, 'capital', 'box', 'stone', size=[0.83, 0.14, 0.83], bevel=0.012, pos=[0, 2.66, 0])
    part(d, 'cap', 'box', 'base', size=[0.98, 0.16, 0.98], bevel=0.018, pos=[0, 2.81, 0])
    return d


def crate():
    d = base(
        'Field_Crate',
        'A reinforced weathered wood equipment crate with metal corner posts, fasteners and UV-baked shipping stencils.',
        5000
    )
    d['lods'] = [1, 0.5]
    d['materials'] = {
        'wood': {'kind': 'wood', 'color': [0.39, 0.25, 0.12], 'rough': 0.77, 'bump': 0.001},
        'iron': {'kind': 'steel', 'color': [0.19, 0.22, 0.23], 'rough': 0.51, 'wear': 0.6, 'bump': 0.0003},
        'panel': {
            'kind': 'paint',
            'color': [0.26, 0.32, 0.25],
            'rough': 0.59,
            'wear': 0.35,
            'layers': [
                {
                    'kind': 'text',
                    'text': 'FIELD 07',
                    'rect': [0.03, 0.09, 0.27, 0.13],
                    'color': [0.83, 0.78, 0.6]
                },
                {
                    'kind': 'text',
                    'text': 'HANDLE WITH CARE',
                    'rect': [0.04, 0.24, 0.25, 0.05],
                    'color': [0.78, 0.72, 0.53]
                },
                {
                    'kind': 'stripe',
                    'rect': [0.035, 0.36, 0.263, 0.055],
                    'color': [0.65, 0.46, 0.09],
                    'count': 8
                },
                {
                    'kind': 'scratches',
                    'rect': [0.015, 0.02, 0.3, 0.43],
                    'color': [0.13, 0.1, 0.055],
                    'count': 26,
                    'height': -0.0003
                }
            ]
        }
    }
    part(d, 'body', 'box', 'wood', size=[1.12, 0.8, 0.8], bevel=0.01, pos=[0, 0.52, 0], tile=[2, 1])
    for x in [-0.5, 0.5]:
        for z in [-0.36, 0.36]:
            part(d, f"post_{len(d['parts'])}", 'box', 'iron', size=[0.095, 0.92, 0.095], bevel=0.01, pos=[x, 0.53, z])
    for z in [-0.43, 0.43]:
        for y in [0.15, 0.9]:
            part(d, f"rail_{len(d['parts'])}", 'box', 'wood', size=[1.21, 0.105, 0.065], bevel=0.009, pos=[0, y, z])
    for x in [-0.48, 0.48]:
        part(d, f"skid_{len(d['parts'])}", 'box', 'wood', size=[0.17, 0.12, 0.92], bevel=0.015, pos=[x, 0.06, 0])
    part(
        d,
        'front_panel',
        'box',
        'panel',
        size=[0.6, 0.37, 0.045],
        bevel=0.008,
        pos=[0, 0.57, 0.43],
        uv='box'
    )
    for z in [-0.4, 0.4]:
        for x in [-0.5, 0.5]:
            for y in [0.22, 0.78]:
                part(d, f"rivet_{len(d['parts'])}", 'cylinder', 'iron', radius=0.025, length=0.022, steps=8, pos=[x, y, z * 1.06], rot=[90, 0, 0], min_lod=0.75)
    for x in [-0.28, 0.28]:
        part(d, f"top_strap_{len(d['parts'])}", 'box', 'iron', size=[0.085, 0.04, 0.85], bevel=0.008, pos=[x, 0.94, 0])
    return d


def barrel():
    d = base(
        'Service_Drum',
        'A used steel service drum, blue-green paint, rolled ribs and two lid fittings. Keep rust and stenciling in materials.',
        4000
    )
    d['materials'] = {
        'paint': {
            'kind': 'paint',
            'color': [0.13, 0.32, 0.35],
            'rough': 0.47,
            'wear': 0.66,
            'bump': 0.0005,
            'layers': [
                {
                    'kind': 'text',
                    'text': 'SERVICE',
                    'rect': [0.625, 0.25, 0.25, 0.085],
                    'color': [0.78, 0.78, 0.65]
                },
                {'kind': 'text', 'text': '07', 'rect': [0.68, 0.36, 0.14, 0.14], 'color': [0.82, 0.79, 0.6]},
                {'kind': 'stripe', 'rect': [0.59, 0.58, 0.32, 0.043], 'color': [0.66, 0.49, 0.1], 'count': 8},
                {
                    'kind': 'scratches',
                    'rect': [0.45, 0.1, 0.5, 0.72],
                    'color': [0.37, 0.18, 0.065],
                    'count': 38,
                    'height': -0.0005,
                    'rough': 0.9
                }
            ]
        },
        'steel': {'kind': 'steel', 'color': [0.3, 0.31, 0.29], 'rough': 0.42, 'wear': 0.35}
    }
    profile = [
        [0, 0],
        [0.285, 0],
        [0.305, 0.015],
        [0.305, 0.035],
        [0.286, 0.055],
        [0.286, 0.24],
        [0.3, 0.26],
        [0.3, 0.28],
        [0.286, 0.3],
        [0.286, 0.58],
        [0.3, 0.6],
        [0.3, 0.62],
        [0.286, 0.64],
        [0.286, 0.82],
        [0.305, 0.84],
        [0.305, 0.86],
        [0.283, 0.88],
        [0, 0.88]
    ]
    part(d, 'shell', 'lathe', 'paint', profile=profile, steps=40)
    part(d, 'large_plug', 'cylinder', 'steel', radius=0.043, length=0.02, steps=12, pos=[0.12, 0.886, 0.09])
    part(d, 'small_plug', 'cylinder', 'steel', radius=0.024, length=0.018, steps=8, pos=[-0.13, 0.886, -0.09])
    part(d, 'plug_slot', 'box', 'steel', size=[0.06, 0.008, 0.008], pos=[0.12, 0.9, 0.09], min_lod=0.75)
    return d


def arch():
    d = base(
        'Courtyard_Arch',
        'A modular masonry arch. Separate wedge stones create the arch silhouette; roughness and small cracks stay in maps.',
        3500
    )
    d['lods'] = [1]
    d['materials'] = {
        'stone': {
            'kind': 'stone',
            'color': [0.59, 0.53, 0.43],
            'rough': 0.9,
            'bump': 0.0014,
            'layers': [{
                'kind': 'crack',
                'rect': [0.2, 0.05, 0.15, 0.62],
                'color': [0.25, 0.22, 0.18],
                'height': -0.001,
                'opacity': 0.45
            }]
        },
        'trim': {'kind': 'stone', 'color': [0.43, 0.4, 0.34], 'rough': 0.92, 'bump': 0.001}
    }
    for side in [-1, 1]:
        for i in range(5):
            part(d, f"block_{len(d['parts'])}", 'box', 'stone', size=[0.36, 0.294, 0.54], bevel=0.015, pos=[side * 0.98, 0.15 + i * 0.3, 0])
        part(d, f"foot_{len(d['parts'])}", 'box', 'trim', size=[0.53, 0.13, 0.68], bevel=0.015, pos=[side * 0.98, 0.065, 0])
        part(d, f"ledge_{len(d['parts'])}", 'box', 'trim', size=[0.5, 0.12, 0.64], bevel=0.012, pos=[side * 0.98, 1.54, 0])
    for i in range(11):
        a = i * math.pi / 11 + 0.009
        b = (i + 1) * math.pi / 11 - 0.009
        points = [
            [r * math.cos(t), 1.59 + r * math.sin(t)] for r,
            t in [(0.8, a), (1.16, a), (1.16, b), (0.8, b)]
        ]
        part(d, f'wedge_{i}', 'plate', 'stone', points=points, depth=0.54)
    return d
TEMPLATES = {'pillar': pillar, 'crate': crate, 'barrel': barrel, 'arch': arch}


def get(name):
    if name not in TEMPLATES:
        raise ValueError(f"Unknown template: {name}. Available: {', '.join(TEMPLATES)}")
    return TEMPLATES[name]()
