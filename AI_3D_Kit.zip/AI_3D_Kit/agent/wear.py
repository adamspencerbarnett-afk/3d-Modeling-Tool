"""Bake geometry-aware edge wear and dilate chart borders to reduce UV seams."""

from __future__ import annotations
import numpy as np
from scipy.ndimage import distance_transform_edt, gaussian_filter
from scipy.spatial import cKDTree
from agent.bake import surface
from core.mesh import unit


def edges(mesh, angle=24):
    scale = max(float(np.ptp(mesh.v, axis=0).max()), 1e-09)
    _, ids = np.unique(np.round(mesh.v / scale, 8), axis=0, return_inverse=True)
    tri = mesh.v[mesh.f]
    ns = unit(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]))
    found = {}
    for j, face in enumerate(mesh.f):
        for a, b in zip(face, np.roll(face, -1)):
            key = tuple(sorted((int(ids[a]), int(ids[b]))))
            if key not in found:
                found[key] = [mesh.v[a], mesh.v[b], []]
            found[key][2].append(ns[j])
    cutoff = np.cos(np.deg2rad(angle))
    return [
        (a, b) for a,
        b,
        ns in found.values() if len(ns) == 1 or np.min(np.asarray(ns) @ np.asarray(ns).T) < cutoff
    ]


def apply(mesh, base, rough, metal, cfg, seed):
    """Use actual hard edges, not arbitrary texture borders, to guide baked wear."""
    size = len(base)
    ys, xs, pos, _ = surface(mesh, size)
    width = cfg.get('edge_width', 0.008)
    segs = edges(mesh)
    if not segs or not len(pos):
        return {'samples': 0, 'hard_edges': len(segs), 'method': 'No eligible hard edges'}
    count = [max(2, int(np.ceil(np.linalg.norm(b - a) / (width * 0.4))) + 1) for a, b in segs]
    total = sum(count)
    if total > 250000:
        raise ValueError('Edge-wear sampling exceeds 250000 points. Increase edge_width or simplify the mesh.')
    pts = np.concatenate([np.linspace(a, b, n) for (a, b), n in zip(segs, count)])
    dist = cKDTree(pts).query(pos, workers=1)[0]
    rng = np.random.default_rng(seed)
    noise = gaussian_filter(rng.random((size, size)).astype(np.float32), max(0.4, size / 600), mode='wrap')
    gate = np.clip((noise[ys, xs] - 0.24) * 2.6, 0, 1)
    mask = np.exp(-(dist / width) ** 2) * gate * cfg['edge_wear']
    color = np.asarray(cfg.get('edge_color', [0.64, 0.64, 0.61]))
    base[ys, xs] = base[ys, xs] * (1 - mask[:, None]) + color * mask[:, None]
    rough[ys, xs] = rough[ys, xs] * (1 - mask) + 0.46 * mask
    metal[ys, xs] = metal[ys, xs] * (1 - mask) + 0.92 * mask
    return {
        'samples': total,
        'hard_edges': len(segs),
        'painted_texels': int((mask > 0.04).sum()),
        'method': 'Distance to sampled geometric hard edges; coplanar triangulation edges excluded; artistic wear'
    }


def pad(mesh, arrays, width=6):
    """Extend occupied chart texels into gutters to reduce filtering seams."""
    from agent.bake import raster
    ids, _ = raster(mesh, len(arrays[0]))
    empty = ids < 0
    dist, index = distance_transform_edt(empty, return_indices=True)
    take = empty & (dist <= width)
    for a in arrays:
        a[take] = a[index[0][take], index[1][take]]
