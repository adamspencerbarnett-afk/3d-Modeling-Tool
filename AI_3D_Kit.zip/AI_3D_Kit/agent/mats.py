"""Evaluate procedural or supplied-image materials and write glTF channel maps.

Base color and emission use sRGB images; scalar maps and normals are linear."""

from __future__ import annotations
from pathlib import Path
import numpy as np
import time
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
from scipy.ndimage import gaussian_filter, zoom
from agent.state import safe, write
from core.hash import digest


def read(path, mode, size):
    with Image.open(path) as im:
        if min(im.size) < 2 or im.width * im.height > 40000000:
            raise ValueError('Images must have 2 to 40 million pixels within supported dimensions.')
        return ImageOps.exif_transpose(im).convert(mode).resize((size, size), Image.Resampling.LANCZOS)


def noise(rng, n, sigma):
    cells = n if sigma <= 4 else max(16, round(n * 4 / sigma))
    a = gaussian_filter(rng.random((cells, cells)).astype(np.float32), sigma * cells / n, mode='wrap')
    if cells != n:
        a = zoom(a, n / cells, order=1, mode='grid-wrap', grid_mode=True, prefilter=False)
    return (a - a.mean()) / max(float(a.std()), 1e-06)


def linear(a):
    """Decode sRGB color samples before lighting and material multiplication."""
    a = np.asarray(a, dtype=np.float32)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)


def srgb(a):
    """Encode linear color samples for ordinary color-image storage."""
    a = np.maximum(np.asarray(a, dtype=np.float32), 0)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * a ** (1 / 2.4) - 0.055)


def color(cfg, target='srgb'):
    defaults = {
        'wood': [0.32, 0.18, 0.075],
        'steel': [0.3, 0.34, 0.37],
        'paint': [0.17, 0.34, 0.32],
        'concrete': [0.58, 0.56, 0.52],
        'stone': [0.48, 0.44, 0.36]
    }
    a = np.asarray(cfg.get('color', defaults.get(cfg['kind'], [0.6, 0.6, 0.6])), np.float32)
    source = cfg.get('color_space', 'linear' if cfg['kind'] == 'solid' else 'srgb')
    return a if target == source else linear(a) if target == 'linear' else srgb(a)


def field(cfg, n, seed):
    if cfg['kind'] in {'solid', 'image'}:
        col = color(cfg)
        return (
            np.broadcast_to(col, (n, n, 3)).copy(),
            np.zeros((n, n), np.float32),
            np.full((n, n), cfg.get('rough', 0.82), np.float32),
            np.full((n, n), cfg.get('metal', 0), np.float32)
        )
    rng = np.random.default_rng(seed)
    fine = noise(rng, n, 0.65)
    mid = noise(rng, n, max(1, n / 70))
    broad = noise(rng, n, max(2, n / 14))
    y, x = np.mgrid[0:n, 0:n] / n
    kind = cfg['kind']
    col = color(cfg)
    rough = np.full((n, n), cfg.get('rough', 0.45 if kind in {'steel', 'paint'} else 0.82), np.float32)
    metal = np.full((n, n), cfg.get('metal', 0.9 if kind == 'steel' else 0), np.float32)
    wear = cfg.get('wear', 0.2)
    bump = cfg.get('bump', 0.0005 if kind in {'steel', 'paint'} else 0.0015)
    f = 0.035 * fine + 0.04 * mid + 0.04 * broad
    h = bump * (0.2 * fine + 0.6 * mid)
    if kind == 'wood':
        grain = np.sin(x * 110 * np.pi + 3 * np.sin(y * 2 * np.pi) + 0.8 * broad)
        pores = np.power(np.maximum(0, grain), 6)
        f = 0.12 * mid + 0.14 * grain - 0.24 * pores + 0.025 * fine
        h = bump * (0.6 * grain - pores + 0.1 * fine)
        rough += 0.06 * grain
    elif kind == 'stone':
        veins = np.exp(-np.abs(mid + 0.25 * broad) * 18)
        f += 0.06 * veins
        h += bump * 0.1 * veins
    elif kind in {'steel', 'paint'}:
        scuff = gaussian_filter(rng.random((n, n)).astype(np.float32), (max(1, n / 140), 0.2), mode='wrap')
        scuff = (scuff - scuff.mean()) / max(float(scuff.std()), 1e-06)
        f = 0.018 * fine + 0.025 * broad + 0.016 * scuff
        h = bump * 0.15 * scuff
    base = np.clip(col[None, None, :] * (1 + f[:, :, None]), 0, 1)
    if kind in {'steel', 'paint'} and wear:
        rust = np.clip((mid + 0.6 * broad + 0.38 * fine - (2.4 - 1.4 * wear)) * wear * 1.9, 0, 0.92)
        rust_color = np.stack([0.26 + 0.07 * fine, 0.1 + 0.025 * fine, 0.035 + 0.012 * fine], axis=2)
        base = base * (1 - rust[:, :, None]) + np.clip(rust_color, 0, 1) * rust[:, :, None]
        rough = rough * (1 - rust) + 0.94 * rust
        metal *= 1 - rust
        h -= bump * rust
    return (base.astype(np.float32), h.astype(np.float32), np.clip(rough, 0.02, 1), metal)


def layer(cfg, w, h, seed, root):
    rng = np.random.default_rng(cfg.get('seed', seed))
    col = tuple((round(c * 255) for c in cfg.get('color', [0.06, 0.045, 0.03])))
    kind = cfg['kind']
    if kind == 'image':
        with Image.open(safe(root, cfg['image'])) as im:
            if im.width * im.height > 40000000:
                raise ValueError('Layer image exceeds 40 million pixels.')
            image = ImageOps.exif_transpose(im).convert('RGBA')
            if 'crop' in cfg:
                x, y, cw, ch = cfg['crop']
                image = image.crop((
                    round(x * image.width),
                    round(y * image.height),
                    round((x + cw) * image.width),
                    round((y + ch) * image.height)
                ))
            if min(image.size) < 1:
                raise ValueError('Image crop is smaller than one source pixel.')
            if 'tint' in cfg:
                a = np.asarray(image).copy()
                a[..., :3] = np.rint(a[..., :3] * np.asarray(cfg['tint'])).astype(np.uint8)
                image = Image.fromarray(a)
            fit = cfg.get('fit', 'stretch')
            if fit == 'cover':
                return ImageOps.fit(image, (w, h), Image.Resampling.LANCZOS)
            if fit == 'contain':
                image = ImageOps.contain(image, (w, h), Image.Resampling.LANCZOS)
                canvas = Image.new('RGBA', (w, h), (0, 0, 0, 0))
                canvas.paste(image, ((w - image.width) // 2, (h - image.height) // 2))
                return canvas
            return image.resize((w, h), Image.Resampling.LANCZOS)
    mask = Image.new('L', (w, h))
    d = ImageDraw.Draw(mask)
    count = cfg.get('count', 5)
    if kind == 'text':
        font = ImageFont.load_default(size=max(10, round(h * 0.7)))
        box = d.textbbox((0, 0), cfg['text'], font=font)
        stamp = Image.new('L', (max(1, box[2] - box[0] + 4), max(1, box[3] - box[1] + 4)))
        ImageDraw.Draw(stamp).text((2 - box[0], 2 - box[1]), cfg['text'], fill=255, font=font)
        stamp.thumbnail((w, h), Image.Resampling.LANCZOS)
        mask.paste(stamp, ((w - stamp.width) // 2, (h - stamp.height) // 2))
    elif kind == 'speckle':
        for _ in range(count * 24):
            x, y = rng.random(2) * [w, h]
            r = rng.uniform(0.0008, 0.0035) * min(w, h)
            d.ellipse((x - r, y - r, x + r, y + r), fill=int(rng.integers(70, 245)))
    elif kind == 'polygon':
        d.polygon([(x * w, y * h) for x, y in cfg['points']], fill=255)
    elif kind == 'stripe':
        yy, xx = np.mgrid[0:h, 0:w]
        mask = Image.fromarray(np.uint8((xx / max(1, h) + yy / max(1, h)) * count / 2 % 1 < 0.48) * 255)
    elif kind == 'stain':
        yy, xx = np.mgrid[-1:1:complex(h), -1:1:complex(w)]
        a = np.exp(-(xx * xx + yy * yy) * 3) * (0.45 + 0.55 * rng.random((h, w)))
        mask = Image.fromarray(np.uint8(a * 255)).filter(ImageFilter.GaussianBlur(max(0.5, w / 80)))
    elif kind == 'scratches':
        for _ in range(count):
            x, y = rng.uniform(0.04, 0.85, 2) * [w, h]
            end = (min(w - 1, x + rng.uniform(0.03, 0.15) * w), min(h - 1, y + rng.uniform(0.08, 0.35) * h))
            d.line([(x, y), end], fill=int(rng.integers(70, 210)), width=max(1, w // 400))
    elif kind == 'crack':
        yy = np.linspace(0.02 * h, 0.98 * h, 20)
        xx = 0.5 * w + np.cumsum(rng.normal(0, 0.055 * w, 20))
        xx = np.clip(xx, 0.12 * w, 0.88 * w)
        points = list(zip(xx, yy))
        width = max(1, round(min(w, h) / 95))
        d.line(points, fill=255, width=width, joint='curve')
        for i in rng.choice(np.arange(3, 17), size=min(count, 14), replace=False):
            branch = [(xx[i], yy[i])]
            for j in range(1, 5):
                branch.append((
                    np.clip(xx[i] + j * rng.uniform(-0.07, 0.07) * w, 0, w - 1),
                    yy[i] + j * 0.025 * h
                ))
            d.line(branch, fill=200, width=max(1, width // 2))
        mask = mask.filter(ImageFilter.GaussianBlur(0.35))
    result = Image.new('RGBA', (w, h), (*col, 255))
    result.putalpha(mask)
    return result


def normal(h, strength):
    """Convert a scalar height field to a tangent-space normal image."""
    dy, dx = np.gradient(h.astype(np.float32), 1 / max(h.shape[0] - 1, 1), 1 / max(h.shape[1] - 1, 1))
    n = np.stack([-dx * strength, -dy * strength, np.ones_like(dx)], axis=2)
    n /= np.linalg.norm(n, axis=2, keepdims=True)
    return np.uint8(np.rint((n * 0.5 + 0.5) * 255).clip(0, 255))


def make(cfg, out, size, seed, root, mesh=None, decals=None, stamp_ctx=None):
    """Bake the material maps needed by a GLB; preserve the selected conventions."""
    started = time.perf_counter()
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    seed = cfg.get('seed', seed)
    base, h, rough, metal = field(cfg, size, seed)
    sources = []
    if 'image' in cfg:
        p = safe(root, cfg['image'])
        base = np.asarray(read(p, 'RGB', size), np.float32) / 255
        sources.append({
            'channel': 'base',
            'path': cfg['image'],
            'sha256': digest(p),
            'source': cfg.get('source', 'provided')
        })
    if 'height' in cfg:
        p = safe(root, cfg['height'])
        with Image.open(p) as im:
            if im.width * im.height > 40000000:
                raise ValueError('Height image exceeds 40 million pixels.')
            raw = np.asarray(im)
            if raw.ndim != 2:
                raise ValueError('Supply a grayscale height map, not an RGB photograph.')
            div = 65535 if raw.dtype == np.uint16 or im.mode.startswith('I;16') or (im.mode == 'I' and raw.max() > 255 and (raw.max() <= 65535)) else 255 if raw.dtype == np.uint8 else 1
            a = raw.astype(np.float32) / div
            if not np.isfinite(a).all() or a.min() < 0 or a.max() > 1:
                raise ValueError('Height map values must be finite and normalized to [0,1].')
            a = np.asarray(Image.fromarray(a).resize((size, size), Image.Resampling.BILINEAR))
            h = (a - 0.5) * cfg.get('bump', 0.002)
        sources.append({'channel': 'height', 'path': cfg['height'], 'sha256': digest(p)})
    if 'orm' in cfg:
        p = safe(root, cfg['orm'])
        orm = np.asarray(read(p, 'RGB', size), np.float32) / 255
        rough, metal = (orm[:, :, 1].copy(), orm[:, :, 2].copy())
        ao = orm[:, :, 0].copy()
        sources.append({'channel': 'orm', 'path': cfg['orm'], 'sha256': digest(p)})
    else:
        ao = np.ones((size, size), np.float32)
    channels = {'rough_map': rough, 'metal_map': metal, 'ao_map': ao}
    for key, channel in channels.items():
        if key in cfg:
            path = safe(root, cfg[key])
            channel[:] = np.asarray(read(path, 'L', size), np.float32) / 255
            sources.append({'channel': key, 'path': cfg[key], 'sha256': digest(path)})
    for i, spec in enumerate(cfg.get('layers', [])):
        u, v, w, hh = spec.get('rect', [0, 0, 1, 1])
        x, y = (min(size - 1, round(u * size)), min(size - 1, round(v * size)))
        w, hh = (min(size - x, max(1, round(w * size))), min(size - y, max(1, round(hh * size))))
        rgba = np.asarray(layer(spec, w, hh, seed + i * 1009, root), np.float32) / 255
        a = rgba[:, :, 3] * spec.get('opacity', 1)
        region = np.s_[y:y + hh, x:x + w]
        base[region] = base[region] * (1 - a[:, :, None]) + rgba[:, :, :3] * a[:, :, None]
        if 'height' in spec:
            h[region] += a * spec['height']
        if 'rough' in spec:
            rough[region] = rough[region] * (1 - a) + spec['rough'] * a
        if 'metal' in spec:
            metal[region] = metal[region] * (1 - a) + spec['metal'] * a
        if 'image' in spec:
            sources.append({'channel': f'layer_{i}', 'path': spec['image'], 'sha256': digest(safe(root, spec['image']))})
    edge_info = None
    if cfg.get('edge_wear', 0):
        if mesh is None:
            raise ValueError('edge_wear requires a mesh with unique atlas UVs.')
        from agent.wear import apply
        edge_info = apply(mesh, base, rough, metal, cfg, seed)
    stamp_info = None
    stamp_normal = None
    if stamp_ctx is not None:
        from agent.stamps import bake
        stamp_normal = (np.asarray(
            read(safe(root, cfg['normal']), 'RGB', size),
            np.float64
        ) if 'normal' in cfg else normal(h, cfg.get('normal_strength', 0.65)).astype(np.float64)) / 255
        stamp_orm = np.stack([ao, rough, metal], axis=2)
        stamp_info = bake(stamp_ctx, base, stamp_normal, stamp_orm)
        ao, rough, metal = [stamp_orm[:, :, i] for i in range(3)]
    projection = None
    if decals:
        from agent.bake import project
        if mesh is None:
            raise ValueError('A mesh is required for projected decals.')
        projection = project(mesh, decals, base, h, rough, metal, root, seed)
        for i, spec in enumerate(decals):
            if 'image' in spec:
                sources.append({'channel': f'projected_{i}', 'path': spec['image'], 'sha256': digest(safe(root, spec['image'])), 'crop': spec.get('crop')})
    if mesh is not None and (not stamp_ctx):
        from agent.wear import pad
        pad(mesh, [base, rough, metal, ao, h])
    maps = {'base': out / 'base.png', 'normal': out / 'normal.png', 'orm': out / 'orm.png'}
    Image.fromarray(np.uint8(np.rint(base.clip(0, 1) * 255))).save(maps['base'], compress_level=3)
    Image.fromarray(np.uint8(np.rint(np.stack(
        [ao, rough, metal],
        axis=2
    ).clip(0, 1) * 255))).save(maps['orm'], compress_level=3)
    if stamp_normal is not None:
        if 'normal' in cfg:
            sources.append({
                'channel': 'normal',
                'path': cfg['normal'],
                'sha256': digest(safe(root, cfg['normal']))
            })
        Image.fromarray(np.uint8(np.rint(stamp_normal.clip(0, 1) * 255))).save(maps['normal'], compress_level=3)
    elif 'normal' in cfg:
        p = safe(root, cfg['normal'])
        read(p, 'RGB', size).save(maps['normal'], compress_level=3)
        sources.append({'channel': 'normal', 'path': cfg['normal'], 'sha256': digest(p)})
    else:
        Image.fromarray(normal(h, cfg.get('normal_strength', 0.65))).save(maps['normal'], compress_level=3)
    if 'normal' in cfg and cfg.get('normal_y', 'opengl') == 'directx':
        with Image.open(maps['normal']) as im:
            a = np.asarray(im).copy()
        a[:, :, 1] = 255 - a[:, :, 1]
        Image.fromarray(a).save(maps['normal'], compress_level=3)
    if 'emissive' in cfg:
        p = safe(root, cfg['emissive'])
        maps['emissive'] = out / 'emissive.png'
        read(p, 'RGB', size).save(maps['emissive'], compress_level=3)
        sources.append({'channel': 'emissive', 'path': cfg['emissive'], 'sha256': digest(p)})
    meta = {
        'edge_wear': edge_info,
        'color_space': 'sRGB base/emissive; linear normal and ORM',
        'kind': cfg['kind'],
        'size': size,
        'seed': seed,
        'sources': sources,
        'projection': projection,
        'stamps': stamp_info,
        'seconds': round(time.perf_counter() - started, 6),
        'detail_method': 'LOD-specific residual normals over displaced geometry' if stamp_ctx is not None else 'UV material baking; zero added triangles; no mesh displacement',
        'normal_convention': 'glTF tangent space, positive green along increasing V',
        'maps': {k: {'file': p.name, 'sha256': digest(p)} for k, p in maps.items()}
    }
    write(out / 'material.json', meta)
    return (maps, meta)


def plain(cfg):
    return cfg['kind'] == 'solid' and set(cfg) <= {
        'kind',
        'color',
        'rough',
        'metal',
        'emission',
        'tex_size',
        'source',
        'prompt',
        'color_space',
        'seed',
        'wrap',
        'normal_scale'
    }
