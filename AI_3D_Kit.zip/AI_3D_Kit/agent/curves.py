"""Sample smooth parametric recipe shapes within explicit geometry budgets."""

from __future__ import annotations
import math
import numpy as np
from core.mesh import Mesh, merge, unit


def steps_for(radius, error, cap=256):
    if not math.isfinite(radius) or not math.isfinite(error) or radius <= 0 or (error <= 0):
        raise ValueError('Radius and chord error must be positive and finite.')
    n = max(8, math.ceil(math.pi / math.acos(max(-1, 1 - min(error / radius, 1)))))
    n = 4 * math.ceil(n / 4)
    if n > cap:
        raise ValueError(f'Chord error requires {n} segments, above the {cap} segment limit. Increase error.')
    return n


def grid_faces(rows, cols, flip=False):
    a = (np.arange(rows - 1)[:, None] * cols + np.arange(cols - 1)).ravel()
    b = a + cols
    f = np.stack([np.column_stack([a, b, a + 1]), np.column_stack([a + 1, b, b + 1])], axis=1).reshape(-1, 3)
    return np.asarray(f[:, ::-1] if flip else f, np.uint32)


def clean(v, f, n, uv):
    v = np.asarray(v, float).reshape(-1, 3)
    n = np.asarray(n, float).reshape(-1, 3)
    f = np.asarray(f, np.uint32).reshape(-1, 3)
    t = v[f]
    good = np.linalg.norm(np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]), axis=1) > 1e-13
    return Mesh(v, f[good], unit(n), np.asarray(uv, float).reshape(-1, 2))


def ellipsoid(size, steps, rings):
    r = np.asarray(size, float) / 2
    if r.shape != (3,) or np.any(r <= 0):
        raise ValueError('Ellipsoid size needs three positive full dimensions.')
    phi = np.linspace(np.pi, 0, rings + 1)
    theta = np.linspace(0, 2 * np.pi, steps + 1)
    v = np.stack(
        [
            r[0] * np.sin(phi[:, None]) * np.cos(theta),
            np.broadcast_to(r[1] * np.cos(phi[:, None]), (rings + 1, steps + 1)),
            -r[2] * np.sin(phi[:, None]) * np.sin(theta)
        ],
        axis=2
    )
    uv = np.stack(np.meshgrid(np.linspace(0, 1, steps + 1), np.linspace(1, 0, rings + 1)), axis=2)
    return clean(v, grid_faces(rings + 1, steps + 1, True), v / (r * r), uv)


def torus(radius, tube, steps, rings):
    if tube >= radius:
        raise ValueError('Torus tube must be smaller than its major radius.')
    a = np.linspace(0, 2 * np.pi, steps + 1)
    b = np.linspace(0, 2 * np.pi, rings + 1)
    rr = radius + tube * np.cos(b[:, None])
    v = np.stack(
        [rr * np.cos(a), np.broadcast_to(tube * np.sin(b[:, None]), (rings + 1, steps + 1)), -rr * np.sin(a)],
        axis=2
    )
    n = np.stack(
        [
            np.cos(b[:, None]) * np.cos(a),
            np.broadcast_to(np.sin(b[:, None]), (rings + 1, steps + 1)),
            -np.cos(b[:, None]) * np.sin(a)
        ],
        axis=2
    )
    uv = np.stack(np.meshgrid(np.linspace(0, 1, steps + 1), np.linspace(0, 1, rings + 1)), axis=2)
    return clean(v, grid_faces(rings + 1, steps + 1, True), n, uv)


def bowl(size, depth, steps, rings, power=2, taper=0.58, lean=0):
    w, h, d = np.asarray(size, float)
    if depth >= min(w, h, d) / 4:
        raise ValueError('Bowl wall thickness must be less than one quarter of its smallest dimension.')
    t = np.linspace(0, 2 * np.pi, steps + 1)
    x = np.sign(np.cos(t)) * np.abs(np.cos(t)) ** (2 / power)
    z = -np.sign(np.sin(t)) * np.abs(np.sin(t)) ** (2 / power)
    side = np.linspace(0, 1, rings + 1)
    side = np.sin(side * np.pi / 2)
    rows = [(0.0, -h / 2, 0.0, 0.0)]
    for q in side:
        r = taper + (1 - taper) * q
        rows.append((w / 2 * r, -h / 2 + h * q ** 1.8, d / 2 * r, lean * q))
    rows.append((w / 2 - depth, h / 2, d / 2 - depth, lean))
    for q in side[-2::-1]:
        r = taper + (1 - taper) * q
        rows.append((
            max(depth, w / 2 * r - depth),
            -h / 2 + depth + (h - depth) * q ** 1.8,
            max(depth, d / 2 * r - depth),
            lean * q
        ))
    rows.append((0.0, -h / 2 + depth, 0.0, 0.0))
    rows = np.asarray(rows)
    v = np.stack(
        [
            rows[:, 0, None] * x,
            np.broadcast_to(rows[:, 1, None], (len(rows), steps + 1)),
            rows[:, 3, None] + rows[:, 2, None] * z
        ],
        axis=2
    )
    dist = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(rows[:, :3], axis=0), axis=1))]
    vv = 1 - dist / dist[-1]
    parts = []
    for i in range(len(rows) - 1):
        verts = v[i:i + 2]
        around = np.roll(verts[:, :-1], -1, axis=1) - np.roll(verts[:, :-1], 1, axis=1)
        around = np.concatenate([around, around[:, :1]], axis=1)
        along = np.broadcast_to(verts[1] - verts[0], verts.shape)
        ns = np.cross(around, along)
        for j in range(2):
            if np.max(np.linalg.norm(around[j], axis=1)) < 1e-12:
                ns[j] = np.array([0, -1 if i == 0 else 1, 0])
        uv = np.stack(np.meshgrid(np.linspace(0, 1, steps + 1), vv[i:i + 2]), axis=2)
        parts.append(clean(verts, grid_faces(2, steps + 1, True), ns, uv))
    for row in list(range(2, rings + 1)) + list(range(rings + 3, len(rows) - 2)):
        left, right = (parts[row - 1], parts[row])
        ns = unit(left.n[-(steps + 1):] + right.n[:steps + 1])
        left.n[-(steps + 1):] = ns
        right.n[:steps + 1] = ns
    return merge(parts)
