"""Manage bounded files, artifact fingerprints, and offline environment checks."""

from __future__ import annotations
import hashlib
import importlib
import importlib.metadata
import json
import os
import sys
import tempfile
from pathlib import Path
from agent import VERSION
from core.hash import digest
ROOT = Path(__file__).resolve().parents[1]
DEPS = {'numpy': 'numpy', 'scipy': 'scipy', 'Pillow': 'PIL', 'jsonschema': 'jsonschema'}

PACKAGE_DIRS = ('agent', 'core', 'examples', 'tests', 'tools', 'docs', '.github')
ROOT_SUFFIXES = {'.py', '.md', '.txt', '.toml', '.yml', '.yaml'}
ROOT_NAMES = {'LICENSE', 'NOTICE', '.gitignore', '.gitattributes', '.editorconfig'}
SKIP_DIRS = {'__pycache__', '.pytest_cache', '.ruff_cache', '.mypy_cache', '.git', '.venv', 'venv'}
PRIVATE_SUFFIXES = {'.pem', '.key', '.p12', '.pfx', '.ppk'}
PACKAGE_SUFFIXES = {'.py', '.html', '.json', '.md', '.txt', '.toml', '.yml', '.yaml', '.png', '.jpg', '.jpeg', '.webp', '.svg'}


def code_files():
    """Fingerprint distributable sources, docs, artwork, and CI configuration.

    Generated outputs, virtual environments, Git state, and local secrets are
    outside this inventory. Any link in a tracked source folder is rejected.
    """
    paths = []

    def visit(folder):
        for path in sorted(folder.iterdir()):
            if path.name in SKIP_DIRS:
                continue
            if path.is_symlink():
                raise ValueError('Kit source files and folders must not be symbolic links.')
            if path.is_dir():
                visit(path)
            elif path.is_file():
                if path.name.startswith('.env') or path.suffix.lower() in PRIVATE_SUFFIXES:
                    raise ValueError('Sensitive local files must stay outside package folders.')
                if path.suffix.lower() in PACKAGE_SUFFIXES:
                    paths.append(path)

    for path in sorted(ROOT.iterdir()):
        include = path.name in ROOT_NAMES or path.suffix in ROOT_SUFFIXES
        if path.name in PACKAGE_DIRS:
            if path.is_symlink() or not path.is_dir():
                raise ValueError('Tracked package directories must be real directories.')
            visit(path)
        elif include and path.is_symlink():
            raise ValueError('Kit source files must not be symbolic links.')
        elif include and path.is_file():
            paths.append(path)
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in sorted(paths)}


def source():
    """Digest the sorted release inventory, including documentation and CI files."""
    return hashlib.sha256(json.dumps(code_files(), sort_keys=True).encode()).hexdigest()


def write(path, data):
    """Atomically replace a JSON file after writing finite data to a sibling stage."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, allow_nan=False)
            f.write('\n')
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def read(path, limit=16 * 1048576):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > limit:
        raise ValueError(f'JSON input must be an existing file no larger than {limit // 1048576} MiB.')
    return json.loads(path.read_text(encoding='utf-8'))


def safe(root, name, limit=40 * 1048576):
    """Resolve an existing bounded asset without traversal outside its root."""
    root = Path(root).resolve()
    if not isinstance(name, str) or not name or '\\' in name or (':' in name) or ('\x00' in name):
        raise ValueError(f'Use a relative asset path with forward slashes: {name!r}')
    path = root / name
    if Path(name).is_absolute() or '..' in Path(name).parts:
        raise ValueError(f'Asset path must stay inside its folder: {name}')
    if path.is_symlink() or not path.resolve().is_relative_to(root) or (not path.is_file()):
        raise ValueError(f'Asset must be an existing file inside its folder: {name}')
    if path.stat().st_size > limit:
        raise ValueError(f'Asset exceeds the {limit // 1048576} MiB input limit: {name}')
    return path.resolve()


def output_path(path, allow_existing=False):
    path = Path(path)
    if path.is_symlink():
        raise ValueError('Output must not be a symbolic link.')
    path = path.resolve()
    if path.is_relative_to(ROOT) or ROOT.is_relative_to(path):
        raise ValueError('Keep output outside the kit folder and its parent; use a sibling work folder.')
    if path.exists() and (not allow_existing):
        raise FileExistsError('Output already exists. Choose a new folder to preserve earlier work.')
    return path


def verify():
    """Compare an unsigned manifest with current files; this is not authentication."""
    path = ROOT / 'MANIFEST.json'
    current = code_files()
    key = hashlib.sha256(json.dumps(current, sort_keys=True).encode()).hexdigest()
    if not path.is_file():
        return {'ok': True, 'release_verified': False, 'source_sha256': key, 'status': 'development copy'}
    saved = read(path)
    old = saved['files']
    changed = sorted((k for k in set(old) | set(current) if old.get(k) != current.get(k)))
    ok = not changed and key == saved.get('source_sha256') and saved.get('version') == VERSION
    return {'ok': ok, 'release_verified': ok, 'changed': changed, 'source_sha256': key}


def doctor(smoke=False):
    """Check installed dependencies and optionally build, validate, and render a fixture."""
    versions, errors = ({}, {})
    for name, module in DEPS.items():
        try:
            versions[name] = importlib.metadata.version(name)
            importlib.import_module(module)
        except Exception as exc:
            versions[name] = None
            errors[name] = str(exc)
    try:
        versions['trimesh'] = importlib.metadata.version('trimesh')
    except importlib.metadata.PackageNotFoundError:
        versions['trimesh'] = None
    release = verify()
    ok = sys.version_info >= (3, 11) and (not errors) and release['ok']
    result = {
        'ok': ok,
        'version': VERSION,
        'python': sys.version.split()[0],
        'dependencies': versions,
        'missing': [k for k in DEPS if not versions[k]],
        'errors': errors,
        'release': release,
        'capabilities': {
            'recipe_build': not errors,
            'glb_import_edit': not errors,
            'obj_stl_ply_import_available_not_tested': bool(versions['trimesh']),
            'cpu_preview': not errors,
            'heightmap_relief': not errors,
            'imported_mesh_retexture': not errors,
            'pbr_texture_baking': not errors,
            'uv_atlas_metric_custom': not errors,
            'embedded_texture_inspection': not errors,
            'neural_image_to_3d': False,
            'network_required': False,
            'host_image_generation': 'Depends on the chat tools and accessible image files'
        },
        'setup': 'Reuse installed packages. requirements.txt is only for missing core packages; requirements-import.txt adds optional OBJ/STL/PLY support.'
    }
    if smoke and ok:
        try:
            from core.mesh import GLB, box
            from core.validate import check
            from agent.preview import render
            with tempfile.TemporaryDirectory(prefix='ai3d-check-') as tmp:
                root = Path(tmp)
                g = GLB()
                from agent.mats import make
                from agent.quality import inspect
                maps, _ = make(
                    {'kind': 'steel', 'color': [0.4, 0.45, 0.5], 'wear': 0.5},
                    root / 'maps',
                    64,
                    7,
                    root
                )
                g.material('surface', color=(1, 1, 1, 1), metal=1, rough=1, maps=maps, emission=[0.03, 0, 0])
                g.add_mesh('box', box((1, 1, 1), 0), 'surface')
                g.save(root / 'check.glb')
                valid = check(root / 'check.glb')
                if not valid['passed']:
                    raise ValueError('; '.join(valid['errors']))
                render(root / 'check.glb', root / 'views', size=96)
                result['smoke_test'] = {
                    'ok': True,
                    'triangles': valid['rendered_triangles'],
                    'renders': 3,
                    'embedded_images': inspect(root / 'check.glb')['embedded_images_used']
                }
        except Exception as exc:
            result['ok'] = False
            result['smoke_test'] = {'ok': False, 'error': str(exc)}
    return result
