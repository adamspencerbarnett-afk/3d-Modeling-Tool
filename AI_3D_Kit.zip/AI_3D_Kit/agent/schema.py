"""Define bounded JSON contracts and validate cross-field modeling constraints."""

from __future__ import annotations
import math


def num(lo=-10000, hi=10000):
    return {'type': 'number', 'minimum': lo, 'maximum': hi}


def vec(n, lo=-10000, hi=10000):
    return {'type': 'array', 'items': num(lo, hi), 'minItems': n, 'maxItems': n}


def obj(props, required=()):
    return {'type': 'object', 'properties': props, 'required': list(required), 'additionalProperties': False}


def arr(item, lo=0, hi=256):
    return {'type': 'array', 'items': item, 'minItems': lo, 'maxItems': hi}
NAME = {'type': 'string', 'pattern': '^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$'}
PATH = {'type': 'string', 'minLength': 1, 'maxLength': 512}
LAYER = obj(
    {
        'kind': {'enum': ['image', 'text', 'crack', 'stain', 'scratches', 'stripe', 'polygon', 'speckle']},
        'fit': {'enum': ['contain', 'cover', 'stretch']},
        'crop': vec(4, 0, 1),
        'rect': vec(4, 0, 1),
        'color': vec(3, 0, 1),
        'tint': vec(3, 0, 1),
        'opacity': num(0, 1),
        'points': arr(vec(2, 0, 1), 3, 64),
        'image': PATH,
        'prompt': {'type': 'string', 'maxLength': 2000},
        'text': {'type': 'string', 'maxLength': 80},
        'height': num(-0.1, 0.1),
        'rough': num(0, 1),
        'metal': num(0, 1),
        'seed': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647},
        'count': {'type': 'integer', 'minimum': 1, 'maximum': 64}
    },
    ['kind']
)
DECAL = obj(
    {
        **LAYER['properties'],
        'side': {'enum': ['front', 'back', 'left', 'right', 'top', 'bottom']},
        'angle': num(1, 89),
        'reach': num(0.001, 1),
        'turn': num(-360, 360)
    },
    ['kind', 'side']
)
MAT = obj(
    {
        'kind': {'enum': ['concrete', 'wood', 'steel', 'paint', 'stone', 'solid', 'image']},
        'color': vec(3, 0, 1),
        'rough': num(0, 1),
        'metal': num(0, 1),
        'tex_size': {'type': 'integer', 'enum': [64, 128, 256, 512, 1024, 2048]},
        'wear': num(0, 1),
        'bump': num(0, 0.1),
        'normal_strength': num(0, 4),
        'image': PATH,
        'normal': PATH,
        'orm': PATH,
        'height': PATH,
        'rough_map': PATH,
        'metal_map': PATH,
        'ao_map': PATH,
        'emissive': PATH,
        'color_space': {'enum': ['srgb', 'linear']},
        'normal_y': {'enum': ['opengl', 'directx']},
        'normal_scale': num(0, 4),
        'wrap': {'enum': ['repeat', 'clamp', 'mirror']},
        'edge_wear': num(0, 1),
        'edge_width': num(1e-05, 100),
        'edge_color': vec(3, 0, 1),
        'seed': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647},
        'source': {'enum': ['procedural', 'photo', 'generated', 'provided']},
        'prompt': {'type': 'string', 'maxLength': 2000},
        'layers': arr(LAYER, hi=32),
        'emission': vec(3, 0, 1)
    },
    ['kind']
)
STAMP = obj({
    'schema': {'const': 'ai3d.stamp/1'},
    'asset': PATH,
    'kind': {'enum': ['crack', 'chip', 'bark', 'rosette', 'dent', 'height']},
    'height': PATH,
    'image': PATH,
    'mask': PATH,
    'zero': num(-1, 1),
    'range': num(1e-06, 4),
    'size': {'type': 'integer', 'enum': [64, 128, 256, 512, 1024]},
    'seed': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647},
    'color': vec(3, 0, 1),
    'rough': num(0, 1),
    'metal': num(0, 1),
    'source': {'enum': ['procedural', 'provided', 'authored', 'photo', 'inferred', 'generated', 'scanned']}
})
USE = obj(
    {
        'stamp': NAME,
        'side': {'enum': ['front', 'back', 'left', 'right', 'top', 'bottom']},
        'mode': {'enum': ['carve', 'raise', 'signed', 'bump']},
        'depth': num(1e-06, 100),
        'rect': vec(4, 0, 1),
        'turn': num(-360, 360),
        'feather': num(0.005, 0.4),
        'angle': num(1, 85),
        'reach': num(0.001, 0.95),
        'opacity': num(0, 1),
        'res': {'type': 'integer', 'minimum': 8, 'maximum': 96},
        'geo_min': num(0, 1),
        'rough': num(0, 1),
        'metal': num(0, 1)
    },
    ['stamp', 'side', 'mode', 'depth']
)
SCULPT = obj(
    {
        'name': NAME,
        'brush': {'enum': ['draw', 'carve', 'inflate', 'grab', 'pinch', 'crease', 'flatten', 'smooth']},
        'center': vec(3),
        'path': arr(vec(3), 1, 128),
        'space': {'enum': ['local', 'bounds']},
        'radius': num(1e-06, 1000),
        'depth': num(-100, 100),
        'strength': num(0, 1),
        'weight': num(0, 1),
        'move': vec(3),
        'normal': vec(3, -1, 1),
        'angle': num(1, 90),
        'symmetry': {'enum': ['none', 'x', 'y', 'z']},
        'plane': num(),
        'connected': {'type': 'boolean'},
        'step': num(1e-06, 100)
    },
    ['brush', 'radius']
)
PART = obj(
    {
        'name': NAME,
        'shape': {'enum': [
            'box',
            'cylinder',
            'sphere',
            'ellipsoid',
            'torus',
            'bowl',
            'lathe',
            'hose',
            'plate',
            'prism',
            'mesh'
        ]},
        'sculpt': arr(SCULPT, hi=192),
        'sculpt_limit': {'type': 'integer', 'minimum': 12, 'maximum': 200000},
        'decals': arr(DECAL, hi=24),
        'stamps': arr(USE, hi=24),
        'stamp_limit': {'type': 'integer', 'minimum': 12, 'maximum': 200000},
        'error': num(1e-06, 100),
        'tube': num(0.0001, 10000),
        'power': num(2, 5),
        'taper': num(0.1, 1),
        'lean': num(-100, 100),
        'mat': NAME,
        'size': vec(3, 0.0001, 10000),
        'bevel': num(0, 100),
        'radius': num(0.0001, 10000),
        'length': num(0.0001, 10000),
        'inner': num(0, 10000),
        'top': num(0.0001, 10000),
        'steps': {'type': 'integer', 'minimum': 6, 'maximum': 256},
        'rings': {'type': 'integer', 'minimum': 4, 'maximum': 128},
        'samples': {'type': 'integer', 'minimum': 2, 'maximum': 128},
        'profile': arr(vec(2), 2, 128),
        'points': arr({'type': 'array', 'items': num(), 'minItems': 2, 'maxItems': 3}, 2, 128),
        'depth': num(0.0001, 10000),
        'pos': vec(3),
        'rot': vec(3, -36000, 36000),
        'scale': vec(3, 0.0001, 10000),
        'uv': {'enum': ['tile', 'box', 'cylinder', 'atlas', 'metric']},
        'uv_size': num(0.0001, 10000),
        'tile': vec(2, 0.001, 100),
        'min_lod': num(0, 1),
        'uvs': arr(vec(2), 3, 30000),
        'v': arr(vec(3), 3, 30000),
        'f': arr(
            {
                'type': 'array',
                'items': {'type': 'integer', 'minimum': 0, 'maximum': 29999},
                'minItems': 3,
                'maxItems': 3
            },
            1,
            60000
        )
    },
    ['name', 'shape', 'mat']
)
ANCHOR = {'oneOf': [vec(3), obj({'part': NAME, 'point': vec(3)}, ['part'])]}
HAND = obj(
    {
        'name': {'type': 'string', 'pattern': '^[A-Za-z0-9][A-Za-z0-9_-]{0,47}$'},
        'side': {'enum': ['left', 'right']},
        'elbow': ANCHOR,
        'wrist': ANCHOR,
        'palm': vec(3, -10000, 10000),
        'direction': vec(3, -10000, 10000),
        'size': vec(3, .001, 10),
        'curl': num(0, 60),
        'spread': num(0, 15),
        'mat': NAME,
        'joint_mat': NAME,
        'armor_mat': NAME,
    },
    ['name', 'side', 'elbow', 'wrist', 'palm', 'mat', 'joint_mat', 'armor_mat']
)
SCHEMA = obj(
    {
        'schema': {'const': 'ai3d.recipe/1'},
        'name': NAME,
        'brief': {'type': 'string', 'maxLength': 10000},
        'seed': {'type': 'integer', 'minimum': 0, 'maximum': 2147483647},
        'texture_size': {'type': 'integer', 'enum': [64, 128, 256, 512, 1024, 2048]},
        'max_triangles': {'type': 'integer', 'minimum': 12, 'maximum': 200000},
        'lods': arr(num(0.1, 1), 1, 4),
        'materials': {
            'type': 'object',
            'minProperties': 1,
            'maxProperties': 32,
            'propertyNames': NAME,
            'additionalProperties': MAT
        },
        'stamps': {
            'type': 'object',
            'maxProperties': 64,
            'propertyNames': NAME,
            'additionalProperties': STAMP
        },
        'hands': arr(HAND, 0, 8),
        'parts': arr(PART, 1, 256)
    },
    ['schema', 'name', 'materials', 'parts']
)
SCHEMA['$schema'] = 'https://json-schema.org/draft/2020-12/schema'


def finite(x):
    if isinstance(x, float) and (not math.isfinite(x)):
        raise ValueError('All numbers must be finite.')
    if isinstance(x, dict):
        for v in x.values():
            finite(v)
    elif isinstance(x, list):
        for v in x:
            finite(v)


def validate(data):
    from jsonschema import Draft202012Validator
    finite(data)
    error = next(iter(Draft202012Validator(SCHEMA).iter_errors(data)), None)
    if error:
        path = '.'.join(map(str, error.absolute_path)) or 'recipe'
        raise ValueError(f'{path}: {error.message}')
    hands = data.get('hands', [])
    if len({h['name'] for h in hands}) != len(hands):
        raise ValueError('Hand names must be unique.')
    if len(data['parts']) + 4 * len(hands) > 256:
        raise ValueError('The 256-part budget includes four generated parts per hand.')
    if hands:
        from agent.hands import anchor, frame, spec
        parts = {p['name']: p for p in data['parts']}
        generated = set(parts)
        for h in hands:
            spec(h)
            for key in ('mat', 'joint_mat', 'armor_mat'):
                if h[key] not in data['materials']:
                    raise ValueError(f"Unknown hand material: {h[key]}")
            for role in ('palm', 'digits', 'armor', 'joints'):
                name = h['name'] + '_' + role
                if name in generated:
                    raise ValueError(f'Generated hand part name collision: {name}')
                generated.add(name)
            for key in ('wrist', 'elbow'):
                ref = h[key]
                if isinstance(ref, dict) and ref['part'] in parts:
                    if parts[ref['part']].get('min_lod', 0) > min(data.get('lods', [1])):
                        raise ValueError('Hand anchors must remain present at every LOD.')
            frame(anchor(h['elbow'], parts=parts), anchor(h['wrist'], parts=parts), h['palm'], h.get('direction'))
    names = [p['name'] for p in data['parts']]
    if len(set(names)) != len(names):
        raise ValueError('Part names must be unique.')
    if data.get('lods', [1])[0] != 1:
        raise ValueError('The first LOD must be 1.0.')
    lods = data.get('lods', [1])
    if any((a <= b for a, b in zip(lods, lods[1:]))):
        raise ValueError('LODs must strictly decrease.')
    allowed = {
        'box': {'size', 'bevel'},
        'cylinder': {'radius', 'length', 'inner', 'top', 'steps', 'error', 'rings'},
        'sphere': {'radius', 'steps', 'rings', 'error'},
        'ellipsoid': {'size', 'steps', 'rings', 'error'},
        'torus': {'radius', 'tube', 'steps', 'rings', 'error'},
        'bowl': {'size', 'depth', 'steps', 'rings', 'power', 'taper', 'lean'},
        'lathe': {'profile', 'steps'},
        'hose': {'points', 'radius', 'steps', 'samples'},
        'plate': {'points', 'depth'},
        'mesh': {'v', 'f', 'uvs'},
        'prism': {'points', 'depth', 'bevel', 'taper'}
    }
    common = {
        'name',
        'shape',
        'mat',
        'pos',
        'rot',
        'scale',
        'uv',
        'uv_size',
        'tile',
        'min_lod',
        'decals',
        'stamps',
        'stamp_limit',
        'sculpt',
        'sculpt_limit'
    }
    for cfg in data.get('stamps', {}).values():
        check_stamp(cfg)
    for p in data['parts']:
        if p.get('sculpt'):
            from agent.sculpt import validate as validate_stroke
            for stroke in p['sculpt']:
                validate_stroke(stroke)
        if p['mat'] not in data['materials']:
            raise ValueError(f"Unknown material: {p['mat']}")
        extras = set(p) - common - allowed[p['shape']]
        if extras:
            raise ValueError(f"{p['name']}: {sorted(extras)} do not apply to {p['shape']}.")
        if 'error' in p and 'steps' in p:
            raise ValueError('Choose either explicit steps or radial chord error, not both.')
        if data['materials'][p['mat']].get('edge_wear', 0) and p.get('uv') not in {'atlas', 'box', 'cylinder'}:
            raise ValueError('edge_wear requires explicit unique atlas, box or cylinder UVs.')
        if p.get('decals'):
            if p['shape'] in {'hose', 'plate', 'prism', 'mesh'} and p.get('uv') != 'atlas':
                raise ValueError('Projected decals require a supported primitive with unique UVs; use material layers for custom meshes.')
            if p.get('tile', [1, 1]) != [1, 1]:
                raise ValueError('Projected decals cannot use tiled UVs.')
            if p['shape'] == 'box' and p.get('uv') not in {'box', 'atlas'}:
                raise ValueError('A box with projected decals requires uv=box or uv=atlas.')
            m = data['materials'][p['mat']]
            if 'normal' in m and any(('height' in d for d in p['decals'])):
                raise ValueError('Projected height edits cannot override a supplied normal map.')
            for d in p['decals']:
                check_layer(d)
        if p.get('stamps'):
            if p['shape'] in {'hose', 'plate', 'mesh'}:
                raise ValueError('Recipe stamps require a supported primitive with unique UVs. This recipe operation does not support custom meshes.')
            if p.get('tile', [1, 1]) != [1, 1]:
                raise ValueError('Geometry stamps need unique UVs, not tiled UVs.')
            if p['shape'] == 'box' and p.get('uv') != 'box':
                raise ValueError('A stamped box requires uv=box.')
            if p['shape'] == 'cylinder' and p.get('uv') != 'cylinder':
                raise ValueError('A stamped cylinder requires uv=cylinder to avoid cap UV overlap.')
            if any(('height' in d for d in p.get('decals', []))):
                raise ValueError('On stamped parts, put geometric or bump height in stamps rather than decal.height.')
            for use in p['stamps']:
                if use['stamp'] not in data.get('stamps', {}):
                    raise ValueError('Unknown stamp: ' + use['stamp'])
                x, y, w, h = use.get('rect', [0.1, 0.1, 0.8, 0.8])
                if min(w, h) <= 0 or x + w > 1.000001 or y + h > 1.000001:
                    raise ValueError('Stamp rect must have positive size and fit inside [0,1].')
        if p.get('uv') == 'atlas' and p.get('tile', [1, 1]) != [1, 1]:
            raise ValueError('Do not tile a unique atlas.')
        if 'uv_size' in p and p.get('uv') != 'metric':
            raise ValueError('uv_size requires uv=metric.')
        if p.get('uv') == 'cylinder' and p['shape'] != 'cylinder':
            raise ValueError('Cylinder UV mapping requires a cylinder.')
        if p.get('uv') == 'cylinder' and p.get('tile', [1, 1]) != [1, 1]:
            raise ValueError('Do not repeat a cylinder atlas.')
        if p.get('uv') == 'box' and p['shape'] != 'box':
            raise ValueError('Box UV mapping is only supported on box parts.')
        if p.get('uv') == 'box' and p.get('tile', [1, 1]) != [1, 1]:
            raise ValueError('Do not repeat an atlas. Use tile=[1,1] with box UVs.')
        required = {
            'lathe': ['profile'],
            'hose': ['points'],
            'plate': ['points'],
            'prism': ['points'],
            'mesh': ['v', 'f']
        }.get(p['shape'], [])
        for key in required:
            if key not in p:
                raise ValueError(f"{p['name']}: {key} is required.")
        if p['shape'] in {'hose', 'plate', 'prism'}:
            n = 3 if p['shape'] == 'hose' else 2
            if any((len(v) != n for v in p['points'])):
                raise ValueError(f"{p['name']}: points need {n} coordinates.")
        if p['shape'] == 'lathe' and any((v[0] < 0 for v in p['profile'])):
            raise ValueError('Lathe radii cannot be negative.')
    if not any((p.get('min_lod', 0) <= lods[-1] for p in data['parts'])):
        raise ValueError('At least one part must remain at the lowest LOD.')
    for m in data['materials'].values():
        if 'orm' in m and any((k in m for k in ['rough_map', 'metal_map', 'ao_map'])):
            raise ValueError('Choose packed ORM or separate scalar maps, not both.')
        if m.get('normal_y') == 'directx' and ('normal' not in m or any((p.get('stamps') for p in data['parts'] if data['materials'][p['mat']] is m))):
            raise ValueError('DirectX normal conversion requires a supplied normal map without stamps.')
        if m['kind'] == 'image' and 'image' not in m:
            raise ValueError('Image materials require an image path.')
        if 'normal' in m and ('height' in m or any(('height' in l for l in m.get('layers', [])))):
            raise ValueError('A supplied normal map cannot be combined with height edits in this version.')
        for l in m.get('layers', []):
            check_layer(l)
    return data


def check_stamp(cfg):
    from jsonschema import Draft202012Validator
    finite(cfg)
    error = next(iter(Draft202012Validator(STAMP).iter_errors(cfg)), None)
    if error:
        raise ValueError('Stamp definition: ' + error.message)
    if 'asset' in cfg:
        if set(cfg) != {'asset'}:
            raise ValueError('An asset reference must contain only asset; edit the saved definition for overrides.')
        return cfg
    if 'kind' not in cfg:
        raise ValueError('A stamp needs kind or asset.')
    if cfg['kind'] == 'height' and 'height' not in cfg:
        raise ValueError('Height stamps require an explicit height map.')
    if cfg['kind'] != 'height' and any((k in cfg for k in ('height', 'zero', 'range'))):
        raise ValueError('height, zero and range apply only to height-map stamps.')
    return cfg


def check_layer(l):
    if l['kind'] == 'polygon' and 'points' not in l:
        raise ValueError('Polygon layers require normalized points.')
    if l['kind'] == 'image' and 'image' not in l:
        raise ValueError('Image layers require an image path.')
    if l['kind'] == 'text' and (not l.get('text')):
        raise ValueError('Text layers require nonempty text.')
    for key in ['rect', 'crop']:
        u, v, w, h = l.get(key, [0, 0, 1, 1])
        if min(w, h) <= 0 or u + w > 1.000001 or v + h > 1.000001:
            raise ValueError('Layer rectangles must have positive size and fit inside [0,1].')
    if 'tint' in l and l['kind'] != 'image':
        raise ValueError('tint applies only to image layers.')
    if 'points' in l and l['kind'] != 'polygon':
        raise ValueError('points applies only to polygon layers.')
    if 'crop' in l and l['kind'] != 'image':
        raise ValueError('Image cropping only applies to image layers.')


def load(path):
    """Read an 8 MiB-bounded recipe and apply structural and semantic checks."""
    from agent.state import read
    return validate(read(path, limit=8 * 1048576))
