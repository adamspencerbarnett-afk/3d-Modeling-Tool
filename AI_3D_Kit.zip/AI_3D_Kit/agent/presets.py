"""Return editable material defaults and bounded recipe-quality settings."""

from __future__ import annotations
import copy
MATS = {
    'armor': {
        'kind': 'steel',
        'color': [0.24, 0.245, 0.25],
        'color_space': 'srgb',
        'rough': 0.68,
        'metal': 0.78,
        'wear': 0.55,
        'bump': 0.00045,
        'normal_strength': 0.6,
        'edge_wear': 0.78,
        'edge_width': 0.012,
        'tex_size': 512,
        'layers': [
            {'kind': 'scratches', 'color': [0.54, 0.51, 0.46], 'opacity': 0.33, 'count': 40},
            {'kind': 'stain', 'color': [0.12, 0.085, 0.05], 'opacity': 0.3, 'rough': 0.92, 'metal': 0.1}
        ]
    },
    'steel': {
        'kind': 'steel',
        'color': [0.43, 0.45, 0.48],
        'color_space': 'srgb',
        'rough': 0.38,
        'metal': 0.96,
        'wear': 0.1,
        'bump': 0.00015,
        'normal_strength': 0.45,
        'tex_size': 512
    },
    'rubber': {
        'kind': 'solid',
        'color': [0.065, 0.07, 0.075],
        'color_space': 'srgb',
        'rough': 0.9,
        'metal': 0
    },
    'hazard': {
        'kind': 'paint',
        'color': [0.65, 0.39, 0.09],
        'color_space': 'srgb',
        'rough': 0.76,
        'metal': 0.05,
        'wear': 0.5,
        'bump': 0.00025,
        'tex_size': 256,
        'layers': [
            {'kind': 'stripe', 'color': [0.055, 0.058, 0.06], 'count': 5, 'opacity': 0.95},
            {'kind': 'scratches', 'color': [0.46, 0.44, 0.38], 'opacity': 0.6, 'count': 40}
        ]
    },
    'red_core': {
        'kind': 'solid',
        'color': [0.38, 0.008, 0.005],
        'color_space': 'srgb',
        'rough': 0.3,
        'metal': 0,
        'emission': [1, 0.002, 0.001]
    },
    'wood': {
        'kind': 'wood',
        'color': [0.43, 0.26, 0.12],
        'color_space': 'srgb',
        'rough': 0.75,
        'bump': 0.0008,
        'tex_size': 512
    }
}


def material(name):
    if name not in MATS:
        raise ValueError('Unknown material preset: ' + name)
    return copy.deepcopy(MATS[name])


def quality(data, level):
    if level is None:
        return data
    if level not in {'draft', 'standard', 'high'}:
        raise ValueError('Unknown quality profile.')
    result = copy.deepcopy(data)
    size, tris = {'draft': (256, 10000), 'standard': (512, 50000), 'high': (1024, 100000)}[level]
    result.setdefault('texture_size', size)
    result.setdefault('max_triangles', tris)
    return result
