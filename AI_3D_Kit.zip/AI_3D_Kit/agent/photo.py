"""Prepare supplied image swatches with explicit crop and source provenance.

Cropping and rectification do not remove lighting or confer image rights."""

from __future__ import annotations
import shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps
from scipy.ndimage import gaussian_filter
from agent.mats import linear, srgb
from agent.state import output_path, write
from core.hash import digest


def rectify(im, corners):
    """Resample a quadrilateral in the supplied image into a rectangular patch."""
    if corners is None:
        return im
    p = np.asarray(corners, float)
    if p.shape != (4, 2) or not np.isfinite(p).all() or p.min() < 0 or (p.max() > 1):
        raise ValueError('corners need four normalized XY pairs in TL, TR, BR, BL order.')
    e = np.roll(p, -1, axis=0) - p
    cross = e[:, 0] * np.roll(e[:, 1], -1) - e[:, 1] * np.roll(e[:, 0], -1)
    if not np.all(cross > 1e-05):
        raise ValueError('corners must form a noncrossing clockwise quadrilateral.')
    p *= im.size
    w = max(8, round((np.linalg.norm(p[1] - p[0]) + np.linalg.norm(p[2] - p[3])) / 2))
    h = max(8, round((np.linalg.norm(p[3] - p[0]) + np.linalg.norm(p[2] - p[1])) / 2))
    mat, rhs = ([], [])
    for (x, y), (u, v) in zip([(0, 0), (w, 0), (w, h), (0, h)], p):
        mat.extend([[x, y, 1, 0, 0, 0, -u * x, -u * y], [0, 0, 0, x, y, 1, -v * x, -v * y]])
        rhs.extend([u, v])
    return im.transform(
        (w, h),
        Image.Transform.PERSPECTIVE,
        np.linalg.solve(mat, rhs),
        Image.Resampling.BICUBIC
    )


def swatch(src, out, crop=None, corners=None, size=512, delight=0.0, tile=False):
    """Save a prepared patch and record the original input hash and operations."""
    src = Path(src).resolve()
    out = output_path(out)
    if size not in [64, 128, 256, 512, 1024, 2048] or not np.isfinite(delight) or (not 0 <= delight <= 1):
        raise ValueError('Choose a power-of-two size from 64 to 2048 and delight from 0 to 1.')
    if crop is not None and corners is not None:
        raise ValueError('Choose a rectangle or perspective corners, not both.')
    with Image.open(src) as raw:
        if raw.width * raw.height > 40000000:
            raise ValueError('Source exceeds 40 million pixels.')
        im = ImageOps.exif_transpose(raw).convert('RGB')
        original = im.size
        if crop is not None:
            x, y, w, h = map(float, crop)
            if not np.isfinite([x, y, w, h]).all() or min(x, y) < 0 or min(w, h) <= 0 or (x + w > 1) or (y + h > 1):
                raise ValueError('crop must be normalized x, y, width, height within the source.')
            im = im.crop((
                round(x * im.width),
                round(y * im.height),
                round((x + w) * im.width),
                round((y + h) * im.height)
            ))
        im = rectify(im, corners)
        if min(im.size) < 4:
            raise ValueError('Selected patch must be at least four source pixels per side.')
        selected = im.size
        im = ImageOps.fit(im, (size, size), Image.Resampling.LANCZOS)
    a = np.asarray(im, np.float32) / 255
    notes = []
    if delight:
        lin = linear(a)
        light = gaussian_filter(lin @ np.array([0.2126, 0.7152, 0.0722]), size / 18)
        gain = np.clip(np.median(light) / np.maximum(light, 0.015), 0.35, 3) ** delight
        a = srgb(np.clip(lin * gain[..., None], 0, 1))
        notes.append('Lighting normalization is a low-frequency heuristic and may change genuine color.')
    if tile:
        x = np.linspace(0, 1, size)[None, :, None]
        a -= (a[:, -1:, :] - a[:, :1, :]) * (x - 0.5)
        y = np.linspace(0, 1, size)[:, None, None]
        a -= (a[-1:, :, :] - a[:1, :, :]) * (y - 0.5)
        notes.append('Edge-matched color tile; not semantic texture synthesis. Repeated motifs can remain.')
    if size > min(selected):
        notes.append('Source crop is upsampled; this does not recover missing image detail.')
    out.mkdir(parents=True)
    Image.fromarray(np.rint(a.clip(0, 1) * 255).astype(np.uint8)).save(out / 'color.png')
    shutil.copyfile(src, out / ('source' + src.suffix.lower()))
    cfg = {
        'kind': 'image',
        'image': 'color.png',
        'source': 'provided',
        'rough': 0.75,
        'metal': 0,
        'color_space': 'srgb',
        'tex_size': size
    }
    write(out / 'material.json', cfg)
    report = {
        'ok': True,
        'source_sha256': digest(src),
        'original_size': original,
        'selected_size': selected,
        'size': size,
        'crop': crop,
        'corners': corners,
        'delight': delight,
        'tile': tile,
        'notes': notes,
        'scope': 'Color preparation only. Roughness/metalness are editable assumptions; no physical depth or material recovery.'
    }
    write(out / 'source.json', report)
    return {**report, 'folder': str(out)}
