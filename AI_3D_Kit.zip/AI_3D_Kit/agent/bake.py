"""Rasterize authored UV charts to bake surface fields and projected decals."""

from __future__ import annotations
import math
import time
import numpy as np
from core.mesh import unit
FACES = {
    'front': (2, 1, 0, 1, 1, -1),
    'back': (2, -1, 0, -1, 1, -1),
    'right': (0, 1, 2, -1, 1, -1),
    'left': (0, -1, 2, 1, 1, -1),
    'top': (1, 1, 0, 1, 2, 1),
    'bottom': (1, -1, 0, 1, 2, -1)
}


def _raster(uv, f, size):
    ids = np.full((size, size), -1, np.int32)
    weights = np.zeros((size, size, 2), np.float64)
    for i, face in enumerate(f):
        tri = uv[face] * size
        x0, y0 = np.maximum(np.floor(tri.min(0)).astype(int), 0)
        x1, y1 = np.minimum(np.ceil(tri.max(0)).astype(int), size - 1)
        if x0 > x1 or y0 > y1:
            continue
        den = (tri[1, 1] - tri[2, 1]) * (tri[0, 0] - tri[2, 0]) + (tri[2, 0] - tri[1, 0]) * (tri[0, 1] - tri[2, 1])
        if abs(den) < 1e-12:
            continue
        yy, xx = np.mgrid[y0:y1 + 1, x0:x1 + 1]
        px, py = (xx + 0.5, yy + 0.5)
        a = ((tri[1, 1] - tri[2, 1]) * (px - tri[2, 0]) + (tri[2, 0] - tri[1, 0]) * (py - tri[2, 1])) / den
        b = ((tri[2, 1] - tri[0, 1]) * (px - tri[2, 0]) + (tri[0, 0] - tri[2, 0]) * (py - tri[2, 1])) / den
        use = (a >= -1e-09) & (b >= -1e-09) & (a + b <= 1 + 1e-09)
        y, x = (yy[use], xx[use])
        ids[y, x] = i
        weights[y, x, 0] = a[use]
        weights[y, x, 1] = b[use]
    return (ids, weights)


def raster(mesh, size):
    """Validate a UV atlas and return triangle IDs with barycentric weights."""
    if not 16 <= size <= 2048:
        raise ValueError('Surface buffer resolution must be 16 to 2048.')
    if mesh.uv.min() < -1e-06 or mesh.uv.max() > 1.000001:
        raise ValueError('Projected decals need unique UVs within [0,1], not tiled UVs.')
    return _raster(mesh.uv, mesh.f, size)


def surface(mesh, size):
    """Interpolate positions and normals only at occupied atlas texels."""
    ids, w = raster(mesh, size)
    ys, xs = np.where(ids >= 0)
    weights = np.column_stack([w[ys, xs], 1 - w[ys, xs].sum(1)])
    faces = mesh.f[ids[ys, xs]]
    pos = np.einsum('ij,ijk->ik', weights, mesh.v[faces])
    ns = unit(np.einsum('ij,ijk->ik', weights, mesh.n[faces]))
    return (ys, xs, pos, ns)


def bilinear(a, u, v):
    x, y = (
        np.clip(u * a.shape[1] - 0.5, 0, a.shape[1] - 1),
        np.clip(v * a.shape[0] - 0.5, 0, a.shape[0] - 1)
    )
    x0, y0 = (np.floor(x).astype(int), np.floor(y).astype(int))
    x1, y1 = (np.minimum(x0 + 1, a.shape[1] - 1), np.minimum(y0 + 1, a.shape[0] - 1))
    fx, fy = ((x - x0)[:, None], (y - y0)[:, None])
    return (a[y0, x0] * (1 - fx) + a[y0, x1] * fx) * (1 - fy) + (a[y1, x0] * (1 - fx) + a[y1, x1] * fx) * fy


def project(mesh, decals, base, height, rough, metal, root, seed):
    """Project a decal into a selected surface frame and reject back-facing hits."""
    from agent.mats import layer
    start = time.perf_counter()
    ys, xs, pos, ns = surface(mesh, len(base))
    buffer_s = time.perf_counter() - start
    lo, span = (mesh.v.min(0), np.maximum(np.ptp(mesh.v, axis=0), 1e-09))
    q = (pos - lo) / span
    rows = []
    for i, spec in enumerate(decals):
        ax, sign, ux, us, vx, vs = FACES[spec['side']]
        u = q[:, ux] if us > 0 else 1 - q[:, ux]
        v = q[:, vx] if vs > 0 else 1 - q[:, vx]
        depth = 1 - q[:, ax] if sign > 0 else q[:, ax]
        x, y, w, h = spec.get('rect', [0.1, 0.1, 0.8, 0.8])
        u, v = ((u - x) / w, (v - y) / h)
        angle = np.deg2rad(spec.get('turn', 0))
        dx, dy = (u - 0.5, v - 0.5)
        u, v = (0.5 + np.cos(angle) * dx + np.sin(angle) * dy, 0.5 - np.sin(angle) * dx + np.cos(angle) * dy)
        dot = sign * ns[:, ax]
        cutoff = math.cos(math.radians(spec.get('angle', 75)))
        use = (u >= 0) & (u <= 1) & (v >= 0) & (v <= 1) & (dot > cutoff) & (depth <= spec.get('reach', 0.5))
        iy, ix = (ys[use], xs[use])
        ratio = span[ux] * w / max(span[vx] * h, 1e-09)
        sw, sh = (1024, max(8, round(1024 / ratio))) if ratio >= 1 else (max(8, round(1024 * ratio)), 1024)
        rgba = np.asarray(
            layer({**spec, 'fit': spec.get('fit', 'contain')}, sw, sh, seed + i * 1009, root),
            np.float64
        ) / 255
        rgba[:, :, :3] *= rgba[:, :, 3:4]
        c = bilinear(rgba, u[use], v[use])
        fade = np.clip((dot[use] - cutoff) / 0.12, 0, 1) * spec.get('opacity', 1)
        c *= fade[:, None]
        a = c[:, 3]
        base[iy, ix] = base[iy, ix] * (1 - a[:, None]) + c[:, :3]
        if 'height' in spec:
            height[iy, ix] += a * spec['height']
        if 'rough' in spec:
            rough[iy, ix] = rough[iy, ix] * (1 - a) + spec['rough'] * a
        if 'metal' in spec:
            metal[iy, ix] = metal[iy, ix] * (1 - a) + spec['metal'] * a
        pixels = int(np.count_nonzero(a > 1 / 255))
        rows.append({
            'side': spec['side'],
            'kind': spec['kind'],
            'pixels': pixels,
            'warning': 'No visible texels affected; inspect rect, angle, reach and image alpha.' if not pixels else None
        })
    return {
        'buffer_seconds': round(buffer_s, 6),
        'total_seconds': round(time.perf_counter() - start, 6),
        'decals': rows,
        'scope': 'Object-local orthographic projection with normal/depth clipping; no concave visibility ray tracing. No added triangles.'
    }
