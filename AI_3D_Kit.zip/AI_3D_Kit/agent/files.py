"""Read supported static assets and reject unsafe archive and model features.

External file references stay beneath the source folder; remote loading is off."""

from __future__ import annotations
import copy
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
import numpy as np
from agent.state import output_path, safe
from core.mesh import GLB, matrix
LIMIT = 128 * 1048576


def unpack(path, out):
    """Extract supported assets through a checked temporary folder before commit."""
    out = output_path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.unpack-', dir=out.parent))
    try:
        total, names, rows = (0, set(), [])
        with zipfile.ZipFile(path) as z:
            if len(z.infolist()) > 1024:
                raise ValueError('Asset ZIP contains too many entries; maximum 1024.')
            for info in z.infolist():
                name = info.filename
                parts = PurePosixPath(name)
                kind = stat.S_IFMT(info.external_attr >> 16)
                if '\\' in name or ':' in name or name.startswith('/') or ('..' in parts.parts) or (kind not in {
                    0,
                    stat.S_IFREG,
                    stat.S_IFDIR
                }):
                    raise ValueError(f'Unsafe archive entry: {name}')
                # Case-folding also prevents Windows/macOS alias collisions.
                key = str(parts).casefold()
                if key in names or not parts.parts:
                    raise ValueError(f'Duplicate or empty archive entry: {name}')
                names.add(key)
                if info.is_dir() or '__MACOSX' in parts.parts or parts.name in {
                    '.DS_Store',
                    'Thumbs.db'
                } or parts.name.startswith('._'):
                    continue
                if info.flag_bits & 1:
                    raise ValueError('Encrypted asset ZIPs are not supported.')
                total += info.file_size
                if info.file_size > LIMIT or total > 256 * 1048576:
                    raise ValueError('Asset ZIP exceeds the 128 MiB/file or 256 MiB total limit.')
                if info.file_size > max(1048576, info.compress_size * 1000):
                    raise ValueError('Suspicious archive compression ratio.')
                if parts.suffix.lower() not in {
                    '.glb',
                    '.obj',
                    '.stl',
                    '.ply',
                    '.mtl',
                    '.png',
                    '.jpg',
                    '.jpeg',
                    '.webp',
                    '.tif',
                    '.tiff',
                    '.bmp',
                    '.json',
                    '.txt',
                    '.md'
                }:
                    raise ValueError(f'Unsupported asset type in ZIP: {name}')
                dst = stage.joinpath(*parts.parts)
                dst.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, dst.open('xb') as f:
                    shutil.copyfileobj(src, f)
                rows.append({'file': str(parts), 'bytes': info.file_size})
        if not rows:
            raise ValueError('Asset ZIP contains no usable files.')
        if out.exists():
            raise FileExistsError('Output was created by another process.')
        stage.rename(out)
        return {'ok': True, 'folder': str(out), 'files': rows}
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def guarded(g):
    """Reject unsupported semantics instead of silently dropping model features."""
    for item in g.j.get('meshes', []):
        for prim in item['primitives']:
            if any((key not in {
                'POSITION',
                'NORMAL',
                'TANGENT',
                'TEXCOORD_0',
                'COLOR_0'
            } for key in prim['attributes'])):
                raise ValueError('Only POSITION, NORMAL, TANGENT, TEXCOORD_0 and COLOR_0 are supported. Export a static GLB with one UV set.')

    def visit(obj):
        if isinstance(obj, dict):
            if obj.get('extensions') or obj.get('texCoord', 0) != 0:
                raise ValueError('GLB extensions and additional UV sets are not supported. Export static core metallic-roughness materials with UV set 0.')
            for value in obj.values():
                visit(value)
        elif isinstance(obj, list):
            for value in obj:
                visit(value)
    visit(g.j)
    return g


def load(path):
    """Import a supported static model without network-based asset resolution."""
    path = Path(path).resolve()
    if not path.is_file() or path.stat().st_size > LIMIT:
        raise ValueError('Model must be an existing file no larger than 128 MiB.')
    if path.suffix.lower() == '.glb':
        return (guarded(GLB.load(path)), [])
    if path.suffix.lower() not in {'.obj', '.stl', '.ply'}:
        raise ValueError('Use GLB, OBJ, STL or PLY. Put OBJ, MTL and textures together in an asset ZIP.')
    try:
        import trimesh
        from trimesh.resolvers import Resolver
    except ImportError as exc:
        raise ValueError('OBJ/STL/PLY import needs the optional requirements-import.txt packages. GLB does not.') from exc
    issues = []

    # Resolver methods are called dynamically by trimesh, including namespaced().
    class Local(Resolver):

        def __init__(self, root, base=None):
            self.root = Path(root).resolve()
            self.base = Path(base or root).resolve()

        def get(self, key):
            try:
                rel = (self.base.relative_to(self.root) / str(key)).as_posix()
                return safe(self.root, rel).read_bytes()
            except (ValueError, OSError) as exc:
                issues.append(f'Unloaded material asset {key!r}: {exc}')
                raise

        def keys(self):
            return []

        def write(self, name, data):
            raise ValueError('Model asset resolver is read-only.')

        def namespaced(self, namespace):
            name = str(namespace)
            base = (self.base / name).resolve()
            if '\\' in name or ':' in name or '..' in Path(name).parts or (not base.is_relative_to(self.root)):
                raise ValueError('Material namespace escapes the model folder.')
            return Local(self.root, base)
    with path.open('rb') as f:
        scene = trimesh.load_scene(
            f,
            file_type=path.suffix[1:].lower(),
            resolver=Local(path.parent),
            allow_remote=False,
            process=False
        )
    if not scene.geometry or any((not isinstance(m, trimesh.Trimesh) for m in scene.geometry.values())):
        raise ValueError('Input must contain triangle surfaces, not curves or a point cloud.')
    count = sum((len(m.faces) for m in scene.geometry.values()))
    if count > 500000:
        raise ValueError('Input exceeds 500,000 stored triangles. Simplify it before importing.')
    if any((not len(m.faces) or not np.isfinite(m.vertices).all() for m in scene.geometry.values())):
        raise ValueError('Model contains empty or non-finite geometry.')
    for mesh in scene.geometry.values():
        n = mesh.vertex_normals
        if not np.isfinite(n).all() or np.any(np.linalg.norm(n, axis=1) < 0.99):
            raise ValueError('Unable to derive valid normals from the imported geometry.')
    with tempfile.TemporaryDirectory(prefix='ai3d-import-') as tmp:
        dst = Path(tmp) / 'model.glb'
        dst.write_bytes(scene.export(file_type='glb'))
        g = guarded(GLB.load(dst))
    return (
        g,
        list(dict.fromkeys(issues)) + ['Imported units and up-axis are not inferred. Numeric units are treated as meters and +Y as up unless explicitly changed.']
    )


def wrap(g, pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1), name='transform'):
    m = matrix(pos, rot, scale)
    scene = g.j['scenes'][g.j.get('scene', 0)]
    index = len(g.j['nodes'])
    g.j['nodes'].append({
        'name': name,
        'matrix': m.flatten(order='F').tolist(),
        'children': list(scene.get('nodes', []))
    })
    scene['nodes'] = [index]


def join(dst, src, name, pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
    """Append a transformed GLB and remap all buffer, material, and node indices."""
    src = copy.deepcopy(src)
    if src.j.get('extensionsUsed') or src.j.get('extensionsRequired') or src.j.get('cameras'):
        raise ValueError('Assembly accepts static core-GLB meshes without extensions or cameras.')
    keys = ['bufferViews', 'accessors', 'samplers', 'images', 'textures', 'materials', 'meshes', 'nodes']
    offsets = {key: len(dst.j.setdefault(key, [])) for key in keys}
    dst.b.extend(b'\x00' * (-len(dst.b) % 4))
    shift = len(dst.b)
    dst.b.extend(src.b)
    for view in src.j.get('bufferViews', []):
        view['byteOffset'] = view.get('byteOffset', 0) + shift
    for acc in src.j.get('accessors', []):
        acc['bufferView'] += offsets['bufferViews']
    for image in src.j.get('images', []):
        image['bufferView'] += offsets['bufferViews']
    for tex in src.j.get('textures', []):
        tex['source'] += offsets['images']
        if 'sampler' in tex:
            tex['sampler'] += offsets['samplers']

    def refs(obj):
        if not isinstance(obj, dict):
            return
        for key, value in obj.items():
            if key.endswith('Texture') and isinstance(value, dict) and ('index' in value):
                value['index'] += offsets['textures']
            elif isinstance(value, dict):
                refs(value)
    for mat in src.j.get('materials', []):
        refs(mat)
    for mesh in src.j.get('meshes', []):
        for prim in mesh['primitives']:
            prim['attributes'] = {k: v + offsets['accessors'] for k, v in prim['attributes'].items()}
            if 'indices' in prim:
                prim['indices'] += offsets['accessors']
            if 'material' in prim:
                prim['material'] += offsets['materials']
    for node in src.j['nodes']:
        node['name'] = name + '/' + node.get('name', 'node')
        if 'mesh' in node:
            node['mesh'] += offsets['meshes']
        if 'children' in node:
            node['children'] = [v + offsets['nodes'] for v in node['children']]
    for key in keys:
        dst.j[key].extend(src.j.get(key, []))
    roots = src.j['scenes'][src.j.get('scene', 0)].get('nodes', [])
    index = len(dst.j['nodes'])
    mat = matrix(pos, rot, scale)
    dst.j['nodes'].append({
        'name': name,
        'matrix': mat.flatten(order='F').tolist(),
        'children': [i + offsets['nodes'] for i in roots]
    })
    dst.j['scenes'][dst.j.get('scene', 0)].setdefault('nodes', []).append(index)
