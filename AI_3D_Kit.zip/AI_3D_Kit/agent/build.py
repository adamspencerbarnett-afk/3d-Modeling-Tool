"""Validate recipes, compile GLBs, and stage reproducible project outputs.

A completed folder is a snapshot: edits belong in a new output folder."""

from __future__ import annotations
import copy
import hashlib
import importlib.metadata
import platform
import json
from pathlib import Path
import shutil
import tempfile
import time
from agent import VERSION
from agent.geom import shape, tangents
from agent.mats import color, make, plain
from agent.schema import validate
from agent.state import source, safe, write
from core.hash import digest
from core.mesh import GLB, matrix
from core.optimize import optimize
from core.validate import check


def owners(data):
    for m in data['materials'].values():
        yield m
        yield from m.get('layers', [])
    for part in data['parts']:
        yield from part.get('decals', [])


def assets(data, root):
    """Resolve declared inputs and fingerprint the actual files used by a recipe."""
    from agent.stamps import inputs
    result = inputs(data, root)
    for owner in owners(data):
        for key in [
            'image',
            'normal',
            'height',
            'orm',
            'mask',
            'rough_map',
            'metal_map',
            'ao_map',
            'emissive'
        ]:
            if key in owner and isinstance(owner[key], str):
                p = safe(root, owner[key])
                result[owner[key]] = digest(p)
    return result


def relocate(data, root, out):
    result = copy.deepcopy(data)
    from agent.stamps import resolve
    if data.get('stamps'):
        result['stamps'] = {k: resolve(v, root) for k, v in data['stamps'].items()}
    for owner in list(owners(result)) + list(result.get('stamps', {}).values()):
        for key in [
            'image',
            'normal',
            'height',
            'orm',
            'mask',
            'rough_map',
            'metal_map',
            'ao_map',
            'emissive'
        ]:
            if key in owner and isinstance(owner[key], str):
                p = safe(root, owner[key])
                name = 'assets/' + digest(p) + p.suffix.lower()
                dest = out / name
                dest.parent.mkdir(exist_ok=True)
                if not dest.is_file():
                    shutil.copyfile(p, dest)
                owner[key] = name
    return result


def geometry(data, root=None, prepared=None, contexts=None):
    from agent.stamps import library, apply
    root = Path(root or '.')
    lib = prepared if prepared is not None else library(data, root)
    cache, levels, hits = ({}, [], 0)
    stamp_rows, sculpt_rows = ([], [])
    for li, lod in enumerate(data.get('lods', [1])):
        total, pairs = (0, [])
        for part in data['parts']:
            if part.get('min_lod', 0) > lod:
                continue
            cfg = {
                k: v for k,
                v in part.items() if k not in {
                    'name',
                    'mat',
                    'pos',
                    'rot',
                    'decals',
                    'stamps',
                    'stamp_limit',
                    'min_lod',
                    'scale',
                    'sculpt',
                    'sculpt_limit'
                }
            }
            if part.get('stamps') and cfg['shape'] == 'cylinder' and ('rings' not in cfg) and any((u['mode'] != 'bump' and lod >= u.get('geo_min', 0) for u in part['stamps'])):
                import math
                count = cfg.get('steps', 32)
                r = max(cfg.get('radius', 0.1), cfg.get('top', 0))
                cfg['rings'] = max(4, min(32, round(cfg.get('length', 0.3) * count / (4 * math.pi * r))))
            if 'error' in part and 'scale' in part:
                cfg['scale'] = part['scale']
            key = json.dumps([cfg, lod], sort_keys=True)
            if key not in cache:
                try:
                    cache[key] = shape(cfg, lod)
                except Exception as exc:
                    raise ValueError(f"{part['name']}: {exc}") from exc
            else:
                hits += 1
            mesh = cache[key]
            placed = part
            if part.get('stamps') or part.get('sculpt'):
                if 'scale' in part:
                    mesh = mesh.transformed(matrix(scale=part['scale']))
                    placed = {**part, 'scale': [1, 1, 1]}
            if part.get('sculpt'):
                from agent.sculpt import apply as sculpt
                mesh, edit = sculpt(
                    mesh,
                    part['sculpt'],
                    min(part.get('sculpt_limit', 50000), data.get('max_triangles', 10000)),
                    lod
                )
                sculpt_rows.append({'part': part['name'], 'lod': lod, **edit.stats})
            if part.get('stamps'):
                wall = None
                if part['shape'] == 'bowl':
                    wall = part.get('depth', 0.012) * min(part.get('scale', [1, 1, 1]))
                elif part['shape'] == 'cylinder' and part.get('inner', 0) > 0:
                    wall = (min(
                        part.get('radius', 0.1),
                        part.get('top', part.get('radius', 0.1))
                    ) - part['inner']) * min(part.get('scale', [1, 1, 1]))
                mesh, ctx = apply(
                    mesh,
                    part['stamps'],
                    lib,
                    lod,
                    min(part.get('stamp_limit', 30000), data.get('max_triangles', 10000)),
                    wall=wall
                )
                stamp_rows.append({'part': part['name'], 'lod': lod, **ctx.stats})
                if contexts is not None:
                    contexts[li, part['name']] = ctx
            total += len(mesh.f)
            if total > data.get('max_triangles', 10000):
                raise ValueError(f"Triangle budget exceeded at LOD {lod}: {total} > {data.get('max_triangles', 10000)}. Reduce segments or stamp res; no silent decimation was applied.")
            pairs.append((placed, mesh))
        levels.append(pairs)
    return (
        levels,
        {
            'unique_generations': len(cache),
            'reused_generations': hits,
            'stamp_geometry': stamp_rows,
            'prepared_stamps': len(lib),
            'sculpt_geometry': sculpt_rows
        }
    )


def signature(meshes):
    h = hashlib.sha256()
    for p, m in meshes:
        h.update(json.dumps(p, sort_keys=True).encode())
        for a in [m.v, m.f, m.n, m.uv]:
            h.update(a.tobytes())
    return h.hexdigest()


def artifact_hashes(out):
    return {p.relative_to(out).as_posix(): digest(p) for p in sorted(Path(out).rglob('*')) if p.is_file() and p.name != 'report.json'}


def audit(folder, latest=False):
    """Recheck saved artifacts; optionally require the current kit fingerprint."""
    folder = Path(folder).resolve()
    path = folder / 'report.json'
    if not path.is_file():
        raise ValueError('Project report.json is missing.')
    report = json.loads(path.read_text(encoding='utf-8'))
    changes = []
    for name, expected in report.get('artifacts', {}).items():
        p = (folder / name).resolve()
        if not p.is_relative_to(folder) or not p.is_file() or digest(p) != expected:
            changes.append(name)
    expected_names = set(report.get('artifacts', {}))
    current_names = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file() and p.name != 'report.json'}
    changes.extend(sorted(current_names - expected_names))
    current = source()
    stale = report['source_sha256'] != current
    checks = []
    for row in report['lods']:
        p = (folder / row['file']).resolve()
        if not p.is_relative_to(folder):
            raise ValueError('Project model path escapes its folder.')
        checks.append(check(p))
    from agent.hands import check as check_hands
    hand_checks = [check_hands(folder / row['file']) for row in report['lods']]
    return {
        'ok': not changes and all((c['passed'] for c in checks)) and all(h['ok'] for h in hand_checks) and (not (latest and stale)),
        'hands': hand_checks,
        'changed_artifacts': changes,
        'source_matches_current': not stale,
        'built_source_sha256': report['source_sha256'],
        'current_source_sha256': current,
        'validation': checks
    }


def compile_glb(data, meshes, maps, out, fingerprint, lod, hands=None):
    """Create one LOD and embed maps; identical geometry may share storage."""
    g = GLB()
    for name, cfg in data['materials'].items():
        if maps[name]:
            g.material(
                name,
                color=(1, 1, 1, 1),
                metal=1,
                rough=1,
                emission=cfg.get('emission'),
                maps=maps[name],
                normal_scale=cfg.get('normal_scale', 1),
                wrap=cfg.get('wrap', 'repeat')
            )
        else:
            g.material(
                name,
                color=(*color(cfg, 'linear'), 1),
                metal=cfg.get('metal', 0),
                rough=cfg.get('rough', 0.82),
                emission=cfg.get('emission')
            )
    shared = {}
    for p, mesh in meshes:
        h = hashlib.sha256(p['mat'].encode())
        for a in [mesh.v, mesh.f, mesh.n, mesh.uv]:
            h.update(a.tobytes())
        key = h.hexdigest()
        transform = {k: p[k] for k in ['pos', 'rot', 'scale'] if k in p}
        if key in shared:
            g.group(p['name'], mesh=shared[key], **transform)
        else:
            ni = g.add_mesh(p['name'], mesh, p['mat'], **transform)
            mi = g.j['nodes'][ni]['mesh']
            g.j['meshes'][mi]['primitives'][0]['attributes']['TANGENT'] = g.accessor(tangents(mesh), 'VEC4')
            shared[key] = mi
    g.j['asset']['generator'] = f'AI 3D Kit {VERSION} / agent recipe compiler'
    g.j['extras'] = {
        'version': VERSION,
        'source_sha256': fingerprint,
        'recipe': data['name'],
        'lod_factor': lod,
        'units': 'meters',
        'up': '+Y',
        'front': '+Z',
        'detail': 'explicit target displacement plus baked maps; not measured reconstruction'
    }
    if hands:
        g.j['extras']['ai3d_hands'] = copy.deepcopy(hands)
    g.save(out)


def build(data, root, out, render='cpu', size=384):
    """Stage a validated recipe build and never replace a different output snapshot."""
    start = time.perf_counter()
    validate(data)
    recipe = data
    from agent.hands import expand, check as check_hands
    data, hand_records = expand(recipe)
    if hand_records:
        validate(data)
    if render not in {'none', 'cpu'}:
        raise ValueError('render must be none or cpu.')
    if not 64 <= size <= 1600:
        raise ValueError('Preview size must be between 64 and 1600.')
    if Path(out).is_symlink():
        raise ValueError('Output cannot be a symbolic link.')
    out = Path(out).resolve()
    root = Path(root).resolve()
    from agent.state import output_path
    output_path(out, allow_existing=True)
    if out == root or out in root.parents:
        raise ValueError('Output cannot replace the recipe folder or its parent.')
    texture_size = data.get('texture_size', 256)
    if sum((m.get(
        'tex_size',
        texture_size
    ) ** 2 for m in data['materials'].values() if not plain(m))) > 16777216:
        raise ValueError('Texture budget exceeds 16 million texels across materials. Reduce texture_size or material count.')
    inputs = assets(data, root)
    fingerprint = source()
    runtime = {
        'python': platform.python_version(),
        'platform': platform.platform(),
        'packages': {n: importlib.metadata.version(n) for n in ['numpy', 'scipy', 'Pillow', 'jsonschema']}
    }
    req = {
        'runtime': runtime,
        'recipe': recipe,
        'input_assets': inputs,
        'source': fingerprint,
        'render': render,
        'size': size
    }
    key = hashlib.sha256(json.dumps(req, sort_keys=True, allow_nan=False).encode()).hexdigest()
    if out.exists():
        report_path = out / 'report.json'
        if report_path.is_file():
            old = json.loads(report_path.read_text(encoding='utf-8'))
            if old.get('build_key') == key and audit(out, latest=True)['ok']:
                return {
                    **old,
                    'cached': True,
                    'request_seconds': round(time.perf_counter() - start, 4),
                    'folder': str(out)
                }
        raise FileExistsError('Output exists but does not match this build. Choose a new folder.')
    lods = data.get('lods', [1])
    t = time.perf_counter()
    from agent.stamps import library, export_stamp
    prepared = library(data, root)
    contexts = {}
    geometry_levels, reuse = geometry(data, root, prepared, contexts)
    phases = {'geometry': time.perf_counter() - t}
    out.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.' + out.name + '-', dir=out.parent))
    try:
        local = relocate(data, root, stage)
        write(stage / 'recipe.json', relocate(recipe, root, stage))
        compiled = copy.deepcopy(local)
        original = list(local['materials'])
        seeds = {k: data.get('seed', 42) + original.index(k) * 7919 for k in original}
        variants = {}
        first = {p['name']: m for p, m in geometry_levels[0]}
        levels = []
        for li, meshes in enumerate(geometry_levels):
            level = []
            for raw_part, mesh in meshes:
                part = copy.deepcopy(next((p for p in local['parts'] if p['name'] == raw_part['name'])))
                ctx = contexts.get((li, part['name']))
                if part.get('stamps') or part.get('sculpt'):
                    part['scale'] = [1, 1, 1]
                if part.get('decals') or ctx is not None or local['materials'][part['mat']].get('edge_wear', 0):
                    base_name = part['mat']
                    name = base_name[:30] + '_' + hashlib.sha256((signature([(
                        dict(mat=base_name, decals=part.get('decals')),
                        mesh
                    )]) + (part['name'] + str(li) if ctx is not None else '')).encode()).hexdigest()[:20]
                    compiled['materials'][name] = copy.deepcopy(local['materials'][base_name])
                    variants[name] = (
                        ctx.ref if ctx is not None else first[part['name']],
                        part.get('decals'),
                        ctx
                    )
                    seeds[name] = seeds[base_name]
                    part['mat'] = name
                level.append((part, mesh))
            levels.append(level)
        geometry_levels = levels
        used = {p['mat'] for level in levels for p, _ in level}
        compiled['materials'] = {k: v for k, v in compiled['materials'].items() if k in used}
        if sum((
            m.get('tex_size', texture_size) ** 2 for k,
            m in compiled['materials'].items() if k in variants or not plain(m)
        )) > 16777216:
            raise ValueError('Texture budget exceeds 16 million texels after per-part decal/stamp LOD variants. Reduce material sizes, LODs or stamped parts.')
        maps, material_info = ({}, {})
        t = time.perf_counter()
        for name, cfg in compiled['materials'].items():
            mesh, decals, ctx = variants.get(name, (None, None, None))
            simple = plain(cfg) and (not decals) and (ctx is None)
            if simple:
                maps[name] = {}
                material_info[name] = {'kind': 'solid', 'texture_size': 0, 'maps': {}, 'baked': False}
            else:
                maps[name], material_info[name] = make(
                    cfg,
                    stage / 'textures' / name,
                    cfg.get('tex_size', texture_size),
                    seeds[name],
                    stage,
                    mesh,
                    decals,
                    stamp_ctx=ctx
                )
        if prepared or reuse['sculpt_geometry']:
            for name, stamp in prepared.items():
                export_stamp(stamp, stage / 'stamps' / name)
            before = GLB()
            for name, cfg in local['materials'].items():
                before.material(
                    name,
                    color=(*color(cfg, 'linear'), 1),
                    rough=cfg.get('rough', 0.82),
                    metal=cfg.get('metal', 0)
                )
            for p in data['parts']:
                mesh = shape(
                    {
                        k: v for k,
                        v in p.items() if k not in {'stamps', 'stamp_limit', 'sculpt', 'sculpt_limit'}
                    },
                    1
                )
                before.add_mesh(
                    p['name'],
                    mesh,
                    p['mat'],
                    **{k: p[k] for k in ('pos', 'rot', 'scale') if k in p}
                )
            before.j['extras'] = {
                'version': VERSION,
                'source_sha256': fingerprint,
                'purpose': 'Original coarse geometry with flat base colors; no stamps, decals or material maps.'
            }
            before.save(stage / 'before.glb')
        phases['materials'] = time.perf_counter() - t
        rows, skipped, seen = ([], [], set())
        t = time.perf_counter()
        for i, (lod, meshes) in enumerate(zip(lods, geometry_levels)):
            sig = signature(meshes)
            if sig in seen:
                skipped.append({
                    'factor': lod,
                    'reason': 'Identical geometry and assignments to an already exported level.'
                })
                continue
            seen.add(sig)
            dst = stage / ('model.glb' if not rows else f'model_lod{len(rows)}.glb')
            raw = stage / f'raw_lod{i}.glb'
            level_data = copy.deepcopy(compiled)
            mat_names = {p['mat'] for p, _ in meshes}
            level_data['materials'] = {k: v for k, v in compiled['materials'].items() if k in mat_names}
            compile_glb(level_data, meshes, maps, raw, fingerprint, lod, hand_records)
            optimize(raw, dst)
            raw.unlink()
            result = check(dst)
            hand_check = check_hands(dst) if hand_records else None
            if hand_check is not None and not hand_check['ok']:
                raise ValueError('Hand validation failed: ' + '; '.join(hand_check['errors']))
            if not result['passed']:
                raise ValueError('GLB validation failed: ' + '; '.join(result['errors']))
            rows.append({
                'file': dst.name,
                'factor': lod,
                'rendered_triangles': result['rendered_triangles'],
                'stored_triangles': result['stored_triangles'],
                'stored_vertices': result['stored_vertices'],
                'bytes': result['bytes'],
                'sha256': result['sha256'],
                'dimensions_m': result['dimensions_m'],
                'passed': result['passed'],
                'warnings': result['warnings'],
                'parts': [p['name'] for p, _ in meshes]
            })
        hand_report = check_hands(stage / 'model.glb')
        if hand_records:
            write(stage / 'hands.json', hand_report)
        from agent.quality import inspect as texture_check
        quality = texture_check(stage / 'model.glb')
        write(stage / 'quality.json', quality)
        if not quality['ok']:
            raise ValueError('Texture validation failed: ' + str(quality['issues']))
        phases['export_validate'] = time.perf_counter() - t
        elapsed = time.perf_counter() - start
        if render != 'none':
            from agent.preview import render as draw
            draw(stage / 'model.glb', stage / 'views', size=size)
        from agent.preview import page
        page(stage / 'model.glb', stage, data['name'])
        report = {
            'ok': True,
            'version': VERSION,
            'name': data['name'],
            'brief': data.get('brief', ''),
            'source_sha256': fingerprint,
            'build_key': key,
            'cached': False,
            'environment': runtime,
            'build_seconds': round(elapsed, 4),
            'total_seconds': round(time.perf_counter() - start, 4),
            'timing_scope': 'Build includes geometry, texture baking, export and internal validation. Total also includes requested renders and HTML packaging; excludes chat planning and image generation.',
            'review_required': True,
            'texture_quality': 'quality.json',
            'hand_quality': 'hands.json' if hand_records else None,
            'hand_status': hand_report['status'],
            'render_backend': render,
            'lods': rows,
            'skipped_lods': skipped,
            'materials': material_info,
            'geometry_reuse': reuse,
            'phase_seconds': {k: round(v, 6) for k, v in phases.items()},
            'projected_decals': sum((len(p.get('decals', [])) for p in data['parts'])),
            'stamps': reuse['stamp_geometry'],
            'stamp_assets': ['stamps/' + name + '/stamp.json' for name in prepared],
            'sculpt': reuse['sculpt_geometry'],
            'before_model': 'before.glb' if prepared or reuse['sculpt_geometry'] else None,
            'input_assets': inputs,
            'baked_detail_added_triangles': 0,
            'limitations': [
                'UV layers and projected decals are shading/color detail. Explicit stamps change target geometry unless mode=bump.',
                'Stamps are local height fields, not Boolean cuts, undercuts, or verified photo reconstruction.',
                'Stamp support is position-based and seam-synchronized; self-intersections and thin-wall safety need inspection.',
                'Each stamped LOD has its own residual normal bake; curvature derivatives are approximated.',
                'Projected decals use unique primitive UVs and normal/depth clipping; concave self-occlusion is not ray traced.',
                'Per-part decal variants increase material/texture count even though they add zero triangles.',
                'LOD reduces analytic sampling and omits only parts explicitly marked min_lod.',
                'Internal GLB subset validation is not official Khronos certification or a realism assessment.',
                'Photo lighting removal and physical material recovery are not performed by this compiler.'
            ],
            'artifacts': artifact_hashes(stage)
        }
        write(stage / 'report.json', report)
        if out.exists():
            raise FileExistsError('Output was created by another process.')
        stage.rename(out)
        return {**report, 'folder': str(out)}
    except BaseException:
        shutil.rmtree(stage, ignore_errors=True)
        raise
