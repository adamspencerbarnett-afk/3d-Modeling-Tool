"""Build and verify static hands in an explicit wrist-local coordinate frame.

Local +Y points toward the fingers and +Z out through the palm. A right
thumb lies on +X; a left thumb lies on -X. Placement is a proper rotation,
not a negative scale. These are mechanical hand templates, not a rig or
an anatomy detector for unannotated imported meshes.
"""

from __future__ import annotations

import copy
import warnings
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation

from core.mesh import GLB, box, matrix, merge, unit

ROLES = ('palm', 'digits', 'armor', 'joints')


def frame(elbow, wrist, palm, direction=None):
    """Construct a right-handed basis from an arm axis and a palm-facing hint."""
    elbow, wrist, palm = (np.asarray(v, dtype=float) for v in (elbow, wrist, palm))
    if any(v.shape != (3,) or not np.isfinite(v).all() for v in (elbow, wrist, palm)):
        raise ValueError('Hand anchors and palm direction need three finite numbers.')
    arm = unit(wrist - elbow)
    y = arm if direction is None else np.asarray(direction, dtype=float)
    if y.shape != (3,) or not np.isfinite(y).all():
        raise ValueError('Hand direction needs three finite numbers.')
    y = unit(y)
    bend = np.degrees(np.arccos(np.clip(np.dot(arm, y), -1, 1)))
    if bend > 80 + 1e-8:
        raise ValueError('Hand direction points back along the forearm or exceeds the supported 80-degree wrist bend.')
    hint = unit(palm)
    z = hint - y * np.dot(hint, y)
    if np.linalg.norm(z) < 0.1:
        raise ValueError('Palm direction is parallel or nearly parallel to the finger direction.')
    z = unit(z)
    x = unit(np.cross(y, z))
    z = unit(np.cross(x, y))
    out = np.eye(4)
    out[:3, :3] = np.column_stack((x, y, z))
    out[:3, 3] = wrist
    return out


def anchor(value, parts=None, glb=None, worlds=None):
    """Resolve a world point or a part-local anchor without guessing body-side names."""
    if not isinstance(value, dict):
        return np.asarray(value, dtype=float)
    point = np.asarray(value.get('point', [0, 0, 0]), dtype=float)
    name = value['part']
    if glb is not None:
        index = glb.find('nodes', name)
        if index not in worlds:
            raise ValueError(f'Hand anchor {name!r} is not in the active scene.')
        m = worlds[index]
    else:
        if name not in parts:
            raise ValueError(f'Unknown hand anchor part: {name}')
        part = parts[name]
        m = matrix(**{k: part[k] for k in ('pos', 'rot', 'scale') if k in part})
    return m[:3, :3] @ point + m[:3, 3]


def spec(cfg):
    """Validate one hand declaration, also when called directly from Python."""
    from jsonschema import Draft202012Validator
    from agent.schema import HAND, finite
    finite(cfg)
    error = next(iter(Draft202012Validator(HAND).iter_errors(cfg)), None)
    if error:
        raise ValueError('Hand definition: ' + error.message)
    w, length, depth = cfg.get('size', [.075, .085, .03])
    if not .4 <= w / length <= 1.5 or not .12 <= depth / w <= .65:
        raise ValueError('Hand size needs palm width/length in [0.4, 1.5] and depth/width in [0.12, 0.65].')
    return cfg


def meshes(cfg):
    """Create four material groups and the actual five digit paths in local space."""
    from agent.geom import shape
    spec(cfg)
    w, length, depth = cfg.get('size', [.075, .085, .03])
    sign = 1 if cfg['side'] == 'right' else -1
    curl = np.radians(cfg.get('curl', 28))
    spread = np.radians(cfg.get('spread', 5))
    groups = {name: [] for name in ROLES}
    paths = {}

    def put(role, mesh, pos=(0, 0, 0), rot=(0, 0, 0)):
        groups[role].append(mesh.transformed(matrix(pos=pos, rot=rot)))

    def block(role, size, pos, rot=(0, 0, 0), bevel=None):
        b = min(size) * .12 if bevel is None else bevel
        put(role, box(size, b), pos, rot)

    def joint(point, radius, span, axis=(1, 0, 0)):
        # Cylinders are aligned from local +Y to their hinge axis, with no reflection.
        m = frame(np.zeros(3), np.asarray(axis), [0, 0, 1])
        m[:3, 3] = point
        mesh = shape({'shape': 'cylinder', 'radius': radius, 'length': span, 'steps': 12})
        groups['joints'].append(mesh.transformed(m))

    def segment(a, b, width, thick, plated=True):
        a, b = np.asarray(a), np.asarray(b)
        d = b - a
        m = frame(a, b, [0, -d[2], d[1]])
        m[:3, 3] = (a + b) / 2
        seg = np.linalg.norm(b - a)
        groups['digits'].append(box([width, seg * .87, thick], min(width, thick) * .12).transformed(m))
        if plated:
            panel = box([width * .84, seg * .63, thick * .19], thick * .045)
            # Dorsal plates stay opposite the palm normal as each joint curls.
            panel = panel.transformed(matrix(pos=[0, 0, -thick * .57]))
            groups['armor'].append(panel.transformed(m))

    block('palm', [w, length * .91, depth], [0, length * .59, 0])
    stem = shape({'shape': 'cylinder', 'radius': w * .19, 'length': length * .34, 'steps': 16})
    put('joints', stem, [0, length * .075, 0])
    block('armor', [w * .87, length * .69, depth * .20], [0, length * .59, -depth * .58])
    block('palm', [w * .72, length * .49, depth * .16], [0, length * .53, depth * .56])

    # Digits are ordered radially to ulnarly, not by screen-space left/right.
    digits = [
        ('index', .34, 1.04, 1.00, .7),
        ('middle', .105, 1.06, 1.10, 0),
        ('ring', -.13, 1.04, 1.03, -.45),
        ('little', -.355, .97, .79, -.9),
    ]
    for name, x, y, ratio, fan in digits:
        width = w * (.18 if name != 'little' else .16)
        thick = depth * .56
        points = [np.array([sign * x * w, y * length, 0.0])]
        for fraction, bend in zip((.44, .32, .24), (.22, .86, 1.42)):
            angle = curl * bend
            d = unit([sign * np.sin(fan * spread), np.cos(angle), np.sin(angle)])
            points.append(points[-1] + d * length * 1.12 * ratio * fraction)
        paths[name] = [p.tolist() for p in points]
        for i, (a, b) in enumerate(zip(points, points[1:])):
            joint(a, thick * .60, width * 1.08)
            segment(a, b, width * (1 - .09 * i), thick * (1 - .07 * i))

    points = [np.array([sign * w * .43, length * .42, depth * .11])]
    for reach, d in [
        (.34, [sign * .82, .48, .22]),
        (.31, [sign * .42, .83, .37]),
        (.25, [-sign * .10, .85, .51]),
    ]:
        points.append(points[-1] + unit(d) * length * reach)
    paths['thumb'] = [p.tolist() for p in points]
    for i, (a, b) in enumerate(zip(points, points[1:])):
        joint(a, depth * (.33 - .03 * i), w * .20)
        segment(a, b, w * (.23 - .025 * i), depth * (.67 - .06 * i))

    return {role: merge(group) for role, group in groups.items()}, paths


def expand(data):
    """Expand declarative hands while retaining the small input recipe for replay."""
    out = copy.deepcopy(data)
    declarations = out.pop('hands', [])
    parts = {p['name']: p for p in data['parts']}
    names = set(parts)
    records = []
    for cfg in declarations:
        spec(cfg)
        for key in ('mat', 'joint_mat', 'armor_mat'):
            if cfg[key] not in data['materials']:
                raise ValueError(f"{cfg['name']}: unknown hand material {cfg[key]!r}.")
        elbow, wrist = (anchor(cfg[k], parts=parts) for k in ('elbow', 'wrist'))
        m = frame(elbow, wrist, cfg['palm'], cfg.get('direction'))
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Gimbal lock detected', category=UserWarning)
            rot = Rotation.from_matrix(m[:3, :3]).as_euler('xyz', degrees=True).tolist()
        groups, _ = meshes(cfg)
        refs = {}
        for role, mesh in groups.items():
            name = cfg['name'] + '_' + role
            if name in names:
                raise ValueError(f'Generated hand part name collides with another part: {name}')
            names.add(name)
            refs[role] = name
            material = cfg['armor_mat'] if role == 'armor' else cfg['joint_mat'] if role == 'joints' else cfg['mat']
            out['parts'].append({
                'name': name, 'shape': 'mesh', 'mat': material,
                'v': mesh.v.tolist(), 'f': mesh.f.tolist(),
                'uv': 'atlas' if role in {'armor', 'palm'} or data['materials'][material].get('edge_wear', 0) else 'metric',
                'pos': wrist.tolist(), 'rot': rot,
            })
            if out['parts'][-1]['uv'] == 'metric':
                out['parts'][-1]['uv_size'] = max(cfg.get('size', [.075, .085, .03])) * 1.5
        records.append({'spec': copy.deepcopy(cfg), 'parts': refs})
    if len(out['parts']) > 256:
        raise ValueError('The 256-part budget includes generated hand parts. Reduce authored parts or hands.')
    return out, records


def check(model):
    """Check declared hand placement and exported geometry, without certifying anatomy.

The output is deliberately marked not_checked for an unannotated mesh. An
intentional pose/shape edit needs a matching recipe rebuild rather than an
old placement contract silently passing after that edit.
"""
    g = model if isinstance(model, GLB) else GLB.load(Path(model))
    extras = g.j.get('extras', {})
    records = extras.get('ai3d_hands', []) if isinstance(extras, dict) else []
    result = {
        'ok': True, 'status': 'checked' if records else 'not_checked',
        'checked': 0, 'hands': [], 'errors': [], 'review_required': True,
        'scope': 'Declared mechanical hand templates, wrist placement, digit handedness and palm-side curl; not rigging, collision, or arbitrary-mesh anatomy certification.',
    }
    if not isinstance(records, list) or len(records) > 8:
        result.update(ok=False, status='invalid', errors=['Invalid or oversized hand declaration list.'])
        return result
    if not records:
        result['note'] = 'No hand declarations are embedded. This is not a hand-orientation pass.'
        return result
    worlds = g.worlds()
    names = set()
    for record in records:
        row = {'name': None, 'ok': False, 'errors': []}
        try:
            cfg = spec(record['spec'])
            row['name'] = cfg['name']
            if cfg['name'] in names:
                raise ValueError('Duplicate hand declaration name.')
            names.add(cfg['name'])
            row['side'] = cfg['side']
            elbow, wrist = (anchor(cfg[k], glb=g, worlds=worlds) for k in ('elbow', 'wrist'))
            m = frame(elbow, wrist, cfg['palm'], cfg.get('direction'))
            expected, paths = meshes(cfg)
            tolerance = max(cfg.get('size', [.075, .085, .03])) * 1e-4
            max_error = 0.0
            for role in ROLES:
                index = g.find('nodes', record['parts'][role])
                if index not in worlds:
                    raise ValueError(f'{role}: hand mesh is not in the active scene.')
                node = g.j['nodes'][index]
                if 'mesh' not in node:
                    raise ValueError(f'{role}: missing mesh.')
                if not np.allclose(worlds[index], m, rtol=0, atol=tolerance):
                    raise ValueError(f'{role}: transform no longer matches the declared wrist/palm frame.')
                verts, faces, counts = [], [], 0
                for prim in g.j['meshes'][node['mesh']]['primitives']:
                    v = g.array(prim['attributes']['POSITION']).astype(float)
                    if len(v) > 30000 or not np.isfinite(v).all():
                        raise ValueError(f'{role}: invalid or oversized hand vertices.')
                    if prim.get('mode', 4) != 4:
                        raise ValueError(f'{role}: hand primitives must be triangles.')
                    f = g.array(prim['indices']).reshape(-1, 3).astype(int)
                    verts.append(v)
                    faces.append(v[f])
                    counts += len(f)
                actual = np.concatenate(verts)
                mesh = expected[role]
                if counts != len(mesh.f):
                    raise ValueError(f'{role}: generated topology count changed; rebuild the hand contract.')
                error = max(
                    cKDTree(mesh.v).query(actual, k=1)[0].max(),
                    cKDTree(actual).query(mesh.v, k=1)[0].max(),
                )
                if error > tolerance:
                    raise ValueError(f'{role}: geometry differs from the hand template by {error:.6g} m; possible inversion or stale declaration.')
                triangles = np.concatenate(faces)
                source = mesh.v[mesh.f]
                centers = cKDTree(source.mean(axis=1))
                distance, nearest = centers.query(triangles.mean(axis=1), k=1)
                normals = unit(np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0]))
                normal_ref = unit(np.cross(source[:, 1] - source[:, 0], source[:, 2] - source[:, 0]))
                if distance.max() > tolerance or np.min(np.sum(normals * normal_ref[nearest], axis=1)) < .99:
                    raise ValueError(f'{role}: topology or triangle winding no longer matches the hand template.')
                max_error = max(max_error, float(error))
            sign = 1 if cfg['side'] == 'right' else -1
            if sign * paths['thumb'][0][0] <= 0:
                raise ValueError('Thumb lies on the wrong anatomical side.')
            row_x = [sign * paths[name][0][0] for name in ('index', 'middle', 'ring', 'little')]
            if not all(a > b for a, b in zip(row_x, row_x[1:])):
                raise ValueError('Finger order does not run index to little away from the thumb.')
            curls = {name: float(path[-1][2] - path[0][2]) for name, path in paths.items()}
            if min(curls.values()) < -tolerance:
                raise ValueError('A digit curls toward the back of the hand, not the palm.')
            row.update(
                ok=True, wrist=wrist.tolist(),
                finger_direction=m[:3, 1].tolist(), palm_normal=m[:3, 2].tolist(),
                thumb_direction=(sign * m[:3, 0]).tolist(),
                frame_determinant=float(np.linalg.det(m[:3, :3])),
                digit_count=len(paths), palm_side_curl_m=curls,
                max_vertex_error_m=max_error, tolerance_m=tolerance,
                verified_mesh_parts=list(record['parts'].values()),
            )
        except (KeyError, TypeError, ValueError, IndexError) as error:
            row['errors'].append(str(error))
            result['errors'].append(f"{row['name'] or 'hand'}: {error}")
        result['hands'].append(row)
    result['checked'] = len(result['hands'])
    result['ok'] = not result['errors']
    return result
