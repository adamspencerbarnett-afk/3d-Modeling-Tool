"""Translate recipe shapes to Y-up geometry, UV layouts, and tangent frames."""

from __future__ import annotations
import numpy as np
from core.mesh import Mesh, box, cylinder, lathe, hose, plate, flat, matrix, unit


def atlas(mesh):
    tri = mesh.v[mesh.f]
    ns = mesh.n[mesh.f]
    uv = np.empty((len(tri), 3, 2), float)
    lo = mesh.v.min(0)
    span = np.maximum(np.ptp(mesh.v, axis=0), 1e-09)
    q = (tri - lo) / span
    fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    axis = np.argmax(np.abs(fn), axis=1)
    for a, axis_slots in [(2, (0, 1)), (0, (2, 3)), (1, (4, 5))]:
        for positive, slot in zip((True, False), axis_slots):
            sel = (axis == a) & ((fn[:, a] > 0) == positive)
            pts = q[sel]
            if a == 2:
                u, v = (pts[:, :, 0] if positive else 1 - pts[:, :, 0], 1 - pts[:, :, 1])
            elif a == 0:
                u, v = (1 - pts[:, :, 2] if positive else pts[:, :, 2], 1 - pts[:, :, 1])
            else:
                u, v = (pts[:, :, 0], pts[:, :, 2] if positive else 1 - pts[:, :, 2])
            uv[sel, :, 0] = (slot % 3 + 0.025 + 0.95 * u) / 3
            uv[sel, :, 1] = (slot // 3 + 0.025 + 0.95 * v) / 2
    return Mesh(
        tri.reshape(-1, 3),
        np.arange(len(tri) * 3, dtype=np.uint32).reshape(-1, 3),
        ns.reshape(-1, 3),
        uv.reshape(-1, 2)
    )


def cap_uv(mesh):
    tri, ns = (mesh.v[mesh.f], mesh.n[mesh.f])
    uv = mesh.uv[mesh.f].copy()
    mean = ns.mean(1)
    cap = np.abs(mean[:, 1]) > 0.99
    center = (mesh.v.min(0) + mesh.v.max(0)) / 2
    span = np.maximum(np.ptp(mesh.v, axis=0), 1e-09)
    radial = np.sum((tri[:, :, [0, 2]] - center[[0, 2]]) * ns[:, :, [0, 2]], axis=(1, 2))
    inner = ~cap & (radial < 0)
    outer = ~cap & ~inner
    q = (tri - mesh.v.min(0)) / span
    uv[outer, :, 1] = 0.02 + 0.44 * (1 - q[outer, :, 1])
    uv[inner, :, 1] = 0.5 + 0.16 * (1 - q[inner, :, 1])
    for up, cx in [(True, 0.25), (False, 0.75)]:
        sel = cap & ((mean[:, 1] > 0) == up)
        uv[sel, :, 0] = cx + (q[sel, :, 0] - 0.5) * 0.46
        uv[sel, :, 1] = 0.835 + (q[sel, :, 2] - 0.5) * (0.29 if up else -0.29)
    return Mesh(
        tri.reshape(-1, 3),
        np.arange(len(tri) * 3, dtype=np.uint32).reshape(-1, 3),
        ns.reshape(-1, 3),
        uv.reshape(-1, 2)
    )


def shape(p, lod=1):
    """Create recipe-local geometry with consistent units, axes, and UV controls."""
    from agent.curves import ellipsoid, torus, bowl, steps_for
    kind = p['shape']
    count = p.get('steps', 32)
    if 'error' in p:
        radius = max(p.get('size', [2 * max(p.get('radius', 0.5), p.get('top', 0))] * 3)) / 2
        if kind == 'torus':
            radius += p.get('tube', 0.08)
        radius *= max(p.get('scale', [1, 1, 1]))
        count = steps_for(radius, p['error'])
    steps = max(6, round(count * lod))
    if kind == 'box':
        mesh = box(p.get('size', [1, 1, 1]), p.get('bevel', 0))
    elif kind == 'cylinder':
        args = {k: p[k] for k in ['radius', 'length', 'inner', 'top'] if k in p}
        if 'rings' in p:
            radius, length = (p.get('radius', 0.1), p.get('length', 0.3))
            top, inner = (p.get('top', radius), p.get('inner', 0))
            if inner >= min(radius, top):
                raise ValueError('Cylinder inner radius must be smaller than both outer radii.')
            rows = max(1, round(p['rings'] * lod))
            height = np.linspace(-length / 2, length / 2, rows + 1)
            profile = [(inner, -length / 2)] + list(zip(np.linspace(radius, top, rows + 1), height))
            profile += [(inner, y) for y in height[::-1]]
            mesh = lathe(profile, steps).transformed(matrix(rot=(-90, 0, 0)))
        else:
            mesh = cylinder(**args, steps=steps).transformed(matrix(rot=(-90, 0, 0)))
        mesh.uv[:, 1] = 1 - mesh.uv[:, 1]
    elif kind == 'lathe':
        mesh = lathe(p['profile'], steps).transformed(matrix(rot=(-90, 0, 0)))
        mesh.uv[:, 1] = 1 - mesh.uv[:, 1]
    elif kind in {'sphere', 'ellipsoid'}:
        size = p.get('size', [2 * p.get('radius', 0.5)] * 3)
        mesh = ellipsoid(size, steps, max(4, 2 * round(p.get('rings', 16) * lod / 2)))
    elif kind == 'torus':
        mesh = torus(
            p.get('radius', 0.4),
            p.get('tube', 0.08),
            steps,
            max(4, 2 * round(p.get('rings', 12) * lod / 2))
        )
    elif kind == 'bowl':
        mesh = bowl(
            p.get('size', [1, 0.4, 1.5]),
            p.get('depth', 0.012),
            steps,
            max(2, round(p.get('rings', 6) * lod)),
            p.get('power', 2),
            p.get('taper', 0.58),
            p.get('lean', 0)
        )
    elif kind == 'hose':
        mesh = hose(
            p['points'],
            p.get('radius', 0.025),
            steps=max(6, round(p.get('steps', 10) * lod)),
            samples=max(2, round(p.get('samples', 24) * lod))
        )
    elif kind == 'plate':
        mesh = plate(p['points'], p.get('depth', 0.1))
    elif kind == 'prism':
        from agent.hard import prism
        mesh = prism(p['points'], p.get('depth', 0.1), p.get('bevel', 0), p.get('taper', 1))
    elif kind == 'mesh':
        v = np.asarray(p['v'], float)
        f = np.asarray(p['f'], int)
        if f.max() >= len(v) or f.min() < 0:
            raise ValueError('Custom mesh face index out of range.')
        mesh = flat(v, f)
        if 'uvs' in p:
            uvs = np.asarray(p['uvs'], float)
            if uvs.shape != (len(v), 2):
                raise ValueError('Custom UVs must contain one pair for every source vertex.')
            mesh.uv = uvs[f].reshape(-1, 2)
        if not len(mesh.f) or len(mesh.f) != len(f):
            raise ValueError('Custom mesh has zero-area faces.')
    else:
        raise ValueError(f'Unsupported primitive: {kind}')
    if p.get('uv') == 'box':
        mesh = atlas(mesh)
    elif p.get('uv') == 'cylinder':
        mesh = cap_uv(mesh)
    elif p.get('uv') == 'atlas':
        from agent.uv import atlas as unwrap
        mesh = unwrap(mesh)
    elif p.get('uv') == 'metric':
        from agent.uv import metric
        mesh = metric(mesh, p.get('uv_size', 1))
    mesh.uv *= np.array(p.get('tile', [1, 1]))
    return mesh


def tangents(mesh):
    """Derive a handed tangent frame from positions, normals, and UV derivatives."""
    f = mesh.f
    v, uv = (mesh.v[f], mesh.uv[f])
    e1, e2 = (v[:, 1] - v[:, 0], v[:, 2] - v[:, 0])
    a, b = (uv[:, 1] - uv[:, 0], uv[:, 2] - uv[:, 0])
    det = a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]
    good = np.abs(det) > 1e-12
    inv = np.zeros_like(det)
    inv[good] = 1 / det[good]
    t = (b[:, 1, None] * e1 - a[:, 1, None] * e2) * inv[:, None]
    bt = (-b[:, 0, None] * e1 + a[:, 0, None] * e2) * inv[:, None]
    ts, bs = (np.zeros_like(mesh.v), np.zeros_like(mesh.v))
    for j in range(3):
        np.add.at(ts, f[:, j], t)
        np.add.at(bs, f[:, j], bt)
    ns = unit(mesh.n)
    ts -= ns * np.einsum('ij,ij->i', ns, ts)[:, None]
    bad = np.linalg.norm(ts, axis=1) < 1e-10
    if bad.any():
        ref = np.eye(3)[np.argmin(np.abs(ns[bad]), axis=1)]
        ts[bad] = np.cross(ref, ns[bad])
    ts = unit(ts)
    sign = np.where(np.einsum('ij,ij->i', np.cross(ns, ts), bs) < 0, -1, 1)
    return np.column_stack([ts, sign])
