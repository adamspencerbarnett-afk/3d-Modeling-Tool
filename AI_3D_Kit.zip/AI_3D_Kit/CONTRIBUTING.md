# Contributing

Contributions intended for inclusion in the kit are submitted under its [MIT License](LICENSE). Retain third-party notices and identify separately licensed components. Do not submit code or assets you lack permission to contribute.

## Keep the kit small

Keep one public entry point, `kit.py`, and small task-oriented modules. Prefer JSON recipes to per-model applications. Use short, descriptive names and explain non-obvious mathematics, transforms, validation boundaries, and resource handling with docstrings or comments. Do not keep old versioned copies, unused wrappers, or compatibility flags for absent engines.

Retain regression coverage when refactoring. Before deleting a seemingly unused method, check framework hooks, closures, and dynamic API calls; the optional importer resolver is one such interface. Do not silently drop unsupported model features or hide failures behind broad exception handlers.

## Validate changes

Review the diff and refresh the release manifest after intentional source or documentation edits:

```bash
python -B -m tools.release
python -B -m unittest discover -s tests -v
python -B kit.py boot
python -B -m tools.release --check
```

Inspect real exported-model views for geometry, material, and hand changes. For the browser viewer, also check JavaScript syntax and test interactive WebGL in a compatible browser. The optional Node-based test checks syntax and fallback behavior only; Node is not a modeling dependency.

The compatibility surface is the documented CLI and JSON schemas, not every internal Python helper. Keep runtime dependency specifications in the existing requirements files. Avoid adding a second installer or environment definition.

## Submit a focused change

Describe the problem, implementation, tests actually run, and remaining limits. Record the origin and terms of new code, images, fonts, and model assets. Include applicable notices; keep outputs, private data, credentials, font binaries, and model weights out of the source release. Use [PUBLISHING.md](PUBLISHING.md) when preparing a downloadable kit.
