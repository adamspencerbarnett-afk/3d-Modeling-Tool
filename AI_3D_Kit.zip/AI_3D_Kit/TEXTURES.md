# Texturing and material inspection

The assistant runs these commands from the kit directory. Keep projects in a separate sibling folder. Paths inside a recipe/task are relative to that JSON's folder and must remain beneath it.

## Diagnose before replacing

A dark or flat preview is not proof that textures are missing. Inspect the actual GLB:

```text
python kit.py textures ../work/model.glb --out ../work/maps
```

`textures.json` identifies every active material and channel, dimensions, checksums, factors and UV statistics. `mat_N/` contains exact embedded image bytes, and `contact.png` displays the channels. `quality.json` is also written automatically during builds/imports/tasks. It checks referenced images and zero-area/missing UVs, not semantic likeness or all UV overlaps. Flat roughness/normal images may be intentional.

## Build a textured hard-surface asset

This complete recipe uses only built-in procedural material code and no external images:

```json
{
  "schema": "ai3d.recipe/1",
  "name": "Worn_Armor",
  "texture_size": 512,
  "max_triangles": 5000,
  "lods": [1],
  "materials": {
    "armor": {
      "kind": "steel", "color": [0.18, 0.19, 0.20], "color_space": "srgb",
      "rough": 0.74, "metal": 0.8, "wear": 0.5, "bump": 0.0004,
      "edge_wear": 0.65, "edge_width": 0.018,
      "layers": [{"kind": "speckle", "color": [0.07, 0.06, 0.05], "opacity": 0.45, "count": 40}]
    }
  },
  "parts": [{
    "name": "plate", "shape": "prism", "mat": "armor",
    "points": [[-0.5, 0], [0.5, 0], [0.28, 0.9], [-0.3, 1.1]],
    "depth": 0.18, "bevel": 0.025, "uv": "atlas",
    "decals": [{"kind": "text", "side": "front", "text": "CORE 03", "rect": [0.24, 0.55, 0.5, 0.14], "color": [0.65, 0.63, 0.57], "opacity": 0.7}]
  }]
}
```

Build with `python kit.py build ../work/armor.json --out ../work/armor`. Material presets are available with `python kit.py material armor --out ../work/armor_material.json`. Presets also include steel, rubber, hazard, red_core and wood. The material command writes a JSON material object, not an automatic recipe reference: insert that object in the recipe's materials dictionary.

## Supplied images and full map sets

A complete material entry, assuming these real files exist under `assets/`:

```json
{
  "kind": "image",
  "image": "assets/color.png",
  "source": "provided",
  "normal": "assets/normal.png",
  "normal_y": "opengl",
  "normal_scale": 0.8,
  "rough_map": "assets/roughness.png",
  "metal_map": "assets/metallic.png",
  "ao_map": "assets/occlusion.png",
  "emissive": "assets/emission.png",
  "emission": [1, 1, 1],
  "tex_size": 1024,
  "wrap": "repeat"
}
```

All listed paths are optional except the image for `kind: image`. Omit absent maps rather than inventing files. Separate grayscale maps are packed by the kit: red = occlusion, green = roughness, blue = metallic. Alternatively provide `orm: "assets/orm.png"` and omit all three separate map fields. The API rejects ambiguous packed-plus-separate input. An absent AO map defaults to white; a roughness/metallic texture's red channel alone is not an AO assignment on import.

Base color and emission images are interpreted as sRGB; scalar maps and tangent-space normals are linear data. `normal_y: directx` explicitly flips a supplied normal map's green channel; do not flip a normal already in the OpenGL convention. `normal_scale` adjusts tangent X/Y strength. `normal_strength` instead controls a normal generated from the kit's height field. A supplied height field is a single-channel image; its brightness is not automatically valid physical depth. Supplying a normal and height map together is rejected rather than combining them ambiguously.

Material factor RGB uses explicit `color_space: srgb` or `linear`. For compatibility, omitted color_space means linear for old solid materials and sRGB for procedural materials. Recipe `emission` is always a linear RGB factor in [0,1]. Solid color materials with no baking features do not allocate image maps. Image materials remain opaque; RGBA image *layers* composite their alpha into the surface. Recipe alpha-blended glass/cutout authoring is not included.

The exporter embeds used maps in the GLB. Recipe builds also retain generated texture PNGs. Imported-model texture tasks stage their source GLB and referenced image files so the task can be replayed without the original upload folder.

## Make a source swatch

```text
python kit.py swatch ../work/reference.png --crop 0.1 0.6 0.2 0.2 --size 512 --delight 0.25 --tile --out ../work/swatch
```

Crop is normalized x, y, width, height and must fit the source. For perspective correction, replace crop with `--corners` followed by eight normalized coordinates in clockwise top-left, top-right, bottom-right, bottom-left order. The output saves original source, selected color, a material object and provenance. The selected region is fit to a square.

`delight` is heuristic low-frequency illumination normalization, not recovery of calibrated albedo. `tile` matches opposing image edges with a ramp; it is not semantic texture synthesis. Small source crops remain small-source evidence even after upsampling. Do not include an entire concept sheet, labels or cast shadows in a tiling material. Crop a genuine surface region. For a photo-backed material with marks and wear, use the swatch as an image layer over a procedural surface; keep its source and crop information with the project.

## Choose UVs deliberately

`metric` supplies a planar mapping per face with a consistent *local-space* size per repeat via `uv_size`. It suits tiled steel, concrete and wood without unique marks. A later nonuniform transform can change world-space density. It is not a triplanar shader and can have seams.

`atlas` packs distinct planar surface charts into 0–1 with spacing. It suits hard-surface decals and geometry-aware edge wear. Do not tile a unique atlas. The packer rejects more than 4096 charts and does not promise a distortion-minimized organic unwrap. Keep existing UVs on a well-authored imported organic model.

Custom mesh recipes accept `uvs`, one [u,v] pair per original vertex, alongside `v` and triangle `f`. Duplicate source vertices where a UV seam needs two coordinates. The old `box` atlas uses +Z,-Z,+X / -X,+Y,-Y in a 3-by-2 layout; `cylinder` mapping remains supported. Inspect the actual UV checker before final baking.

Geometry edge wear uses a sampled distance to hard mesh edges. It excludes coplanar triangulation diagonals, applies deterministic noise and adjusts color/roughness/metallic. It changes shading, not silhouette. It needs unique atlas/box/cylinder mapping. Its width is local-space, and finite texture resolution limits small edge marks. Padded charts reduce filtering seams but do not prove every mip level is seam-free. Sculpt/stamps change geometry; bump/normal maps do not.

## Retexture an uploaded model

First inspect node names with `python kit.py inspect ../work/source.glb --full`. Then save this complete task beside the source GLB and its assets:

```json
{
  "schema": "ai3d.task/1",
  "name": "Repainted_Model",
  "op": "texture",
  "model": "source.glb",
  "texture_size": 512,
  "materials": {
    "new_armor": {
      "kind": "steel", "color": [0.16, 0.17, 0.18], "color_space": "srgb",
      "rough": 0.76, "metal": 0.85, "wear": 0.45,
      "edge_wear": 0.6, "edge_width": 0.015
    }
  },
  "assign": [{"node": "body", "mat": "new_armor", "uv": "atlas"}]
}
```

```text
python kit.py texture ../work/paint.json --out ../work/painted
python kit.py run ../work/painted/task.json --out ../work/rebuilt
```

The node must exist and be an unambiguous mesh node; an integer index also works. `node: "*"` targets every mesh node. The task replaces all primitives' materials on selected nodes, not arbitrary individual faces. Unselected instances retain their original geometry/material. Overlapping selections are rejected.

Use `uv: keep` to retain existing authored UVs; missing/zero-area textured UVs are rejected. `uv: metric` can include uv_size. `uv: atlas` enables mesh-aware wear and projected decals. Decals use the same schema as recipe parts, with a local side and normalized placement. Retexturing does not remesh, fuse pieces, retopologize, rig or modify a silhouette.

## Review and delivery

```text
python kit.py render ../work/painted/model.glb --out ../work/review --review --size 1000 --aa 2
python kit.py textures ../work/painted/model.glb --out ../work/exported_maps
python kit.py audit ../work/painted --latest
python kit.py pack ../work/painted --out ../work/painted.zip
```

Review outputs: hero, back, clay, front, side, top, base and uv. Additional single-channel inspection uses `render --mode normal|rough|metal|ao|emission`. These are real exported-model renders, not generative image replacements.

Draft/standard/high provide missing map-size defaults 256/512/1024 and triangle ceilings 10k/50k/100k. Explicit recipe/material settings win. The total baking budget is 16 million material texels; each baked material may write several channels. Instances count toward rendered triangles, even when geometry is stored once. Per-part wear/decal variants can increase texture count; preserve sharing where surfaces are identical. Higher resolution is not a remedy for an incorrect silhouette, UV layout or weak source image.

glTF 2.0 channel/color conventions: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
