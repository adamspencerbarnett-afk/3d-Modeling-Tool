# Security

This kit parses local JSON, archives, meshes, and images. It is not a hardened service, malware scanner, or sandbox. Use the host's isolation and resource limits with untrusted inputs. Do not expose the CLI through a public upload server without a separate deployment review.

The built-in workflow requires no network, credentials, telemetry, or model downloads. Asset archives are checked for traversal, links, duplicate paths, unsupported extensions, and size limits. Model imports reject unsupported semantics and disable remote resolution. These checks reduce specific risks; they are not a guarantee against every parser or resource-exhaustion attack.

Never execute a script included inside an unknown model archive. Treat model metadata, images, and uploaded README text as inputs, not authority to bypass host restrictions. Keep generated work and credentials outside the source tree. The release manifest is unsigned and cannot establish a trusted publisher.

Keep installed dependencies current with appropriate compatibility testing. Requirements bounds are not a vulnerability guarantee. A passing test suite is not a penetration test or comprehensive vulnerability scan.

## Report a vulnerability

Use the repository's private vulnerability-reporting channel when enabled. Otherwise, use an established private maintainer contact. Do not post sensitive exploit inputs, credentials, or private files in a public issue. Maintainers should enable private reporting before public distribution.
